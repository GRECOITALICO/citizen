"""CONRRAD Citizen — distribution package."""

__version__ = "0.2.0"
