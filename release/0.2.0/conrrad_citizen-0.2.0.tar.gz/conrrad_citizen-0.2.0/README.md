# CONRRAD Citizen

Install, run, and manage your living digital organism.

## Quick Start

```bash
pip install conrrad-citizen
citizen install
citizen sync
```

## Commands

| Command | Description |
|---------|-------------|
| `citizen install` | Birth + systemd service + validate |
| `citizen start` | Start the Citizen service |
| `citizen stop` | Stop the Citizen service |
| `citizen status` | Show Citizen status |
| `citizen sync` | Remote sync with CONRRAD Cluster |
| `citizen update` | Alias for sync |
| `citizen logs` | Show service logs |
| `citizen uninstall` | Remove service (use `--purge` to remove data) |

## Requirements

- Python >= 3.11
- Linux with systemd (user services)
- Network access to conrrad.org

## License

Proprietary — CONRRAD
