"""Runtime-owned inference need decision and post-policy implementation selection."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Callable

from .authorized_models import AuthorizedModel, resolve_authorized_model
from .capability_contract import (
    HISTORY_DIGEST_CAPABILITY_ID,
    INTENT_FIXTURE_A_IMPLEMENTATION_ID,
    INTENT_FIXTURE_B_IMPLEMENTATION_ID,
    INTENT_PROPOSAL_CAPABILITY_ID,
    INTEGRITY_DIGEST_CAPABILITY_ID,
    INTEGRITY_DIGEST_IMPLEMENTATION_ID,
    LOCAL_MODEL_IMPLEMENTATION_ID,
)
from .work_context import (
    TASK_CLASS_DETERMINISTIC,
    TASK_CLASS_SEMANTIC_INTERPRETATION,
    WorkContext,
)

POLICY_VERSION = "1.0.0"

REASON_DETERMINISTIC_CAPABILITY = "DETERMINISTIC_CAPABILITY"
REASON_DETERMINISTIC_WORK_CLASS = "DETERMINISTIC_WORK_CLASS"
REASON_SEMANTIC_INTERPRETATION_REQUIRED = "SEMANTIC_INTERPRETATION_REQUIRED"

DECISION_DETERMINISTIC_CAPABILITY = "DETERMINISTIC_CAPABILITY"
DECISION_DETERMINISTIC = "DETERMINISTIC"
DECISION_SEMANTIC_INTERPRETATION = "SEMANTIC_INTERPRETATION"


@dataclass(frozen=True)
class InferenceNeedDecision:
    """Runtime decision: does this Work require model inference?"""

    inference_required: bool
    reason: str
    policy_version: str
    decision_code: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class WorkExecutionPlan:
    """Policy output: inference need + selected implementation + optional authorized model."""

    implementation_id: str
    inference_decision: InferenceNeedDecision
    authorized_model: AuthorizedModel | None = None
    work_context: WorkContext | None = None

    @property
    def inference_required(self) -> bool:
        return self.inference_decision.inference_required

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "implementation_id": self.implementation_id,
            "inference_decision": self.inference_decision.to_dict(),
            "inference_required": self.inference_required,
            "inference_reason": self.inference_decision.reason,
            "policy_version": self.inference_decision.policy_version,
            "authorized_model": self.authorized_model.to_dict() if self.authorized_model else None,
            "work_context": self.work_context.to_dict() if self.work_context else None,
        }
        return payload


def decide_inference_need(work_context: WorkContext) -> InferenceNeedDecision | None:
    """Deterministic runtime policy — no model participates in this decision."""
    if work_context.capability_id in {
        INTEGRITY_DIGEST_CAPABILITY_ID,
        HISTORY_DIGEST_CAPABILITY_ID,
    }:
        return InferenceNeedDecision(
            inference_required=False,
            reason=REASON_DETERMINISTIC_CAPABILITY,
            policy_version=POLICY_VERSION,
            decision_code=DECISION_DETERMINISTIC_CAPABILITY,
        )

    if work_context.capability_id == INTENT_PROPOSAL_CAPABILITY_ID:
        if work_context.task_class == TASK_CLASS_DETERMINISTIC:
            return InferenceNeedDecision(
                inference_required=False,
                reason=REASON_DETERMINISTIC_WORK_CLASS,
                policy_version=POLICY_VERSION,
                decision_code=DECISION_DETERMINISTIC,
            )
        if work_context.task_class == TASK_CLASS_SEMANTIC_INTERPRETATION:
            return InferenceNeedDecision(
                inference_required=True,
                reason=REASON_SEMANTIC_INTERPRETATION_REQUIRED,
                policy_version=POLICY_VERSION,
                decision_code=DECISION_SEMANTIC_INTERPRETATION,
            )
        return None

    return None


def _is_probe_implementation(implementation_id: str) -> bool:
    return implementation_id.startswith("malicious.") or implementation_id.startswith("adversarial.")


def _implementation_matches_inference(
    implementation_id: str,
    *,
    inference_required: bool,
) -> bool:
    if inference_required:
        return implementation_id == LOCAL_MODEL_IMPLEMENTATION_ID
    return implementation_id in {
        INTENT_FIXTURE_A_IMPLEMENTATION_ID,
        INTENT_FIXTURE_B_IMPLEMENTATION_ID,
    }


def select_implementation_id(
    work_context: WorkContext,
    inference_decision: InferenceNeedDecision,
    explicit_implementation_id: str | None,
) -> str | None:
    """Choose implementation AFTER inference need is decided."""
    if work_context.capability_id in {
        INTEGRITY_DIGEST_CAPABILITY_ID,
        HISTORY_DIGEST_CAPABILITY_ID,
    }:
        return INTEGRITY_DIGEST_IMPLEMENTATION_ID

    if work_context.capability_id != INTENT_PROPOSAL_CAPABILITY_ID:
        return None

    default_impl = (
        LOCAL_MODEL_IMPLEMENTATION_ID
        if inference_decision.inference_required
        else INTENT_FIXTURE_A_IMPLEMENTATION_ID
    )

    if explicit_implementation_id:
        if _is_probe_implementation(explicit_implementation_id):
            if inference_decision.inference_required:
                return None
            return explicit_implementation_id
        if not _implementation_matches_inference(
            explicit_implementation_id,
            inference_required=inference_decision.inference_required,
        ):
            return None
        return explicit_implementation_id

    return default_impl


def resolve_work_execution(
    work_context: WorkContext,
    explicit_implementation_id: str | None,
    *,
    resolve_implementation: Callable[[str, str | None], str | None],
) -> WorkExecutionPlan | None:
    """WorkContext → inference need decision → implementation selection."""
    inference_decision = decide_inference_need(work_context)
    if inference_decision is None:
        return None

    implementation_id = select_implementation_id(
        work_context,
        inference_decision,
        explicit_implementation_id,
    )
    if implementation_id is None:
        return None

    if resolve_implementation(work_context.capability_id, implementation_id) is None:
        return None

    authorized_model: AuthorizedModel | None = None
    if inference_decision.inference_required:
        authorized_model = resolve_authorized_model(implementation_id)
        if authorized_model is None:
            return None

    return WorkExecutionPlan(
        implementation_id=implementation_id,
        inference_decision=inference_decision,
        authorized_model=authorized_model,
        work_context=work_context,
    )


# Backward-compatible helper for tests that inspect policy by implementation id.
def resolve_inference_policy(implementation_id: str) -> WorkExecutionPlan | None:
    from .implementation_registry import resolve_module

    if implementation_id == INTEGRITY_DIGEST_IMPLEMENTATION_ID:
        decision = InferenceNeedDecision(
            False, REASON_DETERMINISTIC_CAPABILITY, POLICY_VERSION, DECISION_DETERMINISTIC_CAPABILITY
        )
    elif implementation_id == LOCAL_MODEL_IMPLEMENTATION_ID:
        decision = InferenceNeedDecision(
            True, REASON_SEMANTIC_INTERPRETATION_REQUIRED, POLICY_VERSION, DECISION_SEMANTIC_INTERPRETATION
        )
    elif implementation_id in {
        INTENT_FIXTURE_A_IMPLEMENTATION_ID,
        INTENT_FIXTURE_B_IMPLEMENTATION_ID,
    }:
        decision = InferenceNeedDecision(
            False, REASON_DETERMINISTIC_WORK_CLASS, POLICY_VERSION, DECISION_DETERMINISTIC
        )
    elif resolve_module(implementation_id) is not None:
        decision = InferenceNeedDecision(
            False, REASON_DETERMINISTIC_WORK_CLASS, POLICY_VERSION, DECISION_DETERMINISTIC
        )
    else:
        return None

    authorized = resolve_authorized_model(implementation_id) if decision.inference_required else None
    return WorkExecutionPlan(
        implementation_id=implementation_id,
        inference_decision=decision,
        authorized_model=authorized,
    )
