"""Pack a signed local evolution for the living UpdateEngine.

This is an asset+manifest package, not a Python replacement. runtime_version
stays the running RUNTIME_VERSION so the current engine will accept it.
citizen_version advances to mark the living generation.
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

from . import COMPATIBILITY, RUNTIME_VERSION
from .assets import AssetLoader
from .crypto import load_publisher_secret, sha256_bytes
from .installer import _ensure_publisher_secret
from .manifest import default_seed_manifest, save_manifest, sign_manifest
from .paths import seed_root
from .work.capability_contract import (
    HISTORY_DIGEST_CAPABILITY_ID,
    HISTORY_DIGEST_GRANT_ASSET_ID,
    INTEGRITY_DIGEST_IMPLEMENTATION_ID,
)

UPDATE_VERSION = "0.4.3"
RELEASE_TS = "2026-08-23T18:00:00Z"
PACKAGE_ID = "citizen-0.4.3"


def package_assets_root() -> Path:
    return Path(__file__).resolve().parents[1] / "conrrad_citizen" / "_assets"


def citizen_assets_dir() -> Path:
    """Genesis + publisher secret: installed data dir, else the package _assets."""
    data_dir = os.environ.get("CITIZEN_DATA_DIR")
    if data_dir:
        installed = Path(data_dir).resolve() / "assets"
        if installed.is_dir():
            return installed
    pkg = package_assets_root()
    if pkg.is_dir():
        return pkg
    return seed_root() / "assets"


def default_updates_dir() -> Path:
    """Where a user-facing Citizen looks for signed update packages."""
    candidates = [
        seed_root() / "assets" / "updates",
        package_assets_root() / "updates",
    ]
    for path in candidates:
        if path.is_dir():
            return path
    return candidates[0]


def _git_field(*args: str) -> str:
    try:
        out = subprocess.check_output(
            ["git", *args],
            cwd=Path(__file__).resolve().parents[3],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return out.strip()
    except Exception:
        return ""


def grant_payload(*, source_commit: str) -> bytes:
    body = {
        "schema": "conrrad.citizen.capability_grant/v1",
        "capability_id": HISTORY_DIGEST_CAPABILITY_ID,
        "implementation_id": INTEGRITY_DIGEST_IMPLEMENTATION_ID,
        "granted_by": f"evolution-{UPDATE_VERSION}",
        "executable": True,
        "source_commit": source_commit,
    }
    return (json.dumps(body, indent=2, sort_keys=True) + "\n").encode("utf-8")


def pack_evolution(
    dest_dir: Path,
    *,
    secret: bytes | None = None,
    source_commit: str | None = None,
    release: str = RELEASE_TS,
) -> dict[str, Any]:
    """Write a signed 0.4.3 package the current UpdateEngine can apply."""
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    commit = source_commit or _git_field("rev-parse", "HEAD") or "UNKNOWN"
    branch = _git_field("rev-parse", "--abbrev-ref", "HEAD") or "p0/citizen-consolidation"

    if secret is None:
        secret = load_publisher_secret(_ensure_publisher_secret(package_assets_root()))

    staging_store = dest / "assets"
    if staging_store.exists():
        import shutil

        shutil.rmtree(staging_store)
    loader = AssetLoader(staging_store, secret)

    entries: list[dict[str, str]] = []
    genesis = package_assets_root() / "genesis"
    if genesis.is_dir():
        from .assets import install_from_genesis_dir

        entries.extend(install_from_genesis_dir(loader, genesis))

    grant = loader.install_payload(
        asset_id=HISTORY_DIGEST_GRANT_ASSET_ID,
        kind="capability_grant",
        version=UPDATE_VERSION,
        payload=grant_payload(source_commit=commit),
    )
    entries.append(
        {
            "asset_id": grant.asset_id,
            "kind": grant.kind,
            "content_hash": grant.content_hash,
            "version": grant.version,
        }
    )

    # UpdateEngine verify() looks for assets/<hash>/ under the package, but
    # AssetLoader writes to assets/<hash>/ at dest/assets. Move layout:
    # dest/assets already matches.
    manifest = default_seed_manifest(
        citizen_id="",
        asset_entries=entries,
        release=release,
    )
    manifest.citizen_version = UPDATE_VERSION
    manifest.runtime_version = RUNTIME_VERSION
    manifest.compatibility = COMPATIBILITY
    manifest = sign_manifest(manifest, secret)
    save_manifest(dest / "manifest.json", manifest)

    provenance = {
        "source_repository": "GRECOITALICO/CONRRAD-CITIZEN",
        "source_branch": branch,
        "source_commit": commit,
        "package_version": UPDATE_VERSION,
        "runtime_version": RUNTIME_VERSION,
        "release": release,
        "asset_version": manifest.asset_version,
        "grant_asset_id": HISTORY_DIGEST_GRANT_ASSET_ID,
        "grant_content_hash": grant.content_hash,
    }
    (dest / "PROVENANCE.json").write_text(
        json.dumps(provenance, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    # Deterministic package hash over the signed manifest bytes.
    artifact_sha256 = sha256_bytes((dest / "manifest.json").read_bytes())
    (dest / "ARTIFACT_SHA256").write_text(artifact_sha256 + "\n", encoding="utf-8")

    feed = {
        "update_available": True,
        "available": True,
        "version": UPDATE_VERSION,
        "release": release,
        "source": "local",
        "package_id": dest.name,
        "artifact_sha256": artifact_sha256,
        "source_commit": commit,
        "runtime_version": RUNTIME_VERSION,
    }
    return {
        "dest": str(dest),
        "manifest": manifest.to_dict(),
        "provenance": provenance,
        "artifact_sha256": artifact_sha256,
        "feed": feed,
    }


def write_local_feed(path: Path, feed: dict[str, Any]) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(feed, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def main() -> int:
    dest = package_assets_root() / "updates" / PACKAGE_ID
    result = pack_evolution(dest)
    write_local_feed(package_assets_root() / "updates" / "citizen-update.json", result["feed"])
    print(json.dumps({k: result[k] for k in ("dest", "artifact_sha256", "provenance")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
