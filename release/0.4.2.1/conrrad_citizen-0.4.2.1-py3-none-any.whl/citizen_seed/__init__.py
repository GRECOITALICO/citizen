"""Citizen 0.4 — Asset-First minimal Runtime.

The certified 0.1 source remains preserved in Git history and its historical
records.  This module is the new 0.4 source line; it is not a release claim.
Law: Runtime executes Assets only. No knowledge / planners / LLMs in Runtime.
"""

__version__ = "0.4.2"
RUNTIME_VERSION = "0.4.2"
PACKAGE_VERSION = "0.4.2.1"
COMPATIBILITY = "seed-2026.1"
SEED_RELEASE = "0.4"
SEED_STATUS = "source-line"

# Release provenance — maps installed package → exact source commit.
SOURCE_REPOSITORY = "GRECOITALICO/CONRRAD-CITIZEN"
SOURCE_BRANCH = "p0/citizen-consolidation"
# Code snapshot packaged as 0.4.2.1 (runtime 0.4.2, install ≠ Sync).
# Distinct from frozen public wheel A (SOURCE_COMMIT 73b29164).
SOURCE_COMMIT = "44246a3ffa9f789c40fe023a0d72a053dc08088b"

