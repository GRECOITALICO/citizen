"""citizen CLI — simple interface to CONRRAD Citizen.

Usage:
    citizen install     Birth + host provision + validate
    citizen start       Start the host service
    citizen stop        Stop the host service
    citizen restart     Restart the host service
    citizen status      Show compact status
    citizen sync        Remote sync with Cluster
    citizen update      Alias for sync
    citizen logs        Show service logs
    citizen serve       Run canonical Citizen server
    citizen work        Run evidence.integrity_digest work
    citizen uninstall   Remove service and optionally data
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from conrrad_citizen.host import USER_ACTION_REQUIRED, current_adapter


def _default_data_dir() -> Path:
    return Path(os.environ.get(
        "CITIZEN_DATA_DIR",
        Path.home() / ".local" / "share" / "conrrad-citizen",
    ))


def _default_citizen_home() -> Path:
    return Path(os.environ.get(
        "CITIZEN_HOME",
        _default_data_dir() / ".citizen",
    ))


def _ops_source() -> Path:
    """Location of bundled ops files inside the installed package."""
    return Path(__file__).resolve().parent / "_ops"


def _data_dir() -> Path:
    d = _default_data_dir()
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ensure_deployed(data_dir: Path) -> Path:
    """Deploy ops/ from package data to the data directory."""
    src = _ops_source()
    dst = data_dir / "ops"
    if not dst.exists():
        shutil.copytree(src, dst)
    else:
        # Always refresh web assets and living_server.py
        shutil.copy2(src / "living_server.py", dst / "living_server.py")
        life_src = src / "life.py"
        if life_src.is_file():
            shutil.copy2(life_src, dst / "life.py")
        dst_web = dst / "web"
        dst_web.mkdir(exist_ok=True)
        src_web = src / "web"
        if src_web.is_dir():
            for f in src_web.iterdir():
                if f.is_file():
                    shutil.copy2(f, dst_web / f.name)
    # Copy assets
    dst_assets = data_dir / "assets"
    src_assets = Path(__file__).resolve().parent / "_assets"
    if not dst_assets.exists() and src_assets.is_dir():
        shutil.copytree(src_assets, dst_assets)

    # Create runtime symlink so living_server.py can find citizen_seed
    runtime_dir = data_dir / "runtime"
    runtime_dir.mkdir(exist_ok=True)
    cs_link = runtime_dir / "citizen_seed"
    # Point to the installed citizen_seed package
    import citizen_seed
    cs_real = Path(citizen_seed.__file__).resolve().parent
    if cs_link.is_symlink() or cs_link.exists():
        if cs_link.is_symlink():
            cs_link.unlink()
        elif cs_link.is_dir():
            shutil.rmtree(cs_link)
    cs_link.symlink_to(cs_real)
    return data_dir


def _citizen_home() -> Path:
    return _default_citizen_home()


def _host():
    return current_adapter(data_dir=_default_data_dir(), home=_citizen_home())


# ── Subcommands ──────────────────────────────────────────────


def cmd_install(args: argparse.Namespace) -> int:
    """Host provision → Birth (or recognize) → boot → host start → health."""
    data_dir = _data_dir()
    home = _citizen_home()
    host = _host()
    guest = getattr(host, "guest_install", None)
    if callable(guest):
        print("== Citizen Install ==")
        print("host     : Windows / WSL2")
        out = guest()
        print(out.message)
        ui = (out.details or {}).get("ui") or host.network().get("ui")
        if ui:
            print(f"UI: {ui}")
        if out.state == USER_ACTION_REQUIRED:
            return 2
        return 0 if out.ok else 1

    print(f"== Citizen Install ==")
    print(f"data_dir : {data_dir}")
    print(f"home     : {home}")

    print("\n[1/5] Deploying ops assets...")
    _ensure_deployed(data_dir)
    print("  OK")

    print("\n[2/5] Provisioning host...")
    prov = host.provision()
    if not prov.ok:
        print(f"  Host: {prov.message} (use 'citizen serve' if no service)")
    else:
        print(f"  Host: {prov.message}")

    print("\n[3/5] Initializing Citizen identity and state...")
    os.environ["CITIZEN_HOME"] = str(home)
    from citizen_seed.installer import install, BootstrapDisarmed
    try:
        result = install(home=home)
        print(f"  Birth: {json.dumps(result, indent=2)}")
    except BootstrapDisarmed:
        print("  Already installed (idempotent).")

    print("\n[4/5] Booting Citizen runtime...")
    from citizen_seed.runtime import boot, BootError
    try:
        boot(home=home)
        print(f"  Boot: OK")
    except BootError as e:
        print(f"  Boot: {e} (may already be running)")

    print("\n[5/5] Starting host and validating...")
    if prov.ok:
        started = host.start()
        if started.state == USER_ACTION_REQUIRED:
            print(f"  {USER_ACTION_REQUIRED}: {started.message}")
        elif started.ok:
            print(f"  Host: {started.message}")
        else:
            print(f"  Host: {started.message} (use 'citizen serve')")
    health = host.wait_health()
    ready = health.ok
    if ready:
        print(f"  Living API: OK ({host.network()['ui']})")
    else:
        print(f"  Living API: not yet responding ({health.message})")

    version = _living_version(home)
    print("\nCitizen READY" if ready else "\nCitizen installed")
    print(f"Version: {version}")
    print(f"UI: {host.network()['ui']}")
    hint = _update_available_hint(version)
    if hint:
        print(hint)
    return 0


def _living_version(home: Path) -> str:
    try:
        from citizen_seed.updater import status
        return str(status(home=home).get("citizen_version") or "?")
    except Exception:
        return "?"


def _update_available_hint(current: str) -> str | None:
    """Read-only candidate notice. Does not apply Sync."""
    try:
        from citizen_seed.evolution_pack import UPDATE_VERSION
    except Exception:
        return None
    if not current or current == "?" or not UPDATE_VERSION or UPDATE_VERSION == current:
        return None
    return (
        f"Update available: {current} → {UPDATE_VERSION}\n"
        "Use 'citizen sync' to evolve."
    )


def cmd_start(args: argparse.Namespace) -> int:
    out = _host().start()
    print(out.message)
    if out.state == USER_ACTION_REQUIRED:
        return 2
    return 0 if out.ok else 1


def cmd_stop(args: argparse.Namespace) -> int:
    out = _host().stop()
    print(out.message)
    return 0 if out.ok else 1


def cmd_restart(args: argparse.Namespace) -> int:
    out = _host().restart()
    print(out.message)
    if out.state == USER_ACTION_REQUIRED:
        return 2
    return 0 if out.ok else 1


def cmd_status(args: argparse.Namespace) -> int:
    home = _citizen_home()
    if not home.exists():
        print("Citizen is not installed. Run 'citizen install' first.")
        return 1
    os.environ["CITIZEN_HOME"] = str(home)
    from citizen_seed.updater import status
    try:
        s = status(home=home)
    except Exception as e:
        s = {"error": str(e)}

    cid = s.get("citizen_id", "unknown")
    host = _host().status()

    import citizen_seed

    print(f"CITIZEN          : {s.get('citizen_version', '?')}")
    print(f"RUNTIME          : {s.get('runtime_version', citizen_seed.RUNTIME_VERSION)}")
    print(f"CITIZEN_ID       : {cid}")

    # Last sync
    sync_file = home / "ops" / "LAST_SYNC.json"
    ls = {}
    if sync_file.exists():
        import json as _json
        try:
            ls = _json.loads(sync_file.read_text())
        except Exception:
            pass

    print(f"ALIVE            : {ls.get('alive', '?')}")
    print(f"CONNECTED        : {ls.get('cluster', '?')}")

    # Heartbeat
    hb_file = home / "ops" / "heartbeat.jsonl"
    print(f"HEARTBEAT        : {'active' if hb_file.exists() else 'inactive'}")

    print(f"LAST_SYNC        : {ls.get('ts', '?')}")
    print(f"LATEST_EVOLUTION : {ls.get('evolution_evidence_id', '?')}")
    print(f"UPDATE_AVAILABLE : {s.get('update_available', '?')}")
    print(f"HOST             : {host.details.get('service', host.state)}")

    return 0


def cmd_sync(args: argparse.Namespace) -> int:
    home = _citizen_home()
    if not home.exists():
        print("Citizen is not installed. Run 'citizen install' first.")
        return 1
    os.environ["CITIZEN_HOME"] = str(home)
    from citizen_seed.updater import one_click_update
    result = one_click_update(home=home, updates_dir=None)
    print(json.dumps(result, indent=2))
    return 0


def cmd_logs(args: argparse.Namespace) -> int:
    out = _host().logs()
    if out.ok and out.message:
        print(out.message)
        return 0
    log = _citizen_home() / "ops" / "event_log.jsonl"
    if log.exists():
        print(log.read_text())
        return 0
    print("No logs found.")
    return 0


def cmd_uninstall(args: argparse.Namespace) -> int:
    print("== Citizen Uninstall ==")
    host = _host()
    removed = host.disable()
    print(f"  Host: {removed.message}")

    # Remove deployed data (ops, runtime symlink) but NOT Citizen home
    data_dir = _default_data_dir()
    ops_dir = data_dir / "ops"
    runtime_dir = data_dir / "runtime"
    for d in [ops_dir, runtime_dir]:
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)
            print(f"  Removed: {d}")

    home = _citizen_home()
    if home.exists():
        if args.purge:
            shutil.rmtree(home, ignore_errors=True)
            print(f"  Purged: {home}")
        else:
            print(f"  Preserved: {home} (use --purge to remove)")

    print("Citizen uninstalled.")
    print("Run 'pip uninstall conrrad-citizen' to remove the package.")
    return 0




def cmd_serve(args: argparse.Namespace) -> int:
    """Run the canonical public Citizen server (living_server)."""
    data_dir = _ensure_deployed(_data_dir())
    home = _citizen_home()
    os.environ["CITIZEN_HOME"] = str(home)
    os.environ["CITIZEN_DATA_DIR"] = str(data_dir)
    os.environ["CITIZEN_OPEN_BROWSER"] = "0" if getattr(args, "no_browser", False) else os.environ.get("CITIZEN_OPEN_BROWSER", "1")
    if getattr(args, "host", None):
        os.environ["CITIZEN_UI_HOST"] = args.host
    if getattr(args, "port", None):
        os.environ["CITIZEN_UI_PORT"] = str(args.port)

    # Prefer packaged module; fall back to deployed ops copy for systemd parity.
    try:
        from conrrad_citizen._ops import living_server as living_server
        return int(living_server.main([
            "--home", str(home),
            "--host", os.environ.get("CITIZEN_UI_HOST", "127.0.0.1"),
            "--port", os.environ.get("CITIZEN_UI_PORT", "3434"),
        ]) or 0)
    except Exception:
        script = data_dir / "ops" / "living_server.py"
        py = sys.executable
        env = os.environ.copy()
        env["PYTHONPATH"] = str(data_dir / "runtime") + os.pathsep + env.get("PYTHONPATH", "")
        return subprocess.call(
            [py, str(script), "--home", str(home),
             "--host", env.get("CITIZEN_UI_HOST", "127.0.0.1"),
             "--port", env.get("CITIZEN_UI_PORT", "3434")],
            env=env,
        )


def cmd_work(args: argparse.Namespace) -> int:
    """Run Work through the SAME engine as POST /api/work."""
    home = _citizen_home()
    os.environ["CITIZEN_HOME"] = str(home)
    from citizen_seed.work import submit_work

    out = submit_work(home, capability_id=args.capability)
    print(json.dumps(out, indent=2, default=str))
    return 0 if out.get("ok") else 1


# ── Entry point ──────────────────────────────────────────────


def main(argv: list[str] | None = None) -> int:
    os.environ["CITIZEN_DATA_DIR"] = str(_data_dir())
    import citizen_seed
    p = argparse.ArgumentParser(
        prog="citizen",
        description="CONRRAD Citizen — living digital organism",
    )
    p.add_argument(
        "--version", "-V", action="version",
        version=f"Citizen runtime {citizen_seed.RUNTIME_VERSION}",
    )
    sub = p.add_subparsers(dest="cmd")

    sub.add_parser("install", help="Install Citizen (birth + service + validate)")
    sub.add_parser("start", help="Start the Citizen service")
    sub.add_parser("stop", help="Stop the Citizen service")
    sub.add_parser("restart", help="Restart the Citizen host service")
    sub.add_parser("status", help="Show Citizen status")
    sub.add_parser("sync", help="Remote sync with CONRRAD Cluster")
    sub.add_parser("update", help="Alias for sync")
    sub.add_parser("logs", help="Show Citizen service logs")

    sv = sub.add_parser("serve", help="Run canonical Citizen server (living_server)")
    sv.add_argument("--host", default=os.environ.get("CITIZEN_UI_HOST", "127.0.0.1"))
    sv.add_argument("--port", type=int, default=int(os.environ.get("CITIZEN_UI_PORT", "3434")))
    sv.add_argument("--no-browser", action="store_true", help="Do not open a browser")

    wk = sub.add_parser("work", help="Run evidence.integrity_digest work")
    wk.add_argument(
        "--capability",
        default="evidence.integrity_digest",
        help="Capability id (default: evidence.integrity_digest)",
    )

    un = sub.add_parser("uninstall", help="Uninstall Citizen")
    un.add_argument("--purge", action="store_true",
                    help="Also remove identity and evidence data")

    args = p.parse_args(argv)

    if not args.cmd:
        p.print_help()
        return 0

    dispatch = {
        "install": cmd_install,
        "start": cmd_start,
        "stop": cmd_stop,
        "restart": cmd_restart,
        "status": cmd_status,
        "sync": cmd_sync,
        "update": cmd_sync,
        "logs": cmd_logs,
        "serve": cmd_serve,
        "work": cmd_work,
        "uninstall": cmd_uninstall,
    }
    fn = dispatch.get(args.cmd)
    if fn is None:
        p.print_help()
        return 1
    return fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
