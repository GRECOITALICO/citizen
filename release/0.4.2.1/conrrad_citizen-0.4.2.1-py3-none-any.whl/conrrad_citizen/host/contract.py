"""Platform-neutral host lifecycle contract.

HostAdapter owns process supervision, volumes, and network bind.
It does not own Birth, Work, Identity, Evidence, History, or Sync.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

USER_ACTION_REQUIRED = "USER_ACTION_REQUIRED"


@dataclass
class HostResult:
    ok: bool
    state: str
    message: str = ""
    details: dict[str, Any] = field(default_factory=dict)


class HostAdapter(Protocol):
    def provision(self) -> HostResult: ...
    def start(self) -> HostResult: ...
    def stop(self) -> HostResult: ...
    def restart(self) -> HostResult: ...
    def status(self) -> HostResult: ...
    def health(self) -> HostResult: ...
    def volume(self) -> dict[str, str]: ...
    def network(self) -> dict[str, str]: ...
