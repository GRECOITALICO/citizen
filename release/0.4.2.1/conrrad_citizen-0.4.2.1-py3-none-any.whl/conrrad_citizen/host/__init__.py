"""Host adapters: infrastructure only. Citizen owns life."""

from .contract import USER_ACTION_REQUIRED, HostAdapter, HostResult
from .linux import LinuxHostAdapter, intended_python
from .macos import MacHostAdapter
from .select import current_adapter
from .windows import WindowsHostAdapter

__all__ = [
    "USER_ACTION_REQUIRED",
    "HostAdapter",
    "HostResult",
    "LinuxHostAdapter",
    "WindowsHostAdapter",
    "MacHostAdapter",
    "current_adapter",
    "intended_python",
]
