"""Linux host adapter — systemd user unit and port ownership.

Does not mint identity, run Work, or apply Sync.
"""
from __future__ import annotations

import os
import pwd
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from .contract import USER_ACTION_REQUIRED, HostResult

UNIT_NAME = "citizen-seed-living.service"


def intended_python() -> str:
    """Exact Citizen runtime interpreter. Never `which python3`."""
    env = os.environ.get("CITIZEN_PYTHON", "").strip()
    if env:
        return env
    return sys.executable


def account_home() -> Path:
    """Login home from the account database. Ignores a test-overridden HOME."""
    try:
        return Path(pwd.getpwuid(os.getuid()).pw_dir)
    except Exception:
        return Path.home()


def session_unit_dir() -> Path:
    return account_home() / ".config" / "systemd" / "user"


def _unit_dir() -> Path:
    override = os.environ.get("CITIZEN_HOST_UNIT_DIR", "").strip()
    if override:
        return Path(override)
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    if xdg:
        return Path(xdg) / "systemd" / "user"
    return Path.home() / ".config" / "systemd" / "user"


class LinuxHostAdapter:
    def __init__(
        self,
        *,
        data_dir: Path,
        home: Path,
        host: str | None = None,
        port: str | int | None = None,
        python: str | None = None,
        unit_dir: Path | None = None,
        runner=None,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.home = Path(home)
        self.host = host or os.environ.get("CITIZEN_UI_HOST", "127.0.0.1")
        self.port = str(port or os.environ.get("CITIZEN_UI_PORT", "3434"))
        self.python = python or intended_python()
        self.unit_dir = Path(unit_dir) if unit_dir is not None else _unit_dir()
        self._injected_runner = runner is not None
        self._run = runner or _run

    def volume(self) -> dict[str, str]:
        return {
            "data_dir": str(self.data_dir),
            "home": str(self.home),
            "unit": str(self.unit_path()),
        }

    def network(self) -> dict[str, str]:
        return {
            "host": self.host,
            "port": self.port,
            "ui": f"http://{self.host}:{self.port}/",
        }

    def unit_path(self) -> Path:
        return self.unit_dir / UNIT_NAME

    def unit_text(self) -> str:
        script = self.data_dir / "ops" / "living_server.py"
        return f"""[Unit]
Description=CONRRAD Citizen
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={self.data_dir}
Environment=CITIZEN_HOME={self.home}
Environment=CITIZEN_UI_HOST={self.host}
Environment=CITIZEN_UI_PORT={self.port}
Environment=CITIZEN_OPEN_BROWSER=0
Environment=CITIZEN_PYTHON={self.python}
Environment=PYTHONPATH={self.data_dir / 'runtime'}
ExecStart={self.python} {script}
Restart=on-failure
RestartSec=8

[Install]
WantedBy=default.target
"""

    def provision(self) -> HostResult:
        self.unit_dir.mkdir(parents=True, exist_ok=True)
        self.unit_path().write_text(self.unit_text(), encoding="utf-8")
        sysd = self._systemctl("daemon-reload")
        if not sysd.ok:
            return self._host_unavailable(sysd, "provision") or HostResult(
                False, "FAILED", sysd.message, {"phase": "provision"}
            )
        enabled = self._systemctl("enable", UNIT_NAME)
        if not enabled.ok:
            return self._host_unavailable(enabled, "provision") or HostResult(
                False, "FAILED", enabled.message, {"phase": "provision"}
            )
        self._host_cmd(["loginctl", "enable-linger", os.environ.get("USER", "")], check=False)
        return HostResult(True, "PROVISIONED", "Linux host unit written", {
            "python": self.python,
            "unit": str(self.unit_path()),
        })

    def start(self) -> HostResult:
        occupied = self._port_conflict()
        if occupied is not None:
            return occupied
        healthy = self.health()
        if healthy.ok:
            return HostResult(True, "READY", "Already healthy", healthy.details)
        started = self._systemctl("start", UNIT_NAME)
        if not started.ok:
            return self._host_unavailable(started, "start") or HostResult(
                False, "FAILED", started.message, {"phase": "start"}
            )
        return HostResult(True, "STARTED", "Host service started", self.network())

    def stop(self) -> HostResult:
        st = self._systemctl("is-active", UNIT_NAME, check=False)
        active = (st.details.get("stdout") or "").strip() == "active"
        if not active:
            return HostResult(True, "STOPPED", "Already stopped")
        stopped = self._systemctl("stop", UNIT_NAME)
        if not stopped.ok:
            return HostResult(False, "FAILED", stopped.message, {"phase": "stop"})
        return HostResult(True, "STOPPED", "Host service stopped")

    def restart(self) -> HostResult:
        occupied = self._port_conflict()
        if occupied is not None:
            return occupied
        restarted = self._systemctl("restart", UNIT_NAME)
        if not restarted.ok:
            return HostResult(False, "FAILED", restarted.message, {"phase": "restart"})
        return HostResult(True, "STARTED", "Host service restarted", {
            "home": str(self.home),
            **self.network(),
        })

    def status(self) -> HostResult:
        st = self._systemctl("is-active", UNIT_NAME, check=False)
        active = (st.details.get("stdout") or "").strip()
        return HostResult(True, active or "unknown", "Host status", {
            "service": active or "unknown",
            "python": self.python,
            **self.volume(),
            **self.network(),
        })

    def health(self) -> HostResult:
        url = f"http://{self.host}:{self.port}/api/living"
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                if resp.status == 200:
                    return HostResult(True, "READY", "Living API reachable", {"url": url})
        except Exception:
            pass
        return HostResult(False, "FAILED", "Living API not reachable", {"url": url})

    def wait_health(self, attempts: int | None = None, delay: float | None = None) -> HostResult:
        if attempts is None:
            attempts = int(os.environ.get("CITIZEN_HOST_HEALTH_ATTEMPTS", "10"))
        if delay is None:
            delay = float(os.environ.get("CITIZEN_HOST_HEALTH_DELAY", "1.0"))
        last = self.health()
        for _ in range(max(attempts, 1)):
            last = self.health()
            if last.ok:
                return last
            time.sleep(delay)
        return last

    def logs(self) -> HostResult:
        r = self._host_cmd(
            ["journalctl", "--user", "-u", UNIT_NAME, "-n", "50", "--no-pager"],
            check=False,
        )
        if r.ok or r.details.get("returncode") == 0:
            return HostResult(True, "LOGS", r.details.get("stdout") or "")
        return HostResult(False, "FAILED", "journalctl unavailable")

    def disable(self) -> HostResult:
        self._systemctl("stop", UNIT_NAME, check=False)
        self._systemctl("disable", UNIT_NAME, check=False)
        path = self.unit_path()
        if path.exists():
            path.unlink()
        self._systemctl("daemon-reload", check=False)
        return HostResult(True, "REMOVED", "Host unit removed", {"unit": str(path)})

    def repair(self) -> HostResult:
        """Rewrite host unit if Python/paths drifted. Never touches Citizen home."""
        current = self.unit_path().read_text(encoding="utf-8") if self.unit_path().is_file() else ""
        needed = self.unit_text()
        if current == needed:
            return HostResult(True, "CURRENT", "Host unit already correct")
        return self.provision()

    def _port_conflict(self, *, ignore_our_service: bool = False) -> HostResult | None:
        pid = listener_pid(self.host, int(self.port))
        if pid is None:
            return None
        if ignore_our_service or self._pid_is_ours(pid):
            return None
        return HostResult(
            False,
            USER_ACTION_REQUIRED,
            f"Port {self.port} is in use by process {pid}, which is not this Citizen. "
            "Free the port or set CITIZEN_UI_PORT. The process was not stopped.",
            {"pid": pid, "port": self.port},
        )

    def _pid_is_ours(self, pid: int) -> bool:
        main = self._main_pid()
        if main is not None and int(main) == pid:
            return True
        try:
            cmd = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\x00", b" ").decode("utf-8", "replace")
        except OSError:
            return False
        tokens = cmd.split()
        ours = (
            "living_server" in cmd
            or "conrrad_citizen" in cmd
            or any(Path(token).name == "citizen" for token in tokens)
        )
        if not ours:
            return False
        if str(self.home) in cmd:
            return True
        try:
            env = Path(f"/proc/{pid}/environ").read_bytes()
        except OSError:
            return False
        return f"CITIZEN_HOME={self.home}".encode() in env

    def _main_pid(self) -> int | None:
        r = self._host_cmd(
            ["systemctl", "--user", "show", UNIT_NAME, "--property=MainPID", "--value"],
            check=False,
        )
        raw = (r.details.get("stdout") or "").strip()
        if raw.isdigit() and int(raw) > 0:
            return int(raw)
        return None

    def _is_session_unit_dir(self) -> bool:
        try:
            return self.unit_dir.resolve() == session_unit_dir().resolve()
        except OSError:
            return False

    def _host_cmd(self, cmd: list[str], *, check: bool = True) -> HostResult:
        if not self._injected_runner and not self._is_session_unit_dir():
            stdout = "inactive\n" if cmd[:3] == ["systemctl", "--user", "is-active"] else ""
            return HostResult(True, "OK", "", {
                "cmd": cmd,
                "stdout": stdout,
                "returncode": 0,
                "skipped": True,
            })
        return self._run(cmd, check=check)

    def _systemctl(self, *args: str, check: bool = True) -> HostResult:
        r = self._host_cmd(["systemctl", "--user", *args], check=check)
        if check and not r.ok:
            return HostResult(False, "FAILED", r.message, r.details)
        return r

    def _host_unavailable(self, result: HostResult, phase: str) -> HostResult | None:
        text = f"{result.message} {result.details.get('cmd', '')}".lower()
        if "no such file" not in text and "not found" not in text:
            return None
        return HostResult(
            False,
            "UNAVAILABLE",
            "systemd user bus unavailable; use 'citizen serve'",
            {"phase": phase, **result.details},
        )


def listener_pid(host: str, port: int) -> int | None:
    """PID listening on host:port, or None if the port is free / unknown."""
    if _port_free(host, port):
        return None
    r = subprocess.run(
        ["ss", "-ltnp", f"sport = :{port}"],
        capture_output=True,
        text=True,
    )
    text = (r.stdout or "") + (r.stderr or "")
    marker = "pid="
    if marker in text:
        try:
            return int(text.split(marker, 1)[1].split(",")[0])
        except (ValueError, IndexError):
            pass
    r = subprocess.run(["lsof", "-ti", f"tcp:{port}"], capture_output=True, text=True)
    pids = [p for p in (r.stdout or "").split() if p.isdigit()]
    if pids:
        return int(pids[0])
    return -1


def _port_free(host: str, port: int) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            return s.connect_ex((host, port)) != 0
    except OSError:
        return True


def _run(cmd: list[str], *, check: bool = True) -> HostResult:
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True)
    except FileNotFoundError as e:
        return HostResult(False, "FAILED", str(e), {"cmd": cmd})
    details = {
        "cmd": cmd,
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }
    if check and proc.returncode != 0:
        return HostResult(False, "FAILED", (proc.stderr or proc.stdout or "command failed").strip(), details)
    return HostResult(True, "OK", "", details)
