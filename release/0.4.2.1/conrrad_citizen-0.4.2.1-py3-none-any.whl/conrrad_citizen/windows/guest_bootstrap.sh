#!/bin/bash
# Guest host prep + citizen install. Not a second lifecycle engine.
set -euo pipefail
DATA='/home/citizen/.local/share/conrrad-citizen'
HOME='/home/citizen/.local/share/conrrad-citizen/.citizen'

if [ "$(id -u)" -eq 0 ]; then
  if ! id -u citizen >/dev/null 2>&1; then
    useradd -m -s /bin/bash citizen
  fi
  mkdir -p "$DATA/artifact" "$HOME"
  PY=$(command -v python3.12 || command -v python3.11 || command -v python3 || true)
  if [ -z "$PY" ]; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get install -y python3.11 python3.11-venv python3-pip curl ca-certificates
    PY=$(command -v python3.11 || command -v python3)
  fi
  "$PY" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 2)'
  if [ ! -x "$DATA/venv/bin/citizen" ]; then
    curl -fsSL 'https://raw.githubusercontent.com/GRECOITALICO/citizen/citizen-runtime-0.4.2/release/0.4.2/conrrad_citizen-0.4.2-py3-none-any.whl' -o "$DATA/artifact/conrrad_citizen-0.4.2-py3-none-any.whl"
    echo "0b4eb6d336352901e783f747bc5f2cc1775f0822ec1be17c145143ea6a4457ce  $DATA/artifact/conrrad_citizen-0.4.2-py3-none-any.whl" | sha256sum -c -
    "$PY" -m venv "$DATA/venv"
    "$DATA/venv/bin/pip" install --no-cache-dir "$DATA/artifact/conrrad_citizen-0.4.2-py3-none-any.whl"
  fi
  chown -R citizen:citizen /home/citizen
  printf 'CONRRAD-Citizen\n' > /etc/conrrad-citizen-managed
  grep -q 'CONRRAD-managed' /etc/wsl.conf 2>/dev/null || printf '\n# CONRRAD-managed=CONRRAD-Citizen\n[user]\ndefault=citizen\n' >> /etc/wsl.conf
  exec su -s /bin/bash citizen -c "CITIZEN_HOME='$HOME' CITIZEN_DATA_DIR='$DATA' CITIZEN_PYTHON='$DATA/venv/bin/python' CITIZEN_OPEN_BROWSER=0 '$DATA/venv/bin/citizen' install"
fi

PY=$(command -v python3.12 || command -v python3.11 || command -v python3)
"$PY" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 2)'
mkdir -p "$DATA/artifact" "$HOME"
if [ ! -x "$DATA/venv/bin/citizen" ]; then
  curl -fsSL 'https://raw.githubusercontent.com/GRECOITALICO/citizen/citizen-runtime-0.4.2/release/0.4.2/conrrad_citizen-0.4.2-py3-none-any.whl' -o "$DATA/artifact/conrrad_citizen-0.4.2-py3-none-any.whl"
  echo "0b4eb6d336352901e783f747bc5f2cc1775f0822ec1be17c145143ea6a4457ce  $DATA/artifact/conrrad_citizen-0.4.2-py3-none-any.whl" | sha256sum -c -
  "$PY" -m venv "$DATA/venv"
  "$DATA/venv/bin/pip" install --no-cache-dir "$DATA/artifact/conrrad_citizen-0.4.2-py3-none-any.whl"
fi
export CITIZEN_HOME="$HOME"
export CITIZEN_DATA_DIR="$DATA"
export CITIZEN_PYTHON="$DATA/venv/bin/python"
export CITIZEN_OPEN_BROWSER=0
"$DATA/venv/bin/citizen" install
