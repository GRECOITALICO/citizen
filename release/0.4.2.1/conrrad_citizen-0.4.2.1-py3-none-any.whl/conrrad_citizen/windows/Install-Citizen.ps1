# Thin Windows entry. Host logic lives in WindowsHostAdapter.
# One command: elevate if needed, enable WSL2, resume after reboot, provision
# CONRRAD-Citizen, then Birth. Not a second Citizen lifecycle engine.
param()
$ErrorActionPreference = "Stop"
$Distro = "CONRRAD-Citizen"
$RootfsName = "ubuntu-noble-wsl-amd64-24.04lts.rootfs.tar.gz"
$RootfsUrl = "https://cloud-images.ubuntu.com/wsl/releases/24.04/current/$RootfsName"
$SumsUrl = "https://cloud-images.ubuntu.com/wsl/releases/24.04/current/SHA256SUMS"
$StateDir = Join-Path $env:LOCALAPPDATA "CONRRAD\CitizenHost"
$StateFile = Join-Path $StateDir "bootstrap.json"
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null

function Test-IsElevated {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Write-HostState([string]$Phase, [bool]$Wsl2 = $false) {
    @{ phase = $Phase; distro = $Distro; wsl2 = $Wsl2 } | ConvertTo-Json | Set-Content $StateFile
}

function Register-ResumeAfterReboot {
    $cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce" -Force | Out-Null
    New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce" -Name "CONRRADCitizenHost" -Value $cmd -PropertyType String -Force | Out-Null
}

function Request-Elevation {
    Write-HostState "wsl_enable_requested"
    Write-Host "Requesting Administrator approval for WSL2 enablement."
    $arg = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    $p = Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $arg -Wait -PassThru
    if (-not $p) { exit 2 }
    exit $p.ExitCode
}

function Write-PendingReboot([string]$Message) {
    Write-HostState "wsl_pending_reboot" $false
    Register-ResumeAfterReboot
    Write-Host $Message
    Write-Host "After reboot, the same bootstrap resumes. No Citizen was born."
}

$wslMissing = -not (Get-Command wsl.exe -ErrorAction SilentlyContinue)
if ($wslMissing -and -not (Test-IsElevated)) {
    Request-Elevation
}

if ($wslMissing) {
    Write-HostState "wsl_enable_requested"
    Write-Host "Enabling WSL2. UAC may already have been granted."
    wsl.exe --install --no-distribution
    Write-PendingReboot "WSL2 enablement requires a reboot."
    exit 2
}

wsl.exe --status 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    if (-not (Test-IsElevated)) { Request-Elevation }
    Write-PendingReboot "WSL2 is not operational. Reboot if Windows requires it."
    exit 2
}

Write-HostState "wsl_ready" $false

# Windows-native `citizen` and Python are ignored. They are not Citizen's runtime.
# Citizen runs only inside the managed CONRRAD-Citizen WSL2 distro.

$list = (wsl.exe -l -v | Out-String)
if ($list -match [regex]::Escape($Distro) -and $list -match "$Distro\s+\S+\s+1(\s|$)") {
    Write-Host "$Distro is WSL1. Attempting in-place upgrade. Other distros are not changed."
    wsl.exe --set-version $Distro 2
}

if ($list -notmatch [regex]::Escape($Distro)) {
    Write-HostState "distro_provisioning" $false
    $dest = Join-Path $StateDir "distro"
    $rootfs = Join-Path $StateDir $RootfsName
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Write-Host "Fetching official Ubuntu SHA256SUMS."
    $sums = (Invoke-WebRequest -UseBasicParsing -Uri $SumsUrl).Content
    $expected = $null
    foreach ($line in ($sums -split "\r?\n")) {
        if ($line -match [regex]::Escape($RootfsName)) {
            $expected = ($line -split "\s+")[0].ToLower()
            break
        }
    }
    if (-not $expected) {
        Write-HostState "failed"
        Write-Host "Ubuntu SHA256SUMS did not list $RootfsName. Rootfs was not imported."
        exit 1
    }
    Write-Host "Downloading $RootfsName for $Distro."
    Invoke-WebRequest -UseBasicParsing -Uri $RootfsUrl -OutFile $rootfs
    $actual = (Get-FileHash -Algorithm SHA256 -Path $rootfs).Hash.ToLower()
    if ($actual -ne $expected) {
        Remove-Item -Force $rootfs
        Write-HostState "failed"
        Write-Host "Rootfs SHA256 mismatch vs official SHA256SUMS. File discarded. Not imported."
        exit 1
    }
    $bytes = [System.IO.File]::ReadAllBytes($rootfs)
    if ($bytes.Length -lt 2 -or $bytes[0] -ne 0x1F -or $bytes[1] -ne 0x8B) {
        Remove-Item -Force $rootfs
        Write-HostState "failed"
        Write-Host "Rootfs is not gzip tar as required by wsl --import. Not imported."
        exit 1
    }
    Write-Host "Provisioning $Distro as WSL2. Other WSL distributions are not changed."
    wsl.exe --import $Distro $dest $rootfs --version 2
}

Write-HostState "runtime_provisioning" $true
$script = Join-Path $PSScriptRoot "guest_bootstrap.sh"
Write-HostState "citizen_birth" $true
Get-Content -Raw $script | wsl.exe -d $Distro --exec /bin/bash -s
$code = $LASTEXITCODE
if ($code -eq 0) {
    Write-HostState "ready" $true
    Start-Process "http://127.0.0.1:3434/"
} else {
    Write-HostState "failed" $true
}
exit $code
