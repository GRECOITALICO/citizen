"""Updater — single button façade over Update Engine."""

from __future__ import annotations

import hashlib
import json
import shutil
import tarfile
import tempfile
import urllib.request
from pathlib import Path

from .crypto import load_publisher_secret
from .paths import layout
from .update_engine import UpdateEngine, UpdateState


def one_click_update(*, home: Path, updates_dir: Path | None = None) -> dict:
    """One-click UPDATE. States + Evidence owned by UpdateEngine."""
    home = Path(home).resolve()
    paths = layout(home)
    secret = load_publisher_secret(paths["runtime"] / "publisher.secret")
    engine = UpdateEngine(home, secret)
    updates = Path(updates_dir) if updates_dir else (_default_updates())
    final = engine.one_click(updates)
    return {
        "state": final.value,
        "citizen_home": str(home),
        "updates_dir": str(updates),
    }


def one_click_remote_update(*, home: Path, envelope_path: Path) -> dict:
    """Governed Remote Evolution: verify envelope → download → stage → inner verify → apply."""
    from .evolution_verifier import verify_descriptor_signature
    from .release_contract import ContractError

    home = Path(home).resolve()
    paths = layout(home)
    envelope_path = Path(envelope_path)

    # 1. Read envelope
    try:
        envelope = json.loads(envelope_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"state": "Error", "error": f"Cannot read envelope: {exc}"}

    # 2. Verify Ed25519 outer signature (fail-closed)
    from .terminal import write_sync_state
    write_sync_state(paths["ui_state"], "Verifying", color="orange")
    try:
        descriptor = verify_descriptor_signature(envelope)
    except ContractError as exc:
        return {"state": "Error", "error": f"Signature verification failed: {exc}"}

    # 3. Extract descriptor fields
    artifact_url = descriptor.get("artifact_url")
    artifact_sha256 = descriptor.get("artifact_sha256")
    to_version = descriptor.get("to_version")
    evolution_id = descriptor.get("evolution_id")
    min_version = descriptor.get("minimum_supported_version", "0.0.0")

    if not artifact_url or not artifact_sha256 or not to_version:
        return {"state": "Error", "error": "Descriptor missing required fields"}

    # 3b. Append optional SAS token from un-signed outer envelope if present
    sas_token = envelope.get("sas_token")
    if sas_token:
        sep = "&" if "?" in artifact_url else "?"
        # Ensure sas_token does not already start with ? or &
        sas_token = sas_token.lstrip("?&")
        artifact_url = f"{artifact_url}{sep}{sas_token}"

    # 4. Replay protection — check evolution history
    history_file = paths.get("updates", paths["home"] / "updates") / "evolution_history.jsonl"
    if history_file.is_file():
        for line in history_file.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
                if row.get("evolution_id") == evolution_id:
                    return {"state": "Current", "detail": f"Evolution {evolution_id} already applied"}
            except json.JSONDecodeError:
                continue

    # 5. Version compatibility check
    from . import RUNTIME_VERSION
    if RUNTIME_VERSION < min_version:
        return {"state": "Error", "error": f"Runtime {RUNTIME_VERSION} below minimum {min_version}"}

    # 6. Download artifact
    write_sync_state(paths["ui_state"], "Downloading", color="orange")
    staging_dir = paths.get("updates", paths["home"] / "updates") / "remote_staging"
    if staging_dir.exists():
        shutil.rmtree(staging_dir)
    staging_dir.mkdir(parents=True, exist_ok=True)

    tar_path = staging_dir / "artifact.tar.gz"
    try:
        req = urllib.request.Request(artifact_url, headers={"User-Agent": "CitizenSeed/0.3"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            tar_path.write_bytes(resp.read())
    except Exception as exc:
        return {"state": "Error", "error": f"Download failed: {exc}"}

    # 7. Verify SHA256
    actual_hash = hashlib.sha256(tar_path.read_bytes()).hexdigest()
    if actual_hash != artifact_sha256:
        return {"state": "Error", "error": f"SHA256 mismatch: expected {artifact_sha256}, got {actual_hash}"}

    # 8. Extract to staging
    extract_dir = staging_dir / "package"
    extract_dir.mkdir(parents=True, exist_ok=True)
    try:
        with tarfile.open(tar_path, "r:gz") as tf:
            tf.extractall(path=extract_dir, filter="data")
    except Exception as exc:
        return {"state": "Error", "error": f"Extraction failed: {exc}"}

    # 9. Delegate to existing inner update engine (HMAC verify + apply)
    # Find the manifest.json in the extracted package
    package_dir = extract_dir
    manifest_candidates = list(extract_dir.glob("**/manifest.json"))
    if manifest_candidates:
        # Use the first manifest's parent as the package dir
        package_dir = manifest_candidates[0].parent

    # Copy extracted package to updates dir so one_click can find it
    inner_updates = paths.get("updates", paths["home"] / "updates") / "governed"
    if inner_updates.exists():
        shutil.rmtree(inner_updates)
    inner_updates.mkdir(parents=True, exist_ok=True)
    target = inner_updates / to_version
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(package_dir, target)



    # Run the standard inner update engine
    secret = load_publisher_secret(paths["runtime"] / "publisher.secret")
    engine = UpdateEngine(home, secret)
    try:
        final = engine.one_click(inner_updates)
    except Exception as exc:
        return {"state": "Error", "error": f"Inner verification failed: {exc}"}

    # 10. Record evolution in history (replay protection)
    # Record for both UPDATED and CURRENT — either means the evolution was
    # successfully processed and must not be accepted again.
    if final in (UpdateState.UPDATED, UpdateState.CURRENT):
        history_file.parent.mkdir(parents=True, exist_ok=True)
        import time
        entry = {
            "evolution_id": evolution_id,
            "to_version": to_version,
            "artifact_sha256": artifact_sha256,
            "applied_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "signing_key_id": envelope.get("signing_key_id"),
        }
        with history_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    # Cleanup staging
    try:
        shutil.rmtree(staging_dir)
    except Exception:
        pass

    return {
        "state": final.value,
        "citizen_home": str(home),
        "evolution_id": evolution_id,
        "to_version": to_version,
    }


def status(*, home: Path) -> dict:
    home = Path(home).resolve()
    paths = layout(home)
    from .manifest import load_manifest, verify_manifest
    from .crypto import load_publisher_secret

    secret = load_publisher_secret(paths["runtime"] / "publisher.secret")
    m = load_manifest(paths["manifest"] / "current.json")
    return {
        "state": UpdateState.CURRENT.value,
        "manifest_ok": verify_manifest(m, secret),
        "citizen_version": m.citizen_version,
        "runtime_version": m.runtime_version,
        "asset_version": m.asset_version,
        "release": m.release,
        "citizen_id": m.citizen_id,
    }


def _default_updates() -> Path:
    from .paths import seed_root

    return seed_root() / "assets" / "updates"