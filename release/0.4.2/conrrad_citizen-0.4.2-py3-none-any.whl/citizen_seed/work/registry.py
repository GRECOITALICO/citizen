"""Minimal capability registry — not a marketplace."""
from __future__ import annotations

from typing import Any

CAPABILITY_ID = "evidence.integrity_digest"
CAPABILITY_VERSION = "1.0.0"
WORKER_ID = "evidence-worker"
IMPLEMENTATION_ID = "deterministic.sha256"
VALIDATOR_ID = "evidence.integrity_digest.validator"


def capability_spec() -> dict[str, Any]:
    return {
        "capability_id": CAPABILITY_ID,
        "version": CAPABILITY_VERSION,
        "name": "Evidence Integrity Digest",
        "input_schema": {
            "type": "object",
            "properties": {
                "source": {"type": "string", "enum": ["evidence.jsonl", "evidence/evidence.jsonl"]},
            },
            "required": ["source"],
        },
        "output_schema": {
            "type": "object",
            "properties": {
                "digest": {"type": "string"},
                "algorithm": {"type": "string"},
                "input_hash": {"type": "string"},
                "bytes": {"type": "integer"},
                "source": {"type": "string"},
            },
            "required": ["digest", "algorithm", "input_hash", "bytes"],
        },
        "implementation_id": IMPLEMENTATION_ID,
        "validator_id": VALIDATOR_ID,
        "worker_id": WORKER_ID,
    }


def local_registry() -> dict[str, dict[str, Any]]:
    return {CAPABILITY_ID: capability_spec()}


def resolve_capability(capability_id: str) -> dict[str, Any] | None:
    """capability_id → implementation_id → worker_id binding."""
    return local_registry().get(capability_id)
