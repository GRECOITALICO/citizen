"""P0.1 Work plane — capability → worker → implementation → validator → evidence → history."""

from .contracts import WorkRequest, WorkResult
from .engine import submit_work
from .registry import CAPABILITY_ID, IMPLEMENTATION_ID, VALIDATOR_ID, WORKER_ID, resolve_capability

__all__ = [
    "WorkRequest",
    "WorkResult",
    "submit_work",
    "resolve_capability",
    "CAPABILITY_ID",
    "WORKER_ID",
    "IMPLEMENTATION_ID",
    "VALIDATOR_ID",
]
