"""Smallest real WorkRequest / WorkResult contracts."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class WorkRequest:
    work_id: str
    citizen_id: str
    capability_id: str
    input: dict[str, Any]
    created_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class WorkResult:
    work_id: str
    citizen_id: str
    capability_id: str
    implementation_id: str
    status: str
    result: dict[str, Any]
    validator_result: dict[str, Any]
    created_at: str
    worker_id: str = ""
    input_hash: str = ""
    output_hash: str = ""
    evidence_ref: str | None = None
    history_ref: str | None = None
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
