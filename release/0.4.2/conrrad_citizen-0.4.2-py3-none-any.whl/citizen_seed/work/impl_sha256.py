"""Deterministic implementation: SHA-256 of the Citizen evidence ledger bytes.

Uses hashlib.sha256 on whole-file read. Validator must NOT import this module.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

IMPLEMENTATION_ID = "deterministic.sha256"


def evidence_path(home: Path) -> Path:
    return Path(home) / "evidence" / "evidence.jsonl"


def run(home: Path) -> dict[str, Any]:
    path = evidence_path(home)
    if not path.is_file():
        raise FileNotFoundError("EVIDENCE_MISSING: evidence/evidence.jsonl not found")
    payload = path.read_bytes()
    digest_hex = hashlib.sha256(payload).hexdigest()
    return {
        "digest": f"sha256:{digest_hex}",
        "algorithm": "sha256",
        "input_hash": digest_hex,
        "bytes": len(payload),
        "source": "evidence/evidence.jsonl",
        "source_present": True,
        "implementation_id": IMPLEMENTATION_ID,
    }
