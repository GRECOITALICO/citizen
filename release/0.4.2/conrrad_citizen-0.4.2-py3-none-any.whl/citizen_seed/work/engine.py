"""Work engine: request → capability → worker → impl → validator → evidence → history."""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from pathlib import Path
from typing import Any

from citizen_seed.evidence import append as evidence_append
from citizen_seed.identity import load as load_identity
from citizen_seed.paths import layout

from . import validator as work_validator
from .contracts import WorkRequest, WorkResult
from .history import append_history
from .registry import (
    CAPABILITY_ID,
    IMPLEMENTATION_ID,
    VALIDATOR_ID,
    WORKER_ID,
    resolve_capability,
)
from .worker import BLOCKED, COMPLETE, FAILED, EvidenceWorker, default_worker


def _utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _sha256_json(obj: Any) -> str:
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _citizen_id(home: Path) -> str:
    return load_identity(layout(home)["identity"]).citizen_id


def _validate_input(capability_id: str, input_payload: Any) -> tuple[bool, str]:
    if not capability_id or not isinstance(capability_id, str):
        return False, "INVALID_CAPABILITY_ID"
    if input_payload is None:
        input_payload = {"source": "evidence.jsonl"}
    if not isinstance(input_payload, dict):
        return False, "INVALID_INPUT"
    source = input_payload.get("source", "evidence.jsonl")
    if source not in {"evidence.jsonl", "evidence/evidence.jsonl"}:
        return False, "INVALID_INPUT_SOURCE"
    return True, ""


def submit_work(
    home: Path,
    *,
    capability_id: str = CAPABILITY_ID,
    input_payload: dict[str, Any] | None = None,
    worker: EvidenceWorker | None = None,
    force_worker_failure: bool = False,
    force_validator_reject: bool = False,
) -> dict[str, Any]:
    """Public Work entry for POST /api/work and CLI."""
    home = Path(home).resolve()
    created = _utc_now()

    ok_in, reason_in = _validate_input(capability_id, input_payload)
    if not ok_in:
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": reason_in,
            "capability_id": capability_id,
        }

    binding = resolve_capability(capability_id)
    if binding is None:
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": "UNKNOWN_CAPABILITY",
            "capability_id": capability_id,
        }

    try:
        citizen_id = _citizen_id(home)
    except FileNotFoundError:
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": "IDENTITY_MISSING",
            "capability_id": capability_id,
        }

    work_id = f"work_{uuid.uuid4().hex[:12]}"
    payload_in = dict(input_payload or {"source": "evidence.jsonl"})
    request = WorkRequest(
        work_id=work_id,
        citizen_id=citizen_id,
        capability_id=capability_id,
        input=payload_in,
        created_at=created,
    )

    implementation_id = str(binding["implementation_id"])
    validator_id = str(binding["validator_id"])
    worker_id = str(binding.get("worker_id") or WORKER_ID)
    worker = worker or default_worker()

    worker_out = worker.execute(
        home,
        request,
        implementation_id=implementation_id,
        force_failure=force_worker_failure,
    )

    if worker_out["status"] == FAILED:
        result = WorkResult(
            work_id=work_id,
            citizen_id=citizen_id,
            capability_id=capability_id,
            implementation_id=implementation_id,
            status=FAILED,
            result={},
            validator_result={
                "ok": False,
                "result": "SKIPPED",
                "validator_id": validator_id,
            },
            created_at=created,
            worker_id=worker_id,
            extras={"worker": worker_out},
        )
        href = append_history(
            home,
            {
                "plane": "canonical_work_history",
                "work_id": work_id,
                "citizen_id": citizen_id,
                "capability_id": capability_id,
                "implementation_id": implementation_id,
                "status": FAILED,
                "validator_result": result.validator_result,
                "result_ref": None,
                "timestamp": created,
                "error": worker_out.get("error"),
            },
        )
        evidence_append(
            layout(home)["evidence"],
            citizen_id=citizen_id,
            event_type="work_failed",
            payload={
                "work_id": work_id,
                "capability_id": capability_id,
                "implementation_id": implementation_id,
                "worker_id": worker_id,
                "error": worker_out.get("error"),
                "status": FAILED,
                "timestamp": created,
            },
        )
        return {
            "ok": False,
            "status": FAILED,
            "reason": "WORKER_FAILURE",
            "request": request.to_dict(),
            "result": result.to_dict(),
            "history_ref": str(href),
            "worker_id": worker_id,
            "capability": binding,
        }

    if worker_out["status"] == BLOCKED:
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": worker_out.get("error") or "WORKER_BLOCKED",
            "request": request.to_dict(),
            "worker_id": worker_id,
            "capability_id": capability_id,
        }

    candidate = dict(worker_out.get("result") or {})
    if force_validator_reject:
        candidate = {
            **candidate,
            "digest": "sha256:" + ("0" * 64),
            "input_hash": "0" * 64,
        }

    validation = work_validator.validate(home, candidate)
    status = COMPLETE if validation.get("ok") else "REJECTED"

    input_hash = str(candidate.get("input_hash") or "")
    output_hash = _sha256_json(candidate)

    evidence_dir = layout(home)["evidence"]
    envelope = evidence_append(
        evidence_dir,
        citizen_id=citizen_id,
        event_type="work_result",
        payload={
            "work_id": work_id,
            "capability_id": capability_id,
            "implementation_id": implementation_id,
            "worker_id": worker_id,
            "input_hash": input_hash,
            "output_hash": output_hash,
            "validator_id": validation.get("validator_id") or VALIDATOR_ID,
            "validator_result": validation,
            "status": status,
            "timestamp": created,
            "result": candidate if status == COMPLETE else None,
        },
    )
    evidence_ref = str(evidence_dir / "evidence.jsonl")

    result = WorkResult(
        work_id=work_id,
        citizen_id=citizen_id,
        capability_id=capability_id,
        implementation_id=implementation_id,
        status=status,
        result=candidate if status == COMPLETE else {},
        validator_result=validation,
        created_at=created,
        worker_id=worker_id,
        input_hash=input_hash,
        output_hash=output_hash,
        evidence_ref=evidence_ref,
        extras={"worker": worker_out, "evidence_envelope": envelope},
    )

    href = append_history(
        home,
        {
            "plane": "canonical_work_history",
            "work_id": work_id,
            "citizen_id": citizen_id,
            "capability_id": capability_id,
            "implementation_id": implementation_id,
            "status": status,
            "validator_result": validation,
            "result_ref": evidence_ref,
            "timestamp": created,
            "input_hash": input_hash,
            "output_hash": output_hash,
            "result": candidate if status == COMPLETE else None,
        },
    )
    result.history_ref = str(href)

    return {
        "ok": status == COMPLETE,
        "status": status,
        "request": request.to_dict(),
        "result": result.to_dict(),
        "capability": binding,
        "worker_id": worker_id,
        "implementation_id": implementation_id,
        "validator_id": validator_id,
        "history_ref": str(href),
        "evidence_ref": evidence_ref,
    }
