"""evidence-worker — executes a resolved implementation for a WorkRequest."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from .contracts import WorkRequest
from .registry import IMPLEMENTATION_ID, WORKER_ID

PENDING = "PENDING"
RUNNING = "RUNNING"
COMPLETE = "COMPLETE"
BLOCKED = "BLOCKED"
FAILED = "FAILED"


class EvidenceWorker:
    worker_id = WORKER_ID

    def __init__(self, implementations: dict[str, Callable[[Path], dict[str, Any]]]):
        self._implementations = implementations

    def execute(
        self,
        home: Path,
        request: WorkRequest,
        *,
        implementation_id: str,
        force_failure: bool = False,
    ) -> dict[str, Any]:
        if force_failure:
            return {
                "worker_id": self.worker_id,
                "status": FAILED,
                "implementation_id": implementation_id,
                "input": request.input,
                "error": "INDUCED_WORKER_FAILURE",
                "result": None,
            }

        impl = self._implementations.get(implementation_id)
        if impl is None:
            return {
                "worker_id": self.worker_id,
                "status": BLOCKED,
                "implementation_id": implementation_id,
                "input": request.input,
                "error": "UNKNOWN_IMPLEMENTATION",
                "result": None,
            }

        try:
            result = impl(home)
            return {
                "worker_id": self.worker_id,
                "status": COMPLETE,
                "implementation_id": implementation_id,
                "input": request.input,
                "result": result,
                "error": None,
            }
        except Exception as exc:  # noqa: BLE001
            return {
                "worker_id": self.worker_id,
                "status": FAILED,
                "implementation_id": implementation_id,
                "input": request.input,
                "result": None,
                "error": f"WORKER_EXCEPTION:{type(exc).__name__}:{exc}",
            }


def default_worker() -> EvidenceWorker:
    from . import impl_sha256

    return EvidenceWorker({IMPLEMENTATION_ID: impl_sha256.run})
