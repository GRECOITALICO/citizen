"""Citizen 0.4 — Asset-First minimal Runtime.

The certified 0.1 source remains preserved in Git history and its historical
records.  This module is the new 0.4 source line; it is not a release claim.
Law: Runtime executes Assets only. No knowledge / planners / LLMs in Runtime.
"""

__version__ = "0.4.2"
RUNTIME_VERSION = "0.4.2"
COMPATIBILITY = "seed-2026.1"
SEED_RELEASE = "0.4"
SEED_STATUS = "source-line"

# Release provenance — maps installed package → exact source commit.
SOURCE_REPOSITORY = "GRECOITALICO/CONRRAD-CITIZEN"
SOURCE_BRANCH = "p0/citizen-consolidation"
# Updated at release-cut by P0.2B; must match the published package commit.
SOURCE_COMMIT = "73b2916458e671e9537f80500fd9e15fe9a4465b"

