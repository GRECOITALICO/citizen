"""citizen CLI — simple interface to CONRRAD Citizen.

Usage:
    citizen install     Birth + systemd service + validate
    citizen start       Start the living service
    citizen stop        Stop the living service
    citizen status      Show compact status
    citizen sync        Remote sync with Cluster
    citizen update      Alias for sync
    citizen logs        Show service logs
    citizen serve       Run canonical Citizen server
    citizen work        Run evidence.integrity_digest work
    citizen uninstall   Remove service and optionally data
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


def _default_data_dir() -> Path:
    return Path(os.environ.get(
        "CITIZEN_DATA_DIR",
        Path.home() / ".local" / "share" / "conrrad-citizen",
    ))


def _default_citizen_home() -> Path:
    return Path(os.environ.get(
        "CITIZEN_HOME",
        _default_data_dir() / ".citizen",
    ))


def _ops_source() -> Path:
    """Location of bundled ops files inside the installed package."""
    return Path(__file__).resolve().parent / "_ops"


def _data_dir() -> Path:
    d = _default_data_dir()
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ensure_deployed(data_dir: Path) -> Path:
    """Deploy ops/ from package data to the data directory."""
    src = _ops_source()
    dst = data_dir / "ops"
    if not dst.exists():
        shutil.copytree(src, dst)
    else:
        # Always refresh web assets and living_server.py
        shutil.copy2(src / "living_server.py", dst / "living_server.py")
        dst_web = dst / "web"
        dst_web.mkdir(exist_ok=True)
        src_web = src / "web"
        if src_web.is_dir():
            for f in src_web.iterdir():
                if f.is_file():
                    shutil.copy2(f, dst_web / f.name)
    # Copy assets
    dst_assets = data_dir / "assets"
    src_assets = Path(__file__).resolve().parent / "_assets"
    if not dst_assets.exists() and src_assets.is_dir():
        shutil.copytree(src_assets, dst_assets)

    # Create runtime symlink so living_server.py can find citizen_seed
    runtime_dir = data_dir / "runtime"
    runtime_dir.mkdir(exist_ok=True)
    cs_link = runtime_dir / "citizen_seed"
    # Point to the installed citizen_seed package
    import citizen_seed
    cs_real = Path(citizen_seed.__file__).resolve().parent
    if cs_link.is_symlink() or cs_link.exists():
        if cs_link.is_symlink():
            cs_link.unlink()
        elif cs_link.is_dir():
            shutil.rmtree(cs_link)
    cs_link.symlink_to(cs_real)
    return data_dir


def _citizen_home() -> Path:
    return _default_citizen_home()


def _unit_name() -> str:
    return "citizen-seed-living.service"


# ── Subcommands ──────────────────────────────────────────────


def cmd_install(args: argparse.Namespace) -> int:
    """Birth + systemd service + validate."""
    data_dir = _data_dir()
    home = _citizen_home()

    print(f"== Citizen Install ==")
    print(f"data_dir : {data_dir}")
    print(f"home     : {home}")

    # 1. Deploy ops from package
    print("\n[1/6] Deploying ops assets...")
    _ensure_deployed(data_dir)
    print("  OK")

    # 2. Run citizen_seed install (idempotent — raises BootstrapDisarmed if done)
    print("\n[2/6] Initializing Citizen identity and state...")
    os.environ["CITIZEN_HOME"] = str(home)
    from citizen_seed.installer import install, BootstrapDisarmed
    try:
        result = install(home=home)
        print(f"  Birth: {json.dumps(result, indent=2)}")
    except BootstrapDisarmed:
        print("  Already installed (idempotent).")

    # 3. Boot
    print("\n[3/6] Booting Citizen runtime...")
    from citizen_seed.runtime import boot, BootError
    try:
        result = boot(home=home)
        print(f"  Boot: OK")
    except BootError as e:
        print(f"  Boot: {e} (may already be running)")

    # 4. Sync / update
    print("\n[4/6] Running initial sync...")
    from citizen_seed.updater import one_click_update
    try:
        result = one_click_update(home=home, updates_dir=None)
        print(f"  Sync: {result.get('state', 'unknown')}")
    except Exception as e:
        print(f"  Sync: {e} (non-fatal)")

    # 5. Install systemd service
    print("\n[5/6] Installing systemd user service...")
    rc = _install_systemd(data_dir, home)
    if rc == 0:
        print("  Service: installed and started")
    else:
        print("  Service: install failed (will run in foreground)")

    # 6. Validate
    print("\n[6/6] Validating...")
    _validate(home)

    print("\n== Citizen installed ==")
    print(f"UI: http://127.0.0.1:3434/")
    print(f"Run 'citizen status' to check health.")
    return 0


def _install_systemd(data_dir: Path, home: Path) -> int:
    """Install the systemd user service."""
    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_path = unit_dir / _unit_name()
    py = shutil.which("python3") or sys.executable
    host = os.environ.get("CITIZEN_UI_HOST", "127.0.0.1")
    port = os.environ.get("CITIZEN_UI_PORT", "3434")

    unit_content = f"""[Unit]
Description=Citizen 0.2 Living Runtime
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={data_dir}
Environment=CITIZEN_HOME={home}
Environment=CITIZEN_UI_HOST={host}
Environment=CITIZEN_UI_PORT={port}
Environment=CITIZEN_OPEN_BROWSER=0
Environment=PYTHONPATH={data_dir / 'runtime'}
ExecStart={py} {data_dir / 'ops' / 'living_server.py'}
Restart=on-failure
RestartSec=8

[Install]
WantedBy=default.target
"""
    unit_path.write_text(unit_content)
    try:
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=True,
                       capture_output=True)
        subprocess.run(["systemctl", "--user", "enable", _unit_name()], check=True,
                       capture_output=True)
        subprocess.run(["systemctl", "--user", "restart", _unit_name()], check=True,
                       capture_output=True)
        # Enable linger so service survives logout
        try:
            subprocess.run(["loginctl", "enable-linger", os.environ.get("USER", "")],
                           capture_output=True)
        except Exception:
            pass
        return 0
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"  WARN: systemd setup failed: {e}", file=sys.stderr)
        return 1


def _validate(home: Path) -> None:
    """Quick validation of the running Citizen."""
    import time
    import urllib.request
    host = os.environ.get("CITIZEN_UI_HOST", "127.0.0.1")
    port = os.environ.get("CITIZEN_UI_PORT", "3434")
    url = f"http://{host}:{port}/api/living"
    for i in range(10):
        try:
            with urllib.request.urlopen(url, timeout=2) as resp:
                if resp.status == 200:
                    print(f"  Living API: OK (http://{host}:{port}/)")
                    return
        except Exception:
            pass
        time.sleep(1)
    print(f"  Living API: not yet responding (service may still be starting)")


def cmd_start(args: argparse.Namespace) -> int:
    try:
        subprocess.run(["systemctl", "--user", "start", _unit_name()], check=True)
        print("Citizen started.")
        return 0
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"Failed to start: {e}", file=sys.stderr)
        return 1


def cmd_stop(args: argparse.Namespace) -> int:
    try:
        subprocess.run(["systemctl", "--user", "stop", _unit_name()], check=True)
        print("Citizen stopped.")
        return 0
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"Failed to stop: {e}", file=sys.stderr)
        return 1


def cmd_status(args: argparse.Namespace) -> int:
    home = _citizen_home()
    if not home.exists():
        print("Citizen is not installed. Run 'citizen install' first.")
        return 1
    os.environ["CITIZEN_HOME"] = str(home)
    from citizen_seed.updater import status
    try:
        s = status(home=home)
    except Exception as e:
        s = {"error": str(e)}

    # Service status
    svc = "unknown"
    try:
        r = subprocess.run(
            ["systemctl", "--user", "is-active", _unit_name()],
            capture_output=True, text=True,
        )
        svc = r.stdout.strip()
    except Exception:
        pass

    # Identity
    cid = s.get("citizen_id", "unknown")

    print(f"VERSION          : {s.get('version', s.get('citizen_version', '?'))}")
    print(f"CITIZEN_ID       : {cid}")

    # Last sync
    sync_file = home / "ops" / "LAST_SYNC.json"
    ls = {}
    if sync_file.exists():
        import json as _json
        try:
            ls = _json.loads(sync_file.read_text())
        except Exception:
            pass

    print(f"ALIVE            : {ls.get('alive', '?')}")
    print(f"CONNECTED        : {ls.get('cluster', '?')}")

    # Heartbeat
    hb_file = home / "ops" / "heartbeat.jsonl"
    print(f"HEARTBEAT        : {'active' if hb_file.exists() else 'inactive'}")

    print(f"LAST_SYNC        : {ls.get('ts', '?')}")
    print(f"CURRENT_VERSION  : {s.get('current_version', s.get('citizen_version', '?'))}")
    print(f"LATEST_EVOLUTION : {ls.get('evolution_evidence_id', '?')}")
    print(f"UPDATE_AVAILABLE : {s.get('update_available', '?')}")

    return 0


def cmd_sync(args: argparse.Namespace) -> int:
    home = _citizen_home()
    if not home.exists():
        print("Citizen is not installed. Run 'citizen install' first.")
        return 1
    os.environ["CITIZEN_HOME"] = str(home)
    from citizen_seed.updater import one_click_update
    result = one_click_update(home=home, updates_dir=None)
    print(json.dumps(result, indent=2))
    return 0


def cmd_logs(args: argparse.Namespace) -> int:
    try:
        subprocess.run(
            ["journalctl", "--user", "-u", _unit_name(), "-n", "50", "--no-pager"],
            check=False,
        )
        return 0
    except FileNotFoundError:
        # Fallback: read ops event_log
        log = _citizen_home() / "ops" / "event_log.jsonl"
        if log.exists():
            print(log.read_text())
        else:
            print("No logs found.")
        return 0


def cmd_uninstall(args: argparse.Namespace) -> int:
    print("== Citizen Uninstall ==")
    # 1. Stop and disable service
    try:
        subprocess.run(["systemctl", "--user", "stop", _unit_name()],
                       capture_output=True)
        subprocess.run(["systemctl", "--user", "disable", _unit_name()],
                       capture_output=True)
    except Exception:
        pass

    # 2. Remove unit file
    unit = Path.home() / ".config" / "systemd" / "user" / _unit_name()
    if unit.exists():
        unit.unlink()
        print(f"  Removed: {unit}")
    try:
        subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True)
    except Exception:
        pass

    # 3. Remove deployed data (ops, runtime symlink) but NOT .citizen
    data_dir = _default_data_dir()
    ops_dir = data_dir / "ops"
    runtime_dir = data_dir / "runtime"
    for d in [ops_dir, runtime_dir]:
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)
            print(f"  Removed: {d}")

    home = _citizen_home()
    if home.exists():
        if args.purge:
            shutil.rmtree(home, ignore_errors=True)
            print(f"  Purged: {home}")
        else:
            print(f"  Preserved: {home} (use --purge to remove)")

    print("Citizen uninstalled.")
    print("Run 'pip uninstall conrrad-citizen' to remove the package.")
    return 0




def cmd_serve(args: argparse.Namespace) -> int:
    """Run the canonical public Citizen server (living_server)."""
    data_dir = _ensure_deployed(_data_dir())
    home = _citizen_home()
    os.environ["CITIZEN_HOME"] = str(home)
    os.environ["CITIZEN_DATA_DIR"] = str(data_dir)
    os.environ["CITIZEN_OPEN_BROWSER"] = "0" if getattr(args, "no_browser", False) else os.environ.get("CITIZEN_OPEN_BROWSER", "1")
    if getattr(args, "host", None):
        os.environ["CITIZEN_UI_HOST"] = args.host
    if getattr(args, "port", None):
        os.environ["CITIZEN_UI_PORT"] = str(args.port)

    # Prefer packaged module; fall back to deployed ops copy for systemd parity.
    try:
        from conrrad_citizen._ops import living_server as living_server
        return int(living_server.main([
            "--home", str(home),
            "--host", os.environ.get("CITIZEN_UI_HOST", "127.0.0.1"),
            "--port", os.environ.get("CITIZEN_UI_PORT", "3434"),
        ]) or 0)
    except Exception:
        script = data_dir / "ops" / "living_server.py"
        py = sys.executable
        env = os.environ.copy()
        env["PYTHONPATH"] = str(data_dir / "runtime") + os.pathsep + env.get("PYTHONPATH", "")
        return subprocess.call(
            [py, str(script), "--home", str(home),
             "--host", env.get("CITIZEN_UI_HOST", "127.0.0.1"),
             "--port", env.get("CITIZEN_UI_PORT", "3434")],
            env=env,
        )


def cmd_work(args: argparse.Namespace) -> int:
    """Run Work through the SAME engine as POST /api/work."""
    home = _citizen_home()
    os.environ["CITIZEN_HOME"] = str(home)
    from citizen_seed.work import submit_work

    out = submit_work(home, capability_id=args.capability)
    print(json.dumps(out, indent=2, default=str))
    return 0 if out.get("ok") else 1


# ── Entry point ──────────────────────────────────────────────


def main(argv: list[str] | None = None) -> int:
    os.environ["CITIZEN_DATA_DIR"] = str(_data_dir())
    import citizen_seed
    p = argparse.ArgumentParser(
        prog="citizen",
        description="CONRRAD Citizen — living digital organism",
    )
    p.add_argument(
        "--version", "-V", action="version",
        version=(
            f"citizen {citizen_seed.__version__} "
            f"({getattr(citizen_seed, 'SOURCE_COMMIT', 'unknown')[:12]})"
        ),
    )
    sub = p.add_subparsers(dest="cmd")

    sub.add_parser("install", help="Install Citizen (birth + service + validate)")
    sub.add_parser("start", help="Start the Citizen service")
    sub.add_parser("stop", help="Stop the Citizen service")
    sub.add_parser("status", help="Show Citizen status")
    sub.add_parser("sync", help="Remote sync with CONRRAD Cluster")
    sub.add_parser("update", help="Alias for sync")
    sub.add_parser("logs", help="Show Citizen service logs")

    sv = sub.add_parser("serve", help="Run canonical Citizen server (living_server)")
    sv.add_argument("--host", default=os.environ.get("CITIZEN_UI_HOST", "127.0.0.1"))
    sv.add_argument("--port", type=int, default=int(os.environ.get("CITIZEN_UI_PORT", "3434")))
    sv.add_argument("--no-browser", action="store_true", help="Do not open a browser")

    wk = sub.add_parser("work", help="Run evidence.integrity_digest work")
    wk.add_argument(
        "--capability",
        default="evidence.integrity_digest",
        help="Capability id (default: evidence.integrity_digest)",
    )

    un = sub.add_parser("uninstall", help="Uninstall Citizen")
    un.add_argument("--purge", action="store_true",
                    help="Also remove identity and evidence data")

    args = p.parse_args(argv)

    if not args.cmd:
        p.print_help()
        return 0

    dispatch = {
        "install": cmd_install,
        "start": cmd_start,
        "stop": cmd_stop,
        "status": cmd_status,
        "sync": cmd_sync,
        "update": cmd_sync,
        "logs": cmd_logs,
        "serve": cmd_serve,
        "work": cmd_work,
        "uninstall": cmd_uninstall,
    }
    fn = dispatch.get(args.cmd)
    if fn is None:
        p.print_help()
        return 1
    return fn(args)


if __name__ == "__main__":
    raise SystemExit(main())
