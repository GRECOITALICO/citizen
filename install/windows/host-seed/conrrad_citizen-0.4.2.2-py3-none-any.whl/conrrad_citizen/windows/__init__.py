"""Windows host bootstrap assets. Not Citizen life."""
