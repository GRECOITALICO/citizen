"""Windows bootstrap resume and distro idempotency. Architecture for tests.

A previous incomplete installation is state to recover, not something to erase.
ERROR_ALREADY_EXISTS is DISTRO_ALREADY_PRESENT, not PROVISION_FAILED.
Missing schtasks is TASK_ALREADY_ABSENT, not failure.
"""
from __future__ import annotations

ERROR_ALREADY_EXISTS = "Wsl/Service/RegisterDistro/ERROR_ALREADY_EXISTS"
TASK_NOT_FOUND_EN = "The system cannot find the file specified"
TASK_NOT_FOUND_ES = "No se puede encontrar el archivo especificado"

KNOWN_MANAGED_DISTRO = "KNOWN_MANAGED_DISTRO"
UNKNOWN_DISTRO = "UNKNOWN_DISTRO"
DISTRO_ABSENT = "ABSENT"

NO_INSTALLATION = "NO_INSTALLATION"
MANAGED_INSTALL_IN_PROGRESS = "MANAGED_INSTALL_IN_PROGRESS"
MANAGED_INSTALL_READY = "MANAGED_INSTALL_READY"
MANAGED_INSTALL_BROKEN = "MANAGED_INSTALL_BROKEN"
UNKNOWN_LEGACY_INSTALLATION = "UNKNOWN_LEGACY_INSTALLATION"

IMPORT = "IMPORT"
SKIP = "SKIP"
DISTRO_ALREADY_PRESENT = "DISTRO_ALREADY_PRESENT"
IMPORT_FAILED = "IMPORT_FAILED"

TASK_EXISTS = "EXISTS"
TASK_MISSING = "MISSING"
TASK_STALE = "STALE"
TASK_RUNNING = "RUNNING"
TASK_NOT_REQUIRED = "NOT_REQUIRED"
TASK_REMOVED = "TASK_REMOVED"
TASK_ALREADY_ABSENT = "TASK_ALREADY_ABSENT"
TASK_DELETE_FAILED = "TASK_DELETE_FAILED"

UNRECOVERABLE_WHAT = (
    "Citizen found an existing managed Linux environment that could not be "
    "recovered automatically."
)
OWNERSHIP_WHAT = (
    "Citizen found a WSL distribution named CONRRAD-Citizen that it does not own."
)
SAFE_DID_NOT = (
    "Citizen did not create a Citizen.\n"
    "Citizen did not modify unrelated WSL distributions.\n"
    "Citizen did not unregister the existing distribution."
)


def normalize_wsl_list(text: str) -> str:
    """WSL -l -v is UTF-16; PowerShell often injects NUL bytes."""
    return (text or "").replace("\x00", "")


def distro_listed(list_text: str, distro: str = "CONRRAD-Citizen") -> bool:
    blob = normalize_wsl_list(list_text)
    return distro in blob


def import_decision(*, distro_present: bool) -> str:
    return SKIP if distro_present else IMPORT


def classify_import_result(
    *,
    distro_present_before: bool,
    stderr: str = "",
    exit_code: int = 0,
) -> str:
    if distro_present_before:
        return DISTRO_ALREADY_PRESENT
    blob = stderr or ""
    if ERROR_ALREADY_EXISTS in blob or "ERROR_ALREADY_EXISTS" in blob:
        return DISTRO_ALREADY_PRESENT
    if exit_code == 0:
        return "IMPORTED"
    return IMPORT_FAILED


def classify_distro_ownership(
    *,
    name_present: bool,
    host_bootstrap_ours: bool = False,
    dest_vhdx_present: bool = False,
    guest_managed_marker: bool = False,
) -> str:
    if not name_present:
        return DISTRO_ABSENT
    if host_bootstrap_ours or dest_vhdx_present or guest_managed_marker:
        return KNOWN_MANAGED_DISTRO
    return UNKNOWN_DISTRO


def classify_install(
    *,
    legacy_volume: bool = False,
    known_citizen: bool = False,
    ownership: str = DISTRO_ABSENT,
    host_bootstrap_ours: bool = False,
    volume_nonempty: bool = False,
    operational: bool | None = None,
) -> str:
    if known_citizen:
        return MANAGED_INSTALL_READY
    if ownership == UNKNOWN_DISTRO:
        return UNKNOWN_DISTRO
    if legacy_volume and not host_bootstrap_ours and not known_citizen:
        return UNKNOWN_LEGACY_INSTALLATION
    if ownership == KNOWN_MANAGED_DISTRO or host_bootstrap_ours:
        if operational is False:
            return MANAGED_INSTALL_BROKEN
        if known_citizen:
            return MANAGED_INSTALL_READY
        return MANAGED_INSTALL_IN_PROGRESS
    if volume_nonempty and not host_bootstrap_ours and not known_citizen:
        return UNKNOWN_LEGACY_INSTALLATION
    return NO_INSTALLATION


def distro_action(ownership: str) -> str:
    if ownership == DISTRO_ABSENT:
        return IMPORT
    if ownership == KNOWN_MANAGED_DISTRO:
        return SKIP
    return "STOP"


def classify_schtasks_delete(*, exit_code: int, stderr: str = "", stdout: str = "") -> str:
    if exit_code == 0:
        return TASK_REMOVED
    blob = f"{stderr} {stdout}"
    lower = blob.lower()
    if (
        TASK_NOT_FOUND_EN.lower() in lower
        or TASK_NOT_FOUND_ES.lower() in lower
        or "cannot find the file specified" in lower
        or "no se puede encontrar el archivo" in lower
        or "cannot find the path specified" in lower
        or "does not exist" in lower
    ):
        return TASK_ALREADY_ABSENT
    return TASK_DELETE_FAILED


def cleanup_is_fatal(task_result: str) -> bool:
    return task_result == TASK_DELETE_FAILED


def resume_skips_import(*, distro_present: bool, reboot_resume: bool = False) -> bool:
    if distro_present:
        return True
    return False


def host_bootstrap_is_ours(
    *,
    distro: str | None = None,
    bootstrap_url: str | None = None,
    managed_distro_registered: bool = False,
    expected_distro: str = "CONRRAD-Citizen",
) -> bool:
    if managed_distro_registered:
        return True
    if distro and distro == expected_distro:
        return True
    url = bootstrap_url or ""
    if "citizen-windows-wsl2" in url:
        return True
    return False


def resume_next_phase(*, prior_phase: str, distro_present: bool) -> str:
    if prior_phase in {"REBOOT_REQUIRED", "RESUMING"}:
        if distro_present:
            return "VERIFYING_WSL"
        return "PROVISIONING_WSL"
    if prior_phase in {"PROVISIONING", "PROVISIONING_WSL"} and distro_present:
        return "VERIFYING_WSL"
    return prior_phase or "PREFLIGHT"
