"""Managed WSL distro readiness — capability, not systemd user-session health.

A WSL warning is not automatically a product failure.

Citizen runtime lives in the managed Linux environment (podman).
Host Windows does not manage Citizen with systemd.
WSL systemd user-session for root is not a hard product dependency.

SYSTEMD_PRODUCT_REQUIREMENT=FALSE
"""
from __future__ import annotations

from dataclasses import dataclass, field

SYSTEMD_USER_SESSION_SNIPPET = "Failed to start the systemd user session"
REAL_WINDOWS_SYSTEMD_ROOT_WARNING = (
    "wsl: Failed to start the systemd user session for 'root'.\n"
    "See journalctl for more details."
)

STDERR_SYSTEMD_USER_SESSION_WARNING = "SYSTEMD_USER_SESSION_WARNING"
STDERR_CREATE_PROCESS_FAILURE = "CREATE_PROCESS_FAILURE"
STDERR_FILESYSTEM_FAILURE = "FILESYSTEM_FAILURE"
STDERR_BIN_EXEC_FAILURE = "BIN_EXEC_FAILURE"
STDERR_UNKNOWN = "UNKNOWN"

TOKEN_READY = "READY"
TOKEN_BASH_OK = "BASH_OK"
TOKEN_FS_OK = "FS_OK"
TOKEN_USER_OK = "USER_OK"
TOKEN_ENGINE_OK = "ENGINE_OK"
TOKEN_ROOTLESS_OK = "ROOTLESS_OK"
TOKEN_NET_OK = "NET_OK"

SAFE_FAIL_WHAT = "Citizen could not start its managed Linux environment."
SAFE_FAIL_DID_NOT = (
    "Citizen did not create a Citizen.\n"
    "Citizen did not modify unrelated WSL distributions."
)


@dataclass(frozen=True)
class ProbeResult:
    name: str
    exit_code: int
    stdout: str = ""
    stderr: str = ""


@dataclass
class ReadinessReport:
    ok: bool
    fatal: bool
    should_import: bool
    should_create_managed_user: bool
    WSL_PROBE: str = ""
    WSL_PROBE_EXIT_CODE: int | None = None
    WSL_PROBE_STDERR_CLASS: str = ""
    WSL_EXECUTION: str = ""
    SYSTEMD_USER_SESSION: str = ""
    FILESYSTEM_PROBE: str = ""
    BASH_PROBE: str = ""
    CONTAINER_ENGINE_PROBE: str = ""
    NETWORK_PROBE: str = ""
    MANAGED_USER_PROBE: str = ""
    SYSTEMD_PRODUCT_REQUIREMENT: str = "FALSE"
    failure_class: str = ""
    diagnostics: dict[str, str] = field(default_factory=dict)


def classify_wsl_stderr(stderr: str) -> str:
    text = stderr or ""
    if not text.strip():
        return ""
    lower = text.lower()
    if "createprocess" in lower or "0xc0000142" in lower or "wsl_e_" in lower:
        return STDERR_CREATE_PROCESS_FAILURE
    if "exec format error" in lower or "cannot execute" in lower:
        return STDERR_BIN_EXEC_FAILURE
    if "read-only file system" in lower or "no space left on device" in lower:
        return STDERR_FILESYSTEM_FAILURE
    if SYSTEMD_USER_SESSION_SNIPPET in text:
        return STDERR_SYSTEMD_USER_SESSION_WARNING
    if "no such file or directory" in lower:
        return STDERR_BIN_EXEC_FAILURE
    return STDERR_UNKNOWN


def _has_token(stdout: str, token: str) -> bool:
    return token in (stdout or "")


def _record(report: ReadinessReport, probe: ProbeResult) -> None:
    report.WSL_PROBE = probe.name
    report.WSL_PROBE_EXIT_CODE = int(probe.exit_code)
    report.WSL_PROBE_STDERR_CLASS = classify_wsl_stderr(probe.stderr)


def _systemd_state(probes: list[ProbeResult]) -> str:
    if any(classify_wsl_stderr(p.stderr) == STDERR_SYSTEMD_USER_SESSION_WARNING for p in probes if p):
        return "DEGRADED"
    return "OK"


def bin_true_is_fatal(probe: ProbeResult) -> bool:
    """True only when /bin/true itself could not execute.

    SYSTEMD_USER_SESSION_WARNING is not fatal. Confirm with later probes.
    Unknown or non-zero wrapper exit is not fatal by itself; bash READY is
    the execution proof.
    """
    cls = classify_wsl_stderr(probe.stderr)
    return cls in (
        STDERR_CREATE_PROCESS_FAILURE,
        STDERR_BIN_EXEC_FAILURE,
        STDERR_FILESYSTEM_FAILURE,
    )


def execution_available_from_bin_true(probe: ProbeResult) -> bool:
    return not bin_true_is_fatal(probe)


def systemd_warning_is_not_automatic_failure(
    stderr: str,
    *,
    exit_code: int,
    command_succeeded: bool,
) -> bool:
    """Regression: the exact Windows 0.4.2.4 stderr must not auto-fail success."""
    cls = classify_wsl_stderr(stderr)
    if command_succeeded:
        return True
    if cls == STDERR_SYSTEMD_USER_SESSION_WARNING and not bin_true_is_fatal(
        ProbeResult("bin_true", exit_code, "", stderr)
    ):
        return True
    return False


def import_decision(distro_present: bool) -> str:
    """Reuse an already-imported managed distro. Never duplicate import."""
    return "SKIP" if distro_present else "IMPORT"


def evaluate_managed_distro_operational(
    *,
    distro_present: bool,
    bin_true: ProbeResult | None = None,
    bash_ready: ProbeResult | None = None,
    bash_exec: ProbeResult | None = None,
    ident: ProbeResult | None = None,
    filesystem: ProbeResult | None = None,
    managed_user: ProbeResult | None = None,
    container_engine: ProbeResult | None = None,
    rootless: ProbeResult | None = None,
    network: ProbeResult | None = None,
    stage: str = "pre_guest",
) -> ReadinessReport:
    report = ReadinessReport(
        ok=False,
        fatal=False,
        should_import=not distro_present,
        should_create_managed_user=False,
    )
    if not distro_present:
        report.ok = True
        report.WSL_EXECUTION = ""
        return report

    seen: list[ProbeResult] = []

    if bin_true is None:
        report.fatal = True
        report.failure_class = "BIN_EXEC_FAILURE"
        report.WSL_EXECUTION = "UNAVAILABLE"
        return report
    seen.append(bin_true)
    _record(report, bin_true)
    if bin_true_is_fatal(bin_true):
        report.fatal = True
        report.WSL_EXECUTION = "UNAVAILABLE"
        report.SYSTEMD_USER_SESSION = _systemd_state(seen)
        report.failure_class = classify_wsl_stderr(bin_true.stderr) or "BIN_EXEC_FAILURE"
        return report

    if bash_ready is None:
        report.fatal = True
        report.WSL_EXECUTION = "UNAVAILABLE"
        report.SYSTEMD_USER_SESSION = _systemd_state(seen)
        report.failure_class = "BIN_EXEC_FAILURE"
        report.BASH_PROBE = "FAIL"
        return report
    seen.append(bash_ready)
    _record(report, bash_ready)
    if not _has_token(bash_ready.stdout, TOKEN_READY):
        report.fatal = True
        report.WSL_EXECUTION = "UNAVAILABLE"
        report.SYSTEMD_USER_SESSION = _systemd_state(seen)
        report.BASH_PROBE = "FAIL"
        report.failure_class = classify_wsl_stderr(bash_ready.stderr) or "BIN_EXEC_FAILURE"
        return report
    report.BASH_PROBE = "PASS"
    report.WSL_EXECUTION = "AVAILABLE"
    report.SYSTEMD_USER_SESSION = _systemd_state(seen)

    if bash_exec is not None:
        seen.append(bash_exec)
        _record(report, bash_exec)
        if not _has_token(bash_exec.stdout, TOKEN_BASH_OK):
            report.fatal = True
            report.WSL_EXECUTION = "UNAVAILABLE"
            report.BASH_PROBE = "FAIL"
            report.SYSTEMD_USER_SESSION = _systemd_state(seen)
            report.failure_class = classify_wsl_stderr(bash_exec.stderr) or "BIN_EXEC_FAILURE"
            return report

    if ident is not None:
        seen.append(ident)
        _record(report, ident)
        if "uid=" not in (ident.stdout or "") and not (ident.stdout or "").strip().isdigit():
            report.fatal = True
            report.WSL_EXECUTION = "UNAVAILABLE"
            report.SYSTEMD_USER_SESSION = _systemd_state(seen)
            report.failure_class = classify_wsl_stderr(ident.stderr) or "BIN_EXEC_FAILURE"
            return report

    if filesystem is None:
        report.fatal = True
        report.FILESYSTEM_PROBE = "FAIL"
        report.failure_class = "FILESYSTEM_FAILURE"
        report.SYSTEMD_USER_SESSION = _systemd_state(seen)
        return report
    seen.append(filesystem)
    _record(report, filesystem)
    if not _has_token(filesystem.stdout, TOKEN_FS_OK):
        report.fatal = True
        report.FILESYSTEM_PROBE = "FAIL"
        report.failure_class = classify_wsl_stderr(filesystem.stderr) or "FILESYSTEM_FAILURE"
        report.SYSTEMD_USER_SESSION = _systemd_state(seen)
        return report
    report.FILESYSTEM_PROBE = "PASS"
    report.SYSTEMD_USER_SESSION = _systemd_state(seen)

    if managed_user is not None:
        seen.append(managed_user)
        _record(report, managed_user)
        if _has_token(managed_user.stdout, TOKEN_USER_OK):
            report.MANAGED_USER_PROBE = "PASS"
            report.should_create_managed_user = False
        else:
            report.MANAGED_USER_PROBE = "MISSING"
            report.should_create_managed_user = True
            if stage == "post_guest":
                report.fatal = True
                report.failure_class = "MANAGED_USER_MISSING"
                return report

    if container_engine is not None:
        seen.append(container_engine)
        _record(report, container_engine)
        if _has_token(container_engine.stdout, TOKEN_ENGINE_OK):
            report.CONTAINER_ENGINE_PROBE = "PASS"
        elif stage == "post_guest":
            report.CONTAINER_ENGINE_PROBE = "FAIL"
            report.fatal = True
            report.failure_class = "CONTAINER_ENGINE_FAILURE"
            report.SYSTEMD_USER_SESSION = _systemd_state(seen)
            return report
        else:
            report.CONTAINER_ENGINE_PROBE = "PENDING"

    if rootless is not None:
        seen.append(rootless)
        if _has_token(rootless.stdout, TOKEN_ROOTLESS_OK):
            report.diagnostics["ROOTLESS_PROBE"] = "PASS"
        elif stage == "post_guest":
            report.fatal = True
            report.failure_class = "ROOTLESS_PREREQ_FAILURE"
            report.CONTAINER_ENGINE_PROBE = report.CONTAINER_ENGINE_PROBE or "FAIL"
            return report
        else:
            report.diagnostics["ROOTLESS_PROBE"] = "PENDING"

    if network is not None:
        seen.append(network)
        _record(report, network)
        if _has_token(network.stdout, TOKEN_NET_OK):
            report.NETWORK_PROBE = "PASS"
        else:
            report.NETWORK_PROBE = "FAIL"
            report.fatal = True
            report.failure_class = classify_wsl_stderr(network.stderr) or "NETWORK_FAILURE"
            report.SYSTEMD_USER_SESSION = _systemd_state(seen)
            return report

    report.ok = True
    report.fatal = False
    report.SYSTEMD_USER_SESSION = _systemd_state(seen)
    return report
