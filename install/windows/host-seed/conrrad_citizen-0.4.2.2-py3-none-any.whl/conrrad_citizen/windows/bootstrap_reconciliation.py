"""Windows bootstrap product-readiness reconciliation. Architecture for tests.

Product readiness is authoritative.
A healthy Citizen cannot be reported as failed because optional cleanup failed.
Guest exit codes are evidence, not the installation result.
"""
from __future__ import annotations

BIRTH = "BIRTH"
RESUME = "RESUME"
ALREADY_RUNNING = "ALREADY_RUNNING"

CRITICAL = "CRITICAL"
WARNING = "WARNING"
INFORMATIONAL = "INFORMATIONAL"

SUCCESS = "SUCCESS"
FAILURE = "FAILURE"

READY = "READY"
NOT_READY = "NOT_READY"

TASK_ALREADY_ABSENT = "TASK_ALREADY_ABSENT"
TASK_REMOVED = "TASK_REMOVED"
TASK_DELETE_FAILED = "TASK_DELETE_FAILED"
RUNONCE_ABSENT = "RUNONCE_ABSENT"

FALSE_FAILURE_WHAT = "Citizen could not be started."
FALSE_FAILURE_BIRTH = "Citizen did not complete Birth or Resume."
SUCCESS_READY_LINE = "Citizen is READY."
SUCCESS_COMPLETE_LINE = "Installation complete."
CLEANUP_WARNING_LINE = "Cleanup warning recorded; Citizen remains healthy."
EXISTING_CITIZEN_LINE = "Existing Citizen detected."
VERIFYING_ENV_LINE = "Verifying environment..."


def classify_birth_mode(*, sealed: bool, http_ready_before_start: bool) -> str:
    if http_ready_before_start:
        return ALREADY_RUNNING
    if sealed:
        return RESUME
    return BIRTH


def should_start_guest(*, product_ready: bool) -> bool:
    return not product_ready


def product_ready(
    *,
    managed_env: bool,
    http_ok: bool,
    state_ready: bool,
) -> bool:
    return bool(managed_env and http_ok and state_ready)


def parse_readiness_payload(
    *,
    http_status: int,
    life: dict | None = None,
    living: dict | None = None,
) -> dict:
    http_ok = int(http_status or 0) == 200
    citizen_id = ""
    living_version = ""
    state = ""
    if isinstance(life, dict):
        citizen = life.get("citizen") if isinstance(life.get("citizen"), dict) else {}
        state = str(citizen.get("state") or "")
        citizen_id = str(citizen.get("citizen_id") or "")
        living_version = str(citizen.get("version") or "")
    if isinstance(living, dict):
        if not citizen_id:
            citizen_id = str(living.get("citizen_id") or "")
        if not living_version:
            living_version = str(
                living.get("citizen_seed_version") or living.get("version") or ""
            )
        alive = str(living.get("alive_status") or "")
        identity = str(living.get("identity_status") or "")
        if not state:
            if alive == "Alive" and identity == "sealed" and citizen_id.startswith("cit_"):
                state = READY
    state_ready = state == READY
    return {
        "http_ok": http_ok,
        "http_status": int(http_status or 0),
        "state": state or NOT_READY,
        "state_ready": state_ready,
        "citizen_id": citizen_id,
        "living_version": living_version,
        "product_ready": bool(http_ok and state_ready),
    }


def classify_cleanup(*, task_result: str = "", runonce_absent: bool = False) -> str:
    if task_result == TASK_DELETE_FAILED:
        return WARNING
    if task_result == TASK_ALREADY_ABSENT and runonce_absent:
        return INFORMATIONAL
    if task_result == TASK_ALREADY_ABSENT:
        return INFORMATIONAL
    if task_result == TASK_REMOVED:
        return INFORMATIONAL
    if runonce_absent:
        return INFORMATIONAL
    return INFORMATIONAL


def reconcile(
    *,
    product_is_ready: bool,
    guest_exit_code: int = 0,
    cleanup_class: str = INFORMATIONAL,
) -> dict:
    """Last command exit code is never the sole installation result."""
    if product_is_ready:
        result = SUCCESS
        severity = WARNING if cleanup_class == WARNING else INFORMATIONAL
        if cleanup_class == CRITICAL:
            severity = WARNING
        return {
            "BOOTSTRAP_RESULT": result,
            "INSTALLATION_RESULT": result,
            "READINESS_RESULT": READY,
            "PRODUCT_READY": True,
            "severity": severity,
            "user_failure": False,
        }
    _ = guest_exit_code
    return {
        "BOOTSTRAP_RESULT": FAILURE,
        "INSTALLATION_RESULT": FAILURE,
        "READINESS_RESULT": NOT_READY,
        "PRODUCT_READY": False,
        "severity": CRITICAL,
        "user_failure": True,
    }


def poll_until_ready(probes: list[dict], *, attempts: int | None = None) -> dict:
    rows = list(probes)
    if attempts is not None:
        rows = rows[: max(attempts, 1)]
    last = {
        "product_ready": False,
        "http_ok": False,
        "http_status": 0,
        "state_ready": False,
        "state": NOT_READY,
        "citizen_id": "",
        "living_version": "",
    }
    for row in rows:
        parsed = parse_readiness_payload(
            http_status=int(row.get("http_status") or 0),
            life=row.get("life"),
            living=row.get("living"),
        )
        last = parsed
        if parsed["product_ready"]:
            return parsed
    return last


def display_lines(*, product_is_ready: bool, cleanup_class: str = INFORMATIONAL) -> list[str]:
    if not product_is_ready:
        return [FALSE_FAILURE_WHAT, FALSE_FAILURE_BIRTH]
    lines = [SUCCESS_READY_LINE, SUCCESS_COMPLETE_LINE]
    if cleanup_class == WARNING:
        lines.append(CLEANUP_WARNING_LINE)
    return lines
