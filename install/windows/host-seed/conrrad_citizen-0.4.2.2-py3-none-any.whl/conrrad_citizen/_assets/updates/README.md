# Local update packages

`citizen-0.4.5/` is a signed local evolution for runtime 0.4.2.
`citizen-0.4.4/` and `citizen-0.4.3/` remain previous living packages. Pack with `python -m citizen_seed.evolution_pack`.

Place new signed packages here:

```text
assets/updates/<package-id>/
  manifest.json          # signed; compatibility must match living Citizen
  assets/
    <content_hash>/
      payload
      meta.json          # signed payload meta
```

Rules:

- Runtime is not replaced by Sync.  
- Identity is never reminted by Sync.  
- Manifest advances; prior Manifest retained under living `manifest/history/`.  
- Citizen Seed **0.1** genesis and certified behavior stay frozen; new capability arrives as Assets + Manifests for **0.2+** consumers when those releases exist.

Do not put private monorepo paths or unpublished knowledge into this tree.
