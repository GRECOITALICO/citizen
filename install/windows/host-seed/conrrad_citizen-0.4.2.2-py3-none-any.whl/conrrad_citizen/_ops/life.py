"""Read-only composition of an already-lived Citizen life.

This module does not persist, mint identity, or become a source of truth.
It reads existing planes and returns a product-facing projection.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from citizen_seed.work.history import read_history
from citizen_seed.work.registry import local_registry

BIRTH_EVENT_TYPES = {
    "PRE_BIRTH",
    "BIRTH_STARTED",
    "BIRTH_IDENTITY_MINTED",
    "BIRTH_EVIDENCE_PLANE_READY",
    "BIRTH_ASSETS_INSTALLED",
    "BIRTH_MANIFEST_INSTALLED",
    "BIRTH_PROJECTION_READY",
    "BIRTH_COMPLETE",
}

EVOLUTION_EVENT_TYPES = {
    "UPDATE_AVAILABLE",
    "UPDATE_VERIFY_OK",
    "UPDATE_COMPLETE",
    "UPDATE_STATE_VERIFIED",
    "UPDATE_STATE_UPDATED",
    "UPDATE_STATE_APPLY_UPDATE",
    "SYNC_EVIDENCE_STORED",
    "EVOLUTION",
}

FAILURE_EVENT_TYPES = {
    "SYNC_FAILED",
    "UPDATE_VERIFY_FAILED",
}

WORK_EVENT_TYPES = {
    "work_result",
    "work_failed",
}


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    out: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict):
            out.append(row)
    return out


def _capability_title(capability_id: str) -> str:
    spec = local_registry().get(capability_id) or {}
    name = str(spec.get("name") or capability_id or "Work")
    return name


def _work_title(row: dict[str, Any]) -> str:
    name = _capability_title(str(row.get("capability_id") or ""))
    status = str(row.get("status") or "").upper()
    if status == "COMPLETE":
        return f"{name} completed"
    if status == "FAILED":
        return f"{name} failed"
    if status == "REJECTED":
        return f"{name} rejected"
    if status:
        return f"{name} {status.lower()}"
    return name


def _ts(row: dict[str, Any]) -> str:
    return str(row.get("ts") or row.get("timestamp") or row.get("created_at") or "")


def compose_history(
    *,
    evolution_rows: list[dict[str, Any]],
    work_rows: list[dict[str, Any]],
    evidence_rows: list[dict[str, Any]],
    identity: dict[str, Any],
) -> list[dict[str, Any]]:
    """Semantic timeline. Not the event log."""
    items: list[dict[str, Any]] = []

    if not any(r.get("kind") == "birth" for r in evolution_rows) and identity.get("citizen_id"):
        items.append(
            {
                "type": "BIRTH",
                "timestamp": str(identity.get("created_utc") or ""),
                "title": "Citizen born",
                "summary": "Persistent identity sealed.",
                "status": "COMPLETE",
                "citizen_id": identity.get("citizen_id"),
            }
        )

    for row in evolution_rows:
        kind = str(row.get("kind") or "")
        ts = _ts(row)
        cid = row.get("citizen_id") or identity.get("citizen_id")
        if kind == "birth":
            items.append(
                {
                    "type": "BIRTH",
                    "timestamp": ts,
                    "title": "Citizen born",
                    "summary": str(row.get("message") or "Citizen born"),
                    "status": "COMPLETE",
                    "citizen_id": cid,
                    "evidence_reference": row.get("evidence_id"),
                }
            )
        elif kind == "generation":
            ver = str(row.get("version") or row.get("label") or "")
            items.append(
                {
                    "type": "GENERATION",
                    "timestamp": ts,
                    "title": f"Citizen {ver}".strip(),
                    "summary": str(row.get("message") or f"Living generation {ver}"),
                    "status": "COMPLETE",
                    "citizen_id": cid,
                    "version_after": ver or None,
                    "evidence_reference": row.get("evidence_id"),
                }
            )
        elif kind in {"sync_evolution", "evolution"}:
            prev = str(row.get("previous_version") or "")
            new = str(row.get("new_version") or row.get("version") or "")
            title = f"{prev} → {new}" if prev and new else (new or "Evolution")
            items.append(
                {
                    "type": "EVOLUTION",
                    "timestamp": ts,
                    "title": title,
                    "summary": str(row.get("message") or "Evolution recorded"),
                    "status": "COMPLETE" if row.get("apply_result") in {None, "OK"} else str(row.get("apply_result")),
                    "citizen_id": cid,
                    "version_before": prev or None,
                    "version_after": new or None,
                    "evidence_reference": row.get("evidence_id"),
                }
            )

    for row in evidence_rows:
        et = str(row.get("event_type") or "")
        if et not in FAILURE_EVENT_TYPES:
            continue
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        items.append(
            {
                "type": "FAILURE",
                "timestamp": _ts(row),
                "title": "Sync failed" if "SYNC" in et or "UPDATE" in et else et,
                "summary": str(payload.get("reason") or payload.get("error") or "A change did not complete."),
                "status": "FAILED",
                "citizen_id": row.get("citizen_id") or identity.get("citizen_id"),
                "evidence_reference": row.get("content_hash"),
            }
        )

    for row in work_rows:
        status = str(row.get("status") or "")
        items.append(
            {
                "type": "WORK",
                "timestamp": _ts(row),
                "title": _work_title(row),
                "summary": f"{row.get('capability_id') or 'work'} · {status or 'recorded'}",
                "status": status or "RECORDED",
                "citizen_id": row.get("citizen_id") or identity.get("citizen_id"),
                "work_type": row.get("capability_id"),
                "evidence_reference": row.get("result_ref") or row.get("work_id"),
            }
        )

    items.sort(key=lambda r: str(r.get("timestamp") or ""))
    return items


def _detail_from_evidence(row: dict[str, Any]) -> dict[str, Any]:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    return {
        "event_type": row.get("event_type"),
        "timestamp": _ts(row),
        "evidence_id": row.get("content_hash"),
        "citizen_id": row.get("citizen_id"),
        "work_id": payload.get("work_id"),
        "implementation_id": payload.get("implementation_id"),
        "worker_id": payload.get("worker_id"),
        "validator_id": (payload.get("validator_result") or {}).get("validator_id")
        if isinstance(payload.get("validator_result"), dict)
        else payload.get("validator_id"),
        "update_artifact_hash": payload.get("update_artifact_hash"),
        "payload": payload,
    }


def compose_evidence(
    *,
    evidence_rows: list[dict[str, Any]],
    identity: dict[str, Any],
) -> list[dict[str, Any]]:
    """Group existing evidence by lifecycle / Work consequence."""
    groups: list[dict[str, Any]] = []
    citizen = identity.get("citizen_id")
    birth = [r for r in evidence_rows if r.get("event_type") in BIRTH_EVENT_TYPES]
    if birth:
        last = birth[-1]
        groups.append(
            {
                "group": "Birth",
                "what": "Citizen born",
                "when": _ts(last),
                "citizen": last.get("citizen_id") or citizen,
                "result": "COMPLETE",
                "details": [_detail_from_evidence(r) for r in birth],
            }
        )

    evo = [r for r in evidence_rows if r.get("event_type") in EVOLUTION_EVENT_TYPES]
    if evo:
        complete = next((r for r in reversed(evo) if r.get("event_type") == "EVOLUTION"), None)
        update = next((r for r in reversed(evo) if r.get("event_type") == "UPDATE_COMPLETE"), None)
        primary = complete or update or evo[-1]
        payload = primary.get("payload") if isinstance(primary.get("payload"), dict) else {}
        prev = payload.get("previous_version")
        new = payload.get("new_version")
        what = f"Evolution {prev} → {new}" if prev and new else "Evolution recorded"
        groups.append(
            {
                "group": "Evolution",
                "what": what,
                "when": _ts(primary),
                "citizen": primary.get("citizen_id") or citizen,
                "result": payload.get("apply_result") or payload.get("verification_result") or "OK",
                "details": [_detail_from_evidence(r) for r in evo],
            }
        )

    fails = [r for r in evidence_rows if r.get("event_type") in FAILURE_EVENT_TYPES]
    if fails:
        last = fails[-1]
        payload = last.get("payload") if isinstance(last.get("payload"), dict) else {}
        groups.append(
            {
                "group": "Sync",
                "what": "Sync failed",
                "when": _ts(last),
                "citizen": last.get("citizen_id") or citizen,
                "result": "FAILED",
                "details": [_detail_from_evidence(r) for r in fails],
            }
        )

    for row in evidence_rows:
        if row.get("event_type") not in WORK_EVENT_TYPES:
            continue
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        cap = str(payload.get("capability_id") or "")
        status = str(payload.get("status") or row.get("event_type"))
        groups.append(
            {
                "group": "Work",
                "what": _work_title({"capability_id": cap, "status": status}),
                "when": _ts(row),
                "citizen": row.get("citizen_id") or citizen,
                "result": status,
                "details": [_detail_from_evidence(row)],
            }
        )
    return groups


def compose_life(home: Path) -> dict[str, Any]:
    """Read-only life projection. Never writes."""
    home = Path(home)
    identity: dict[str, Any] = {}
    ident_path = home / "identity" / "identity.json"
    if ident_path.is_file():
        try:
            loaded = json.loads(ident_path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                identity = loaded
        except json.JSONDecodeError:
            identity = {}

    evolution_rows = _read_jsonl(home / "ops" / "evolution_history.jsonl")
    evidence_rows = _read_jsonl(home / "evidence" / "evidence.jsonl")
    work_rows = read_history(home)

    return {
        "schema": "conrrad.citizen.life/v1",
        "readonly": True,
        "history": compose_history(
            evolution_rows=evolution_rows,
            work_rows=work_rows,
            evidence_rows=evidence_rows,
            identity=identity,
        ),
        "evidence": compose_evidence(evidence_rows=evidence_rows, identity=identity),
        "sources": {
            "identity": "identity/identity.json",
            "evidence": "evidence/evidence.jsonl",
            "evolution_history": "ops/evolution_history.jsonl",
            "work_history": "ops/canonical_work_history.jsonl",
        },
    }
