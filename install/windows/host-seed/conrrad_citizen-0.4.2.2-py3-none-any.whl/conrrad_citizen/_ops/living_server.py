#!/usr/bin/env python3
"""Citizen Console — living organism surface (ops layer only).

INT-CITIZEN-CONSOLE-001 · INT-CITIZEN-VISUAL-EVOLUTION-001

Does NOT modify Runtime / Foundation / GENESIS / Citizen Life / Papers.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

OPS_ROOT = Path(__file__).resolve().parent
SEED_ROOT = OPS_ROOT.parent
from citizen_seed import RUNTIME_VERSION  # noqa: E402
from citizen_seed.evolution_semantics import (  # noqa: E402
    IN_PROGRESS_PLAN_STATUSES,
    TRANSIENT_SYNC_STATES,
    build_evolution_plan,
    load_plan,
    mark_plan_failed,
    mark_step_verified,
    pack_is_compatible,
    remote_is_compatible,
    save_plan,
    select_target,
    update_projection as compose_update_projection,
)
from citizen_seed.update_engine import UpdateState  # noqa: E402

EDGE = os.environ.get("CITIZEN_EDGE_URL", "https://conrrad.org").rstrip("/")
HOME = Path(os.environ.get("CITIZEN_HOME", str(SEED_ROOT / ".citizen"))).expanduser()

# Bound at process start (configurable; 3434 is default only).
UI_HOST = os.environ.get("CITIZEN_UI_HOST", "127.0.0.1")
UI_PORT = int(os.environ.get("CITIZEN_UI_PORT", "3434"))

_TELEMETRY_STOP = threading.Event()
_LOCK = threading.Lock()
_SYNC_APPLY_LOCK = threading.Lock()
_sync_in_flight = False
_runtime_evolution_host = None


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def ops_dir() -> Path:
    d = HOME / "ops"
    d.mkdir(parents=True, exist_ok=True)
    return d


def emit_event(kind: str, message: str, **extra: object) -> None:
    """Important organism events only (append-only)."""
    row = {"ts": utc_now(), "kind": kind, "message": message, **extra}
    path = ops_dir() / "event_log.jsonl"
    with _LOCK:
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, sort_keys=True) + "\n")


def read_events(limit: int = 40) -> list[dict]:
    path = ops_dir() / "event_log.jsonl"
    if not path.is_file():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()
    out: list[dict] = []
    for line in lines[-limit:]:
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return list(reversed(out))


def run_cli(*args: str) -> tuple[int, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(SEED_ROOT / "runtime") + (
        os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else ""
    )
    env["CITIZEN_HOME"] = str(HOME)
    proc = subprocess.run(
        [sys.executable, "-m", "citizen_seed", *args, "--home", str(HOME)],
        cwd=str(SEED_ROOT),
        env=env,
        capture_output=True,
        text=True,
    )
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def load_identity() -> dict:
    ip = HOME / "identity" / "identity.json"
    if not ip.is_file():
        return {}
    return json.loads(ip.read_text(encoding="utf-8"))


def birth_hash(ident: dict) -> str:
    """Stable birth fingerprint from sealed identity bytes (ops display)."""
    ip = HOME / "identity" / "identity.json"
    if ip.is_file():
        digest = hashlib.sha256(ip.read_bytes()).hexdigest()
        return f"bh_{digest[:32]}"
    raw = json.dumps(ident, sort_keys=True).encode()
    return f"bh_{hashlib.sha256(raw).hexdigest()[:32]}" if ident else "—"


def parse_utc(ts: str) -> datetime | None:
    if not ts or ts == "—":
        return None
    try:
        return datetime.strptime(ts.replace("Z", "+0000"), "%Y-%m-%dT%H:%M:%S%z")
    except ValueError:
        return None


def citizen_age(created_utc: str) -> str:
    dt = parse_utc(created_utc)
    if not dt:
        return "—"
    now = datetime.now(timezone.utc)
    delta = now - dt.astimezone(timezone.utc)
    secs = int(delta.total_seconds())
    if secs < 0:
        secs = 0
    days, rem = divmod(secs, 86400)
    hours, rem = divmod(rem, 3600)
    mins, _ = divmod(rem, 60)
    if days:
        return f"{days}d {hours}h"
    if hours:
        return f"{hours}h {mins}m"
    return f"{mins}m"


def file_line_count(path: Path) -> int:
    if not path.is_file():
        return 0
    return sum(1 for _ in path.open(encoding="utf-8", errors="ignore"))


def dir_bytes(path: Path) -> int:
    if not path.is_dir():
        return 0
    total = 0
    for p in path.rglob("*"):
        if p.is_file():
            try:
                total += p.stat().st_size
            except OSError:
                pass
    return total


def organ_status(path: Path, kind: str) -> str:
    """Permanent organ health — never conflated with cluster connectivity."""
    if kind == "filesystem":
        if not HOME.is_dir():
            return "missing"
        try:
            probe = ops_dir() / ".fs_probe"
            probe.write_text(utc_now() + "\n", encoding="utf-8")
            return "active"
        except OSError:
            return "degraded"
    if kind == "memory":
        return "active" if HOME.is_dir() and dir_bytes(HOME) > 0 else "empty"
    if kind == "evidence":
        p = HOME / "evidence" / "evidence.jsonl"
        return "active" if p.is_file() else "awaiting"
    if kind == "telemetry":
        marker = ops_dir() / "TELEMETRY_ORGAN_ACTIVE"
        p = HOME / "telemetry" / "telemetry.jsonl"
        if marker.is_file() or p.is_file():
            return "active"
        return "starting"
    return "unknown"


def connection_label(raw: str | None) -> str:
    """Cluster link only — never 'dead'."""
    if raw in {"online", "connected"}:
        return "Connected"
    if raw in {"offline_retry_later", "offline", "disconnected"}:
        return "Offline"
    return "Offline"


def build_heartbeat() -> dict:
    ident = load_identity()
    ver = seed_version()
    return {
        "message": "Citizen Awake",
        "citizen_uuid": ident.get("citizen_id", "unknown"),
        "citizen_version": ver,
        "timestamp": utc_now(),
        "platform": platform.platform(),
        "node": os.environ.get("CITIZEN_NODE_ID", "local"),
        "heartbeat": True,
    }


def seed_version() -> str:
    """Living Citizen version. Not runtime_version, not the image body VERSION."""
    meta = current_manifest_meta()
    living = str(meta.get("citizen_version") or "").strip().lstrip("v")
    if living:
        return living
    ov = ops_dir() / "CURRENT_VERSION.txt"
    if ov.is_file():
        v = ov.read_text(encoding="utf-8").strip()
        if v:
            return v.lstrip("v")
    vf = SEED_ROOT / "VERSION"
    return vf.read_text(encoding="utf-8").strip() if vf.is_file() else RUNTIME_VERSION


def set_current_version(ver: str) -> None:
    ops_dir().joinpath("CURRENT_VERSION.txt").write_text(ver.lstrip("v") + "\n", encoding="utf-8")


def parse_semver_tuple(ver: str) -> tuple[int, int, int]:
    m = re.match(r"v?(\d+)\.(\d+)(?:\.(\d+))?", ver.strip())
    if not m:
        return (0, 0, 0)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3) or 0))


def is_newer_evolution(candidate: str, current: str) -> bool:
    """True when candidate is a strictly newer living version than current."""
    return parse_semver_tuple(str(candidate or "")) > parse_semver_tuple(str(current or ""))


def candidate_living_version(cand: dict | None) -> str:
    if not cand:
        return ""
    env = cand.get("envelope") if isinstance(cand.get("envelope"), dict) else {}
    descriptor = env.get("descriptor") if isinstance(env, dict) else {}
    for raw in (
        (descriptor or {}).get("to_version"),
        cand.get("version"),
        cand.get("latest"),
        cand.get("latest_version"),
    ):
        if raw:
            return str(raw).lstrip("v")
    return ""


def evolutionary_line(ver: str) -> dict:
    """Fixed palette — never random. SYNC text color by line."""
    major, minor, _ = parse_semver_tuple(ver)
    if major >= 1:
        return {
            "line": "citizen_1",
            "label": "Citizen 1.x",
            "sync_color": "#ffffff",
            "badge": "GEN 1",
            "badge_class": "gen-1",
        }
    if minor >= 4:
        return {
            "line": "citizen_0_4",
            "label": "Citizen 0.4",
            "sync_color": "#2ec4b6",
            "badge": "0.4",
            "badge_class": "gen-04",
        }
    if minor >= 3:
        return {
            "line": "citizen_0_3",
            "label": "Citizen 0.3",
            "sync_color": "#2ec4b6",
            "badge": "0.3",
            "badge_class": "gen-03",
        }
    if minor >= 2:
        return {
            "line": "citizen_0_2",
            "label": "Citizen 0.2",
            "sync_color": "#3dce7a",
            "badge": "0.2",
            "badge_class": "gen-02",
        }
    return {
        "line": "citizen_seed_0_1",
        "label": "Citizen 0.1",
        "sync_color": "#4db8ff",
        "badge": "0.1",
        "badge_class": "gen-seed",
    }


def evolution_path() -> Path:
    return ops_dir() / "evolution_history.jsonl"


def read_evolution_history() -> list[dict]:
    path = evolution_path()
    if not path.is_file():
        return []
    out: list[dict] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def parse_update_cli_output(out: str) -> dict:
    text = (out or "").strip()
    if not text:
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        for line in reversed(text.splitlines()):
            line = line.strip()
            if line.startswith("{"):
                try:
                    return json.loads(line)
                except json.JSONDecodeError:
                    continue
    return {}


def latest_non_birth_evolution_version() -> str | None:
    for row in reversed(read_evolution_history()):
        if row.get("kind") != "birth" and row.get("version"):
            return str(row["version"]).lstrip("v")
    return None


def append_evolution(entry: dict) -> dict:
    """Append-only — history only grows; never deletes."""
    path = evolution_path()
    row = dict(entry)
    row.setdefault("ts", utc_now())
    if "evidence_id" not in row:
        raw = f"{row.get('version')}|{row['ts']}|{row.get('kind', 'evolution')}"
        row["evidence_id"] = "ev_" + hashlib.sha256(raw.encode()).hexdigest()[:24]
    with _LOCK:
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, sort_keys=True) + "\n")
    return row


def ensure_birth_evolution() -> None:
    hist = read_evolution_history()
    if any(h.get("kind") == "birth" for h in hist):
        return
    ident = load_identity()
    birth_ts = ident.get("created_utc") or utc_now()
    append_evolution(
        {
            "kind": "birth",
            "version": "Birth",
            "label": "Birth",
            "ts": birth_ts,
            "citizen_id": ident.get("citizen_id"),
            "message": "Citizen Born",
        }
    )
    # Seed line: current package version as first living generation marker
    vf = SEED_ROOT / "VERSION"
    ver = vf.read_text(encoding="utf-8").strip() if vf.is_file() else RUNTIME_VERSION
    if not any(h.get("version") == ver and h.get("kind") != "birth" for h in read_evolution_history()):
        append_evolution(
            {
                "kind": "generation",
                "version": ver,
                "label": ver,
                "ts": birth_ts,
                "message": f"Citizen Seed {ver}",
            }
        )


def current_manifest_meta() -> dict:
    mf = HOME / "manifest" / "current.json"
    if not mf.is_file():
        return {}
    try:
        return json.loads(mf.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def _project_web_assets() -> None:
    """After a successful update, copy web/* assets from store → ops/web/ directory."""
    meta = current_manifest_meta()
    web_root = (OPS_ROOT / "web").resolve()
    import shutil
    for entry in meta.get("assets", []):
        asset_id = entry.get("asset_id", "")
        content_hash = entry.get("content_hash", "")
        if not asset_id.startswith("web/") or not content_hash:
            continue
        payload = HOME / "assets" / content_hash / "payload"
        if not payload.is_file():
            continue

        # Security invariant: Destination MUST remain inside ops/web/
        rel = asset_id[len("web/"):]
        dest = (web_root / rel).resolve()

        try:
            if not dest.is_relative_to(web_root):
                emit_event("asset_projection_blocked", f"Path traversal prevented for {asset_id}", asset_id=asset_id)
                continue
        except ValueError:
            # Fallback for older Pythons if is_relative_to raises ValueError (it shouldn't in 3.9+)
            continue

        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(payload), str(dest))
        emit_event("asset_projected", f"Projected {asset_id}", asset_id=asset_id)


def _updates_dir() -> Path:
    from citizen_seed.evolution_pack import default_updates_dir

    return default_updates_dir()


def list_local_update_packages() -> list[dict]:
    """All compatible local packages. Includes older packs for behind-target detection."""
    updates = _updates_dir()
    current = current_manifest_meta()
    if not updates.is_dir() or not current:
        return []
    found: list[dict] = []
    for mf in sorted(updates.glob("*/manifest.json")):
        try:
            cand = json.loads(mf.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not pack_is_compatible(
            pack_runtime=str(cand.get("runtime_version") or ""),
            pack_compatibility=str(cand.get("compatibility") or ""),
            pack_citizen_id=str(cand.get("citizen_id") or ""),
            runtime_version=RUNTIME_VERSION,
            current_compatibility=str(current.get("compatibility") or ""),
            current_citizen_id=str(current.get("citizen_id") or ""),
        ):
            continue
        ver = str(cand.get("citizen_version") or cand.get("runtime_version") or "").lstrip("v")
        if not ver:
            continue
        found.append(
            {
                "version": ver,
                "release": cand.get("release"),
                "asset_version": cand.get("asset_version"),
                "path": str(mf.parent),
                "source": "local_package",
                "kind": "local",
            }
        )
    return found


def scan_local_update_candidate() -> dict | None:
    """Ops-side quiet scan of assets/updates (no Runtime edits). Best newer local pack."""
    current_ver = seed_version()
    newer = [
        p for p in list_local_update_packages() if is_newer_evolution(p.get("version") or "", current_ver)
    ]
    if not newer:
        return None
    best = max(
        newer,
        key=lambda p: (parse_semver_tuple(str(p.get("version") or "")), str(p.get("release") or "")),
    )
    return best


def pending_update_marker() -> dict | None:
    path = ops_dir() / "PENDING_UPDATE.json"
    if not path.is_file():
        return None
    try:
        d = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    if d.get("available") is False:
        return None
    return d


def clear_pending_update() -> None:
    path = ops_dir() / "PENDING_UPDATE.json"
    if path.is_file():
        path.unlink()


def edge_update_check() -> dict | None:
    """Discovery only. Cluster `update_available` is not Citizen-local truth."""
    url = os.environ.get("CITIZEN_UPDATE_CHECK_URL", f"{EDGE}/.well-known/citizen-update")
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": "CitizenSeed/0.1-Console"})
    try:
        with urllib.request.urlopen(req, timeout=3) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            data = json.loads(body)
            if not isinstance(data, dict):
                return None
            version = data.get("version") or data.get("latest") or data.get("latest_version")
            result: dict = {
                "version": version,
                "release": data.get("release"),
                "source": "edge",
            }
            if data.get("envelope"):
                env = dict(data["envelope"])
                if data.get("sas_token"):
                    env["sas_token"] = data["sas_token"]
                result["envelope"] = env
                descriptor = env.get("descriptor") if isinstance(env.get("descriptor"), dict) else {}
                if not result["version"] and descriptor.get("to_version"):
                    result["version"] = descriptor.get("to_version")
            if result["version"] or result.get("envelope"):
                return result
    except Exception:
        return None
    return None


def _safe_discover(fn):
    try:
        return fn()
    except Exception:
        return None


def discover_update_artifacts(*, include_all_local: bool = False) -> list[dict]:
    """Collect compatible candidates. Never applies.

    Advertised target uses pending + best local scan + edge so a mocked scan
    still wins in tests. Plan construction also glob-lists every local pack.
    """
    artifacts: list[dict] = []
    pending = _safe_discover(pending_update_marker)
    if pending:
        ver = candidate_living_version(pending) or str(pending.get("version") or "").lstrip("v")
        if ver:
            artifacts.append(
                {
                    "version": ver,
                    "kind": "pending",
                    "source": pending.get("source", "pending"),
                    "release": pending.get("release"),
                    "path": str(pending.get("path") or ""),
                }
            )
    scan = _safe_discover(scan_local_update_candidate)
    if scan:
        artifacts.append(
            {
                "version": str(scan.get("version") or "").lstrip("v"),
                "kind": "local",
                "source": scan.get("source", "local_package"),
                "release": scan.get("release"),
                "path": str(scan.get("path") or ""),
            }
        )
    if include_all_local:
        artifacts.extend(list_local_update_packages())
    edge = _safe_discover(edge_update_check)
    if edge:
        ver = candidate_living_version(edge) or str(edge.get("version") or "").lstrip("v")
        env = edge.get("envelope") if isinstance(edge.get("envelope"), dict) else {}
        descriptor = env.get("descriptor") if isinstance(env, dict) else {}
        min_v = str((descriptor or {}).get("minimum_supported_version") or "0.0.0")
        if ver and remote_is_compatible(
            minimum_supported_version=min_v, runtime_version=RUNTIME_VERSION
        ):
            artifacts.append(
                {
                    "version": ver,
                    "kind": "remote",
                    "source": edge.get("source", "edge"),
                    "release": edge.get("release"),
                    "path": "",
                    "envelope": edge.get("envelope"),
                }
            )
    return [a for a in artifacts if a.get("version")]


def living_update_projection() -> dict:
    current = seed_version()
    artifacts = discover_update_artifacts(include_all_local=False)
    versions = [str(a.get("version") or "") for a in artifacts]
    target, relation = select_target(current, versions)
    source = None
    release = None
    for art in artifacts:
        if str(art.get("version") or "").lstrip("v") == target:
            source = art.get("source")
            release = art.get("release")
    class_pkg = _class_package_projection(current, target)
    if class_pkg.get("target_living"):
        target = class_pkg["target_living"]
        relation = select_target(current, [target])[1]
    proj = compose_update_projection(
        current_version=current,
        target_version=target,
        runtime_version=RUNTIME_VERSION,
        sync_state=_projected_sync_state(),
        plan=load_plan(HOME),
        sync_in_flight=_sync_in_flight,
        update_source=source or class_pkg.get("source"),
        update_release=release or class_pkg.get("release"),
        living_version=current,
    )
    proj["relation"] = relation
    proj["current_runtime"] = RUNTIME_VERSION
    proj["target_runtime"] = class_pkg.get("target_runtime") or RUNTIME_VERSION
    proj["current_runtime_digest"] = class_pkg.get("current_digest") or ""
    proj["target_runtime_digest"] = class_pkg.get("target_digest") or ""
    if class_pkg.get("runtime_update") or class_pkg.get("living_update"):
        proj["update_available"] = True
        proj["sync_required"] = True
        if proj.get("evolution_status") == "READY":
            proj["evolution_status"] = "UPDATE_AVAILABLE"
            proj["update_status"] = "UPDATE AVAILABLE"
            proj["sync_status"] = "Update Available"
            proj["relation"] = "UPDATE_AVAILABLE"
    return proj


def _class_package_projection(current_living: str, target_living: str) -> dict:
    from citizen_seed.class_package import (
        ClassPackageError,
        discover_class_package,
        load_envelope,
        verify_class_package_envelope,
    )

    path = discover_class_package(_updates_dir())
    if path is None:
        return {}
    try:
        descriptor = verify_class_package_envelope(load_envelope(path))
    except (ClassPackageError, OSError):
        return {}
    src = descriptor["source"]
    tgt = descriptor["target"]
    return {
        "source": "class_package",
        "release": descriptor["metadata"].get("release_id"),
        "target_living": tgt["living_version"] or target_living,
        "target_runtime": tgt["runtime_version"],
        "current_digest": src["runtime_image_digest"],
        "target_digest": tgt["runtime_image_digest"],
        "runtime_update": src["runtime_image_digest"] != tgt["runtime_image_digest"],
        "living_update": current_living != tgt["living_version"],
    }


def update_availability() -> dict:
    """Detect CONRRAD-published update.

    Discovery only. Must never apply an update.
    Cluster feed flags are not Citizen-local truth — versions are.
    Older local packages must not mask a newer public evolution.
    """
    proj = living_update_projection()
    latest = proj["target_version"]
    if not proj["update_available"]:
        hist = read_evolution_history()
        latest = "—"
        for row in reversed(hist):
            if row.get("kind") != "birth" and row.get("version"):
                latest = str(row["version"])
                break
    return {
        "update_available": bool(proj["update_available"]),
        "latest_evolution": proj["target_version"] if proj["update_available"] else latest,
        "update_source": proj.get("update_source"),
        "update_release": proj.get("update_release"),
        "target_version": proj["target_version"],
        "current_version": proj["current_version"],
        "sync_required": bool(proj["sync_required"]),
        "target_behind_current": bool(proj.get("target_behind_current")),
    }


def http_post_json(url: str, payload: dict, timeout: float = 5.0) -> tuple[bool, str]:
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers={"Content-Type": "application/json", "User-Agent": "CitizenSeed/0.1-Console"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return True, f"HTTP {resp.status}"
    except urllib.error.HTTPError as e:
        return False, f"HTTP {e.code}"
    except Exception as e:
        return False, f"offline: {e}"


def send_awake(hb: dict) -> tuple[bool, str]:
    url = os.environ.get("CITIZEN_AWAKE_URL", f"{EDGE}/.well-known/citizen-awake")
    return http_post_json(url, hb)


def set_connection(connected: bool) -> None:
    path = ops_dir() / "LAST_CONNECTION.json"
    path.write_text(
        json.dumps(
            {
                "ts": utc_now(),
                "connection": "online" if connected else "offline_retry_later",
                "label": "Connected" if connected else "Offline",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def last_connection() -> dict:
    path = ops_dir() / "LAST_CONNECTION.json"
    if path.is_file():
        return json.loads(path.read_text(encoding="utf-8"))
    lw = ops_dir() / "LAST_WAKE.json"
    if lw.is_file():
        d = json.loads(lw.read_text(encoding="utf-8"))
        return {"connection": d.get("connection"), "ts": d.get("ts")}
    return {}


def last_sync_ts() -> str:
    path = ops_dir() / "LAST_SYNC.json"
    if path.is_file():
        d = json.loads(path.read_text(encoding="utf-8"))
        return d.get("ts", "—")
    sp = HOME / "ui" / "sync_state.json"
    if sp.is_file():
        d = json.loads(sp.read_text(encoding="utf-8"))
        return d.get("updated_ts", "—")
    return "—"


def append_heartbeat(hb: dict) -> int:
    hb_path = ops_dir() / "heartbeat.jsonl"
    with _LOCK:
        with hb_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(hb, sort_keys=True) + "\n")
        return file_line_count(hb_path)


def wake() -> dict:
    report: dict = {"ts": utc_now(), "platform": platform.platform(), "steps": []}

    def step(name: str, ok: bool, detail: str = "") -> None:
        report["steps"].append({"step": name, "ok": ok, "detail": detail[:500]})

    if not (HOME / "boot" / "BOOTSTRAP_DISARMED").is_file():
        step("self_check", False, "Citizen not Born — run ./install.sh first")
        report["ready"] = False
        emit_event("wake_blocked", "Citizen not Born")
        return report
    step("self_check", True, "BOOTSTRAP_DISARMED present")

    code, out = run_cli("boot")
    step("citizen_wake_boot", code == 0, out[-400:])
    code_st, out_st = run_cli("status")
    step("memory_identity_load", code_st == 0, out_st[-400:])

    hb = build_heartbeat()
    n = append_heartbeat(hb)
    step("heartbeat_local", True, f"count={n}")

    edge_ok, edge_detail = send_awake(hb)
    set_connection(edge_ok)
    step("connect_conrrad", edge_ok, edge_detail)
    report["heartbeat"] = hb
    report["connection"] = "online" if edge_ok else "offline_retry_later"
    report["ready"] = True
    (ops_dir() / "LAST_WAKE.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    ensure_birth_evolution()
    _project_web_assets()  # Ensure web dir reflects current manifest on wake
    # Wake discovers nothing new to apply. An incomplete user-requested plan
    # may resume without a second Sync. That is not a new Birth and not a new
    # evolution request.
    resume_incomplete_evolution_if_needed()
    emit_event(
        "wake",
        "Citizen Awake",
        alive=True,
        connected=edge_ok,
        port=UI_PORT,
    )
    return report


def _commit_terminal_sync_state(state: str, **extra: object) -> None:
    from citizen_seed.terminal import write_sync_state

    label = str(state)
    if label in TRANSIENT_SYNC_STATES:
        label = UpdateState.CURRENT.value
    color = "green"
    if label in {UpdateState.SYNC_FAILED.value, UpdateState.ROLLED_BACK.value}:
        color = "red"
    elif label in {UpdateState.UPDATE_AVAILABLE.value, "Update Available"}:
        color = "orange"
    write_sync_state(HOME / "ui", label, color=color, **extra)


def _record_committed_evolution(
    *,
    previous_version: str,
    ver: str,
    caps_before: list,
    avail_before: dict,
) -> dict | None:
    if latest_non_birth_evolution_version() == ver:
        return None
    meta = current_manifest_meta()
    capability_change = _capability_change_after_sync(caps_before, applied=True)
    evolution_row = append_evolution(
        {
            "kind": "sync_evolution",
            "version": ver,
            "label": ver,
            "ts": utc_now(),
            "message": "Evolution recorded after successful SYNC",
            "update_was_available": bool(avail_before.get("update_available")),
            "previous_version": previous_version,
            "new_version": ver,
            "previous_capabilities": caps_before,
            "new_capabilities": _capability_projection().get("capabilities") or [],
            "citizen_id": load_identity().get("citizen_id"),
            "update_artifact_hash": meta.get("asset_version"),
            "verification_result": "OK",
            "apply_result": "OK",
            "capability_change": capability_change,
        }
    )
    emit_event(
        "evolution",
        f"Evolution {previous_version} → {ver}",
        version=ver,
        previous_version=previous_version,
        evidence_id=evolution_row.get("evidence_id"),
    )
    try:
        from citizen_seed.evidence import append as evidence_append

        evidence_append(
            HOME / "evidence",
            citizen_id=str(load_identity().get("citizen_id") or ""),
            event_type="EVOLUTION",
            payload={
                "previous_version": previous_version,
                "new_version": ver,
                "citizen_id": load_identity().get("citizen_id"),
                "update_artifact_hash": meta.get("asset_version"),
                "verification_result": "OK",
                "apply_result": "OK",
                "capability_change": capability_change,
            },
        )
    except Exception:
        pass
    return evolution_row


def _apply_plan_step(step: dict) -> dict:
    """Apply one internal plan step. Identity is never reset."""
    kind = str(step.get("kind") or "local")
    if kind == "remote":
        from citizen_seed.updater import one_click_remote_update

        env = step.get("envelope")
        env_path = ops_dir() / "REMOTE_ENVELOPE.json"
        if env:
            env_path.write_text(json.dumps(env, indent=2), encoding="utf-8")
        return one_click_remote_update(home=HOME, envelope_path=env_path)
    from citizen_seed.updater import one_click_package, one_click_update

    package_dir = str(step.get("artifact_ref") or "")
    if package_dir:
        return one_click_package(home=HOME, package_dir=Path(package_dir))
    return one_click_update(home=HOME, updates_dir=_updates_dir())


def apply_evolution_plan(plan: dict, *, caps_before: list, avail_before: dict) -> dict:
    """Apply remaining plan steps. One user Sync owns the whole plan."""
    from citizen_seed.terminal import write_sync_state

    origin = str(plan.get("source_version") or seed_version())
    target = str(plan.get("target_version") or "")
    steps = list(plan.get("steps") or [])
    start_index = int(plan.get("current_step") or 0)
    last_row = None
    living = seed_version()
    plan["status"] = "applying"
    save_plan(HOME, plan)

    for index in range(start_index, len(steps)):
        step = steps[index]
        to_ver = str(step.get("to_version") or "")
        write_sync_state(
            HOME / "ui",
            "SYNCING",
            color="orange",
            current_step=index + 1,
            total_steps=len(steps),
            source_version=origin,
            target_version=target,
        )
        if to_ver and not is_newer_evolution(to_ver, living):
            plan = mark_step_verified(plan, index, living)
            save_plan(HOME, plan)
            continue
        try:
            payload = _apply_plan_step(step)
        except Exception as exc:
            plan = mark_plan_failed(
                plan,
                failed_step=index,
                error_code="APPLY_EXCEPTION",
                phase="applying",
                last_valid_version=seed_version(),
            )
            save_plan(HOME, plan)
            return {
                "ok": False,
                "updated": False,
                "state": UpdateState.SYNC_FAILED.value,
                "error": str(exc),
                "plan": plan,
                "evolution": None,
                "living_version": seed_version(),
            }
        state = str(payload.get("state") or "")
        sync_ok = state in {
            UpdateState.UPDATED.value,
            UpdateState.CURRENT.value,
            UpdateState.NOOP.value,
        }
        if not sync_ok:
            plan = mark_plan_failed(
                plan,
                failed_step=index,
                error_code=str(payload.get("error") or state or "STEP_FAILED"),
                phase="applying",
                last_valid_version=seed_version(),
            )
            save_plan(HOME, plan)
            return {
                "ok": False,
                "updated": False,
                "state": UpdateState.SYNC_FAILED.value,
                "error": str(payload.get("error") or state),
                "plan": plan,
                "evolution": None,
                "living_version": seed_version(),
            }
        meta = current_manifest_meta()
        new_ver = str(meta.get("citizen_version") or to_ver or living).lstrip("v")
        if new_ver:
            set_current_version(new_ver)
            living = new_ver
        if state == UpdateState.UPDATED.value:
            last_row = _record_committed_evolution(
                previous_version=str(step.get("from_version") or origin),
                ver=living,
                caps_before=caps_before,
                avail_before=avail_before,
            )
            _project_web_assets()
        plan = mark_step_verified(plan, index, living)
        save_plan(HOME, plan)

    plan["status"] = "complete"
    save_plan(HOME, plan)
    updated = living != origin and is_newer_evolution(living, origin)
    return {
        "ok": True,
        "updated": updated,
        "state": UpdateState.UPDATED.value if updated else UpdateState.NOOP.value,
        "error": "",
        "plan": plan,
        "evolution": last_row,
        "living_version": living,
    }


def resume_incomplete_evolution_if_needed() -> dict | None:
    """Resume a user-requested plan after restart. Never starts a new Birth."""
    plan = load_plan(HOME)
    if not plan:
        return None
    if str(plan.get("status") or "") not in IN_PROGRESS_PLAN_STATUSES:
        return None
    if int(plan.get("current_step") or 0) >= int(plan.get("total_steps") or 0):
        plan["status"] = "complete"
        save_plan(HOME, plan)
        _commit_terminal_sync_state(UpdateState.UPDATED.value, identity_preserved=True)
        return {"resumed": False, "complete": True}
    caps_before = _capability_projection().get("capabilities") or []
    avail_before = {
        "update_available": True,
        "latest_evolution": plan.get("target_version"),
    }
    out = apply_evolution_plan(plan, caps_before=caps_before, avail_before=avail_before)
    if out.get("ok"):
        _commit_terminal_sync_state(
            out["state"],
            identity_preserved=True,
            history_preserved=True,
            version_preserved=out.get("living_version"),
        )
    else:
        _commit_terminal_sync_state(
            UpdateState.SYNC_FAILED.value,
            reason=out.get("error"),
            identity_preserved=True,
            history_preserved=True,
            version_preserved=out.get("living_version"),
            failed_step=(out.get("plan") or {}).get("failed_step"),
        )
    return out


def _apply_class_package_sync() -> dict | None:
    """One user Sync may apply a CLASS_PACKAGE. HostAdapter owns runtime switch."""
    from citizen_seed.class_package import (
        ClassPackageError,
        discover_class_package,
        load_envelope,
        needs_living_evolution,
        needs_runtime_replacement,
        verify_class_package_envelope,
    )
    from citizen_seed import RUNTIME_VERSION
    from conrrad_citizen.host.contract import HostResult
    from conrrad_citizen.host.runtime_evolution import apply_class_package, capture_life

    path = discover_class_package(_updates_dir())
    if path is None:
        return None
    try:
        envelope = load_envelope(path)
        descriptor = verify_class_package_envelope(envelope)
    except ClassPackageError as exc:
        _commit_terminal_sync_state(
            UpdateState.SYNC_FAILED.value,
            reason=exc.message,
            identity_preserved=True,
            history_preserved=True,
        )
        return {"ok": False, "state": UpdateState.SYNC_FAILED.value, "error": exc.message, "birth": False}

    host = _runtime_evolution_host
    digest = ""
    if host is not None:
        from conrrad_citizen.host.runtime_evolution import current_image_digest

        digest = current_image_digest(host)
    digest = digest or descriptor["source"]["runtime_image_digest"]
    current = capture_life(HOME, runtime_image_digest=digest, runtime_version=RUNTIME_VERSION)
    runtime_needed = needs_runtime_replacement(descriptor, current)
    living_needed = needs_living_evolution(descriptor, current)
    if not runtime_needed and not living_needed:
        _commit_terminal_sync_state(
            UpdateState.NOOP.value,
            identity_preserved=True,
            history_preserved=True,
            version_preserved=current.living_version,
        )
        return {"ok": True, "state": UpdateState.NOOP.value, "living_version": current.living_version, "birth": False}

    if host is None:
        if runtime_needed:
            from citizen_seed.class_package import write_runtime_evolution_request

            request = {
                "phase": "host_request",
                "package_id": descriptor["package_id"],
                "reason": "in-guest UpdateEngine cannot replace its OCI image",
            }
            write_runtime_evolution_request(
                HOME,
                citizen_id=current.citizen_id,
                current_image_digest=current.runtime_image_digest,
                target_package_reference=str(path),
                status="requested",
            )
            _commit_terminal_sync_state(
                UpdateState.SYNC_FAILED.value,
                reason=request["reason"],
                identity_preserved=True,
                history_preserved=True,
            )
            return {
                "ok": False,
                "state": "HOST_RUNTIME_REPLACEMENT_REQUIRED",
                "error": request["reason"],
                "birth": False,
            }
        class _VolumeHost:
            def __init__(self) -> None:
                self.home = HOME
                self.data_dir = HOME.parent
                self.backend = None

            def health(self) -> HostResult:
                return HostResult(True, "READY", "living-only")

            def wait_health(self, attempts: int | None = None, delay: float | None = None) -> HostResult:
                return self.health()

            def _port_conflict(self, *, ignore_our_service: bool = False):
                return None

        host = _VolumeHost()

    result = apply_class_package(host=host, envelope=envelope, envelope_path=path)
    terminal = result.state if result.ok else (
        result.state if result.state in {UpdateState.ROLLED_BACK.value, UpdateState.SYNC_FAILED.value} else UpdateState.SYNC_FAILED.value
    )
    _commit_terminal_sync_state(
        terminal if result.ok else UpdateState.SYNC_FAILED.value,
        reason="" if result.ok else result.message,
        identity_preserved=True,
        history_preserved=True,
        version_preserved=(result.details or {}).get("living_version"),
    )
    payload = {
        "ok": result.ok,
        "state": result.state,
        "message": result.message,
        "birth": False,
        **(result.details or {}),
    }
    return payload


def sync_cycle() -> dict:
    """Single SYNC action: Handshake → Evidence → Telemetry → Plan → CURRENT→TARGET.

    One user Sync is one evolution request. Internal package steps are not
    extra user actions. Discovery never applies; this function does.
    """
    global _sync_in_flight
    result: dict = {"ts": utc_now(), "phases": [], "ok": True}
    if not _SYNC_APPLY_LOCK.acquire(blocking=False):
        proj = living_update_projection()
        result.update(
            {
                "ok": True,
                "duplicate": True,
                "sync_state": proj.get("sync_status") or "SYNCING",
                "sync_failed": False,
                "current_version": proj.get("current_version"),
                "target_version": proj.get("target_version"),
                "update_available": proj.get("update_available"),
                "sync_required": proj.get("sync_required"),
                "evolution_status": proj.get("evolution_status"),
                "alive_status": "Alive",
                "cluster_connection": connection_label(last_connection().get("connection")),
            }
        )
        return result

    _sync_in_flight = True
    try:
        return _sync_cycle_locked(result)
    finally:
        _sync_in_flight = False
        _SYNC_APPLY_LOCK.release()


def _sync_cycle_locked(result: dict) -> dict:
    ensure_birth_evolution()
    avail_before = update_availability()
    caps_before = _capability_projection().get("capabilities") or []
    version_before = seed_version()

    def phase(name: str, ok: bool, detail: str = "") -> None:
        result["phases"].append({"phase": name, "ok": ok, "detail": detail[:400]})

    emit_event("sync_start", "SYNC initiated from Console")

    hb = build_heartbeat()
    append_heartbeat(hb)
    ok, detail = send_awake({**hb, "message": "Citizen Handshake"})
    set_connection(ok)
    phase("handshake", ok, detail)

    evidence_path = HOME / "evidence" / "evidence.jsonl"
    evidence_tail = []
    if evidence_path.is_file():
        lines = evidence_path.read_text(encoding="utf-8").splitlines()[-20:]
        for line in lines:
            try:
                evidence_tail.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    payload = {
        "citizen_id": load_identity().get("citizen_id"),
        "kind": "evidence_exchange",
        "count": len(evidence_tail),
        "items": evidence_tail,
        "timestamp": utc_now(),
    }
    (ops_dir() / "PENDING_EVIDENCE_EXCHANGE.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )
    e_ok, e_detail = http_post_json(
        os.environ.get("CITIZEN_EVIDENCE_URL", f"{EDGE}/.well-known/citizen-evidence"),
        payload,
    )
    phase("evidence_exchange", e_ok, e_detail or "queued locally")

    tel_path = HOME / "telemetry" / "telemetry.jsonl"
    tel_tail = []
    if tel_path.is_file():
        for line in tel_path.read_text(encoding="utf-8").splitlines()[-30:]:
            try:
                tel_tail.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    organ_tel = ops_dir() / "telemetry_organ.jsonl"
    if organ_tel.is_file():
        for line in organ_tel.read_text(encoding="utf-8").splitlines()[-10:]:
            try:
                tel_tail.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    t_payload = {
        "citizen_id": load_identity().get("citizen_id"),
        "kind": "telemetry_upload",
        "count": len(tel_tail),
        "events": tel_tail,
        "timestamp": utc_now(),
    }
    (ops_dir() / "PENDING_TELEMETRY_UPLOAD.json").write_text(
        json.dumps({"count": len(tel_tail), "ts": utc_now()}, indent=2) + "\n",
        encoding="utf-8",
    )
    t_ok, t_detail = http_post_json(
        os.environ.get("CITIZEN_TELEMETRY_URL", f"{EDGE}/.well-known/citizen-telemetry"),
        t_payload,
    )
    phase("telemetry_upload", t_ok, t_detail or "queued locally")

    artifacts = discover_update_artifacts(include_all_local=True)
    proj = living_update_projection()
    current_ver = proj["current_version"]
    target_ver = proj["target_version"]
    sync_failure_reason = ""
    evolution_row = None
    updated = False
    sync_ok = True
    terminal_state = UpdateState.NOOP.value

    class_out = _apply_class_package_sync()
    if class_out is not None:
        result.update(class_out)
        result["ok"] = bool(class_out.get("ok"))
        result["sync_failed"] = not result["ok"]
        result["current_version"] = class_out.get("living_version") or current_ver
        result["target_version"] = target_ver
        result["update_available"] = False if result["ok"] else proj.get("update_available")
        result["sync_required"] = False
        result["evolution_status"] = class_out.get("state")
        result["alive_status"] = "Alive"
        result["cluster_connection"] = connection_label(last_connection().get("connection"))
        result["sync_state"] = class_out.get("state")
        return result

    if proj.get("target_behind_current"):
        phase("update_check", True, "TARGET_BEHIND_CURRENT — refuse silent downgrade")
        phase("synchronization", True, "NOOP")
        terminal_state = "TARGET_BEHIND_CURRENT"
        _commit_terminal_sync_state(
            terminal_state,
            identity_preserved=True,
            history_preserved=True,
            version_preserved=current_ver,
        )
    elif not proj.get("update_available"):
        phase("update_check", True, "current == target")
        phase("synchronization", True, "NOOP")
        terminal_state = UpdateState.NOOP.value
        _commit_terminal_sync_state(
            terminal_state,
            identity_preserved=True,
            history_preserved=True,
            version_preserved=current_ver,
        )
    else:
        existing = load_plan(HOME)
        if (
            existing
            and str(existing.get("status") or "") in IN_PROGRESS_PLAN_STATUSES
            and str(existing.get("target_version") or "") == target_ver
        ):
            plan = existing
            plan["status"] = "applying"
        else:
            plan_artifacts = []
            for art in artifacts:
                ver = str(art.get("version") or "").lstrip("v")
                if not ver:
                    continue
                if art.get("kind") == "pending" and not art.get("path"):
                    continue
                plan_artifacts.append(art)
            plan = build_evolution_plan(
                source_version=current_ver,
                target_version=target_ver,
                artifacts=plan_artifacts,
            )
        save_plan(HOME, plan)
        phase("update_check", True, f"{current_ver} → {target_ver} steps={plan.get('total_steps')}")
        if not plan.get("steps"):
            sync_ok = False
            sync_failure_reason = "unplannable evolution: no compatible artifacts"
            terminal_state = UpdateState.SYNC_FAILED.value
            phase("synchronization", False, sync_failure_reason)
            _commit_terminal_sync_state(
                terminal_state,
                reason=sync_failure_reason,
                identity_preserved=True,
                history_preserved=True,
                version_preserved=current_ver,
            )
        else:
            applied = apply_evolution_plan(
                plan, caps_before=caps_before, avail_before=avail_before
            )
            sync_ok = bool(applied.get("ok"))
            updated = bool(applied.get("updated"))
            evolution_row = applied.get("evolution")
            current_ver = str(applied.get("living_version") or seed_version())
            if sync_ok:
                terminal_state = (
                    UpdateState.UPDATED.value if updated else UpdateState.NOOP.value
                )
                phase("synchronization", True, terminal_state)
                _commit_terminal_sync_state(
                    terminal_state,
                    identity_preserved=True,
                    history_preserved=True,
                    version_preserved=current_ver,
                    source_version=version_before,
                    target_version=target_ver,
                )
                if updated:
                    clear_pending_update()
            else:
                terminal_state = UpdateState.SYNC_FAILED.value
                sync_failure_reason = str(applied.get("error") or "evolution step failed")
                phase("synchronization", False, sync_failure_reason)
                failed_plan = applied.get("plan") or plan
                _commit_terminal_sync_state(
                    terminal_state,
                    reason=sync_failure_reason,
                    identity_preserved=True,
                    history_preserved=True,
                    version_preserved=current_ver,
                    failed_step=failed_plan.get("failed_step"),
                    source_version=failed_plan.get("source_version"),
                    target_version=failed_plan.get("target_version"),
                    phase=failed_plan.get("phase"),
                )

    connected = ok
    set_connection(connected)
    ver = seed_version()
    capability_change = _capability_change_after_sync(caps_before, applied=updated)
    if not sync_ok:
        emit_event(
            "sync_failed",
            f"SYNC failed: {sync_failure_reason}"[:200],
            reason=sync_failure_reason,
            version_preserved=ver,
            identity_preserved=True,
            history_preserved=True,
        )
    emit_event(
        "sync_complete",
        "SYNC finished",
        connected=connected,
        alive=True,
        update_available=False if updated else avail_before.get("update_available"),
        phases=[p["phase"] for p in result["phases"]],
        sync_state=terminal_state,
    )
    sync_rec = {
        "ts": utc_now(),
        "phases": result["phases"],
        "cluster": "Connected" if connected else "Offline",
        "alive": True,
        "version": ver,
        "evolution_evidence_id": (evolution_row or {}).get("evidence_id"),
        "sync_state": terminal_state,
        "sync_failed": not sync_ok,
        "sync_failure_reason": sync_failure_reason if not sync_ok else None,
        "capability_change": capability_change,
        "current_version": ver,
        "target_version": target_ver,
        "runtime_version": RUNTIME_VERSION,
    }
    (ops_dir() / "LAST_SYNC.json").write_text(json.dumps(sync_rec, indent=2) + "\n", encoding="utf-8")
    avail_after = update_availability()
    result["cluster_connection"] = "Connected" if connected else "Offline"
    result["alive_status"] = "Alive"
    result["update_available"] = bool(avail_after.get("update_available"))
    result["sync_required"] = bool(avail_after.get("sync_required"))
    result["current_version"] = ver
    result["target_version"] = avail_after.get("target_version") or target_ver
    result["runtime_version"] = RUNTIME_VERSION
    result["evolution"] = evolution_row
    result["sync_state"] = terminal_state
    result["sync_failed"] = not sync_ok
    result["sync_failure_reason"] = sync_failure_reason if not sync_ok else None
    result["capability_change"] = capability_change
    result["evolution_status"] = living_update_projection().get("evolution_status")
    result["ok"] = sync_ok
    result["duplicate"] = False
    return result


def telemetry_organ_loop(interval: float = 30.0) -> None:
    """Permanent telemetry organ — active for the life of the process."""
    ops_dir().joinpath("TELEMETRY_ORGAN_ACTIVE").write_text(utc_now() + "\n", encoding="utf-8")
    emit_event("telemetry_organ", "Telemetry organ active for life of Citizen process")
    path = ops_dir() / "telemetry_organ.jsonl"
    while not _TELEMETRY_STOP.is_set():
        pulse = {
            "ts": utc_now(),
            "organ": "telemetry",
            "status": "active",
            "citizen_id": load_identity().get("citizen_id"),
            "alive": True,
            "port": UI_PORT,
            "heartbeat": True,
        }
        with _LOCK:
            with path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(pulse, sort_keys=True) + "\n")
        # Best-effort edge drip; never stop on failure
        http_post_json(
            os.environ.get("CITIZEN_TELEMETRY_URL", f"{EDGE}/.well-known/citizen-telemetry"),
            {"kind": "organ_pulse", **pulse},
            timeout=3.0,
        )
        _TELEMETRY_STOP.wait(interval)
    emit_event("telemetry_organ", "Telemetry organ stopped (process exit)")


def life_state() -> dict:
    """Read-only composition of identity, history, and evidence. Does not persist."""
    try:
        from conrrad_citizen._ops.life import compose_life
    except ImportError:  # deployed ops copy next to this file
        from life import compose_life  # type: ignore

    body = compose_life(HOME)
    ident = load_identity()
    sealed = (HOME / "identity" / "SEALED").is_file()
    born = (HOME / "boot" / "BOOTSTRAP_DISARMED").is_file()
    proj = living_update_projection()
    body["current_version"] = proj["current_version"]
    body["target_version"] = proj["target_version"]
    body["runtime_version"] = proj["runtime_version"]
    body["living_version"] = proj["living_version"]
    body["update_available"] = proj["update_available"]
    body["sync_required"] = proj["sync_required"]
    body["sync_status"] = proj["sync_status"]
    body["evolution_status"] = proj["evolution_status"]
    body["update_status"] = proj["update_status"]
    body["citizen"] = {
        "citizen_id": ident.get("citizen_id"),
        "state": "READY" if sealed and born else ("Not Born" if not born else "Alive"),
        "version": proj["current_version"],
        "runtime_version": proj["runtime_version"],
        "living_version": proj["living_version"],
        "current_version": proj["current_version"],
        "target_version": proj["target_version"],
        "update_available": proj["update_available"],
        "sync_required": proj["sync_required"],
        "update_status": proj["update_status"],
        "sync_status": proj["sync_status"],
        "evolution_status": proj["evolution_status"],
        "capabilities": _capability_projection().get("capabilities") or [],
    }
    return body


def console_state() -> dict:
    ensure_birth_evolution()
    ident = load_identity()
    sealed = (HOME / "identity" / "SEALED").is_file()
    born = (HOME / "boot" / "BOOTSTRAP_DISARMED").is_file()
    alive = sealed and born
    conn = last_connection()
    cluster = connection_label(conn.get("connection"))
    hb_count = file_line_count(ops_dir() / "heartbeat.jsonl")
    birth_ts = ident.get("created_utc") or (
        (HOME / "boot" / "BIRTH_TS").read_text(encoding="utf-8").strip()
        if (HOME / "boot" / "BIRTH_TS").is_file()
        else "—"
    )
    proj = living_update_projection()
    ver = proj["current_version"]
    line = evolutionary_line(ver)
    hist = read_evolution_history()
    latest_date = "—"
    for row in reversed(hist):
        if row.get("ts"):
            latest_date = row["ts"]
            break
    if proj.get("update_release"):
        latest_date = str(proj["update_release"])

    return {
        "logo": "/logo.png",
        "citizen_seed_version": ver,
        "runtime_version": proj["runtime_version"],
        "living_version": proj["living_version"],
        "citizen_id": ident.get("citizen_id", "—"),
        "birth_hash": birth_hash(ident),
        "birth_timestamp": birth_ts,
        "citizen_age": citizen_age(birth_ts),
        "alive_status": "Alive" if alive else "Not Born",
        "cluster_connection_status": cluster,
        "node": os.environ.get("CITIZEN_NODE_ID", "local"),
        "identity_status": "sealed" if sealed else "missing",
        "heartbeat": hb_count,
        "last_sync": last_sync_ts(),
        "telemetry_status": organ_status(HOME, "telemetry"),
        "memory_status": organ_status(HOME, "memory"),
        "filesystem_status": organ_status(HOME, "filesystem"),
        "evidence_status": organ_status(HOME, "evidence"),
        "ui_host": UI_HOST,
        "ui_port": UI_PORT,
        "ui_url": f"http://{UI_HOST}:{UI_PORT}/",
        "is_alive": alive,
        "is_connected": cluster == "Connected",
        "memory_size_bytes": dir_bytes(HOME),
        "institution": ident.get("institution", "Citizen"),
        "current_version": ver,
        "current_version_label": f"v{ver}",
        "target_version": proj["target_version"],
        "latest_evolution": proj["target_version"] if proj["update_available"] else ver,
        "available_version": proj["target_version"],
        "evolution_date": latest_date,
        "update_available": bool(proj["update_available"]),
        "sync_required": bool(proj["sync_required"]),
        "update_status": proj["update_status"],
        "sync_status": proj["sync_status"],
        "evolution_status": proj["evolution_status"],
        "update_label": "Update Available" if proj["update_available"] else "",
        "sync_color": line["sync_color"],
        "evolutionary_line": line["label"],
        "badge": line["badge"],
        "badge_class": line["badge_class"],
        "evolution_history": hist,
        "sync_status_label": proj["sync_status"],
        "model_artifact_available": _model_artifact_available(),
        "capabilities": _capability_projection(),
        "sync_state": {
            **_projected_sync_state(),
            "state": proj["sync_status"],
        },
        "target_behind_current": bool(proj.get("target_behind_current")),
        "current_step": proj.get("current_step"),
        "total_steps": proj.get("total_steps"),
        "step_label": proj.get("step_label"),
    }


def _projected_sync_state() -> dict:
    """UI-facing Sync state — always the file the runtime last wrote."""
    path = HOME / "ui" / "sync_state.json"
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass
    last = ops_dir() / "LAST_SYNC.json"
    if last.is_file():
        try:
            rec = json.loads(last.read_text(encoding="utf-8"))
            return {
                "state": rec.get("sync_state") or "Current",
                "reason": rec.get("sync_failure_reason"),
                "color": "red" if rec.get("sync_failed") else "green",
            }
        except json.JSONDecodeError:
            pass
    return {"state": "Current", "color": "green"}


def _local_update_feed() -> dict:
    """Minimum working local feed. No envelope — apply stays on UpdateEngine."""
    feed_path = _updates_dir() / "citizen-update.json"
    if feed_path.is_file():
        try:
            data = json.loads(feed_path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass
    cand = scan_local_update_candidate()
    if cand:
        return {
            "update_available": True,
            "available": True,
            "version": cand.get("version"),
            "release": cand.get("release"),
            "source": "local",
        }
    return {"update_available": False, "available": False, "source": "local"}


def _capability_change_after_sync(caps_before: list, *, applied: bool) -> dict:
    """Project previous → updated capabilities so an evolution is observable."""
    caps_after = _capability_projection().get("capabilities") or []
    try:
        from citizen_seed.work import capability_state

        satisfied = capability_state.clear_satisfied_requests(HOME) if applied else []
        if satisfied:
            caps_after = _capability_projection().get("capabilities") or []
        diff = capability_state.diff_capabilities(caps_before, caps_after)
    except Exception:
        satisfied = []
        diff = {"new": [], "changed": [], "preserved": [], "removed": []}
    return {**diff, "acquired_after_sync": satisfied}


def _capability_projection() -> dict:
    """Capability state as the runtime sees it. Empty on failure, never faked."""
    try:
        from citizen_seed.work import capability_state

        return capability_state.project(HOME)
    except Exception:
        return {"capabilities": [], "counts": {}}


def _model_artifact_available() -> bool:
    try:
        from citizen_seed.work.models.loader import default_artifact_path

        return default_artifact_path().is_file()
    except Exception:
        return False



class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args) -> None:
        pass

    def _send(self, code: int, body: bytes, ctype: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_HEAD(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        web = OPS_ROOT / "web"
        mapping = {
            "/": (web / "index.html", "text/html; charset=utf-8"),
            "/index.html": (web / "index.html", "text/html; charset=utf-8"),
            "/style.css": (web / "style.css", "text/css"),
            "/app.js": (web / "app.js", "application/javascript"),
            "/logo.png": (web / "logo.png", "image/png"),
        }
        if path in mapping:
            f, ctype = mapping[path]
            if f.is_file():
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(f.stat().st_size))
                self.end_headers()
                return
        self.send_error(404)

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        web = OPS_ROOT / "web"
        if path in {"/", "/index.html"}:
            return self._send(200, (web / "index.html").read_bytes(), "text/html; charset=utf-8")
        if path == "/style.css":
            return self._send(200, (web / "style.css").read_bytes(), "text/css")
        if path == "/app.js":
            return self._send(200, (web / "app.js").read_bytes(), "application/javascript")
        if path == "/logo.png":
            logo = web / "logo.png"
            if logo.is_file():
                return self._send(200, logo.read_bytes(), "image/png")
            return self.send_error(404)
        if path in {"/api/living", "/api/console"}:
            return self._send(200, json.dumps(console_state()).encode(), "application/json")
        if path == "/api/life":
            return self._send(200, json.dumps(life_state()).encode(), "application/json")
        if path == "/api/evolution":
            ensure_birth_evolution()
            return self._send(
                200,
                json.dumps({"history": read_evolution_history()}).encode(),
                "application/json",
            )
        if path == "/api/events":
            return self._send(200, json.dumps({"events": read_events()}).encode(), "application/json")
        if path == "/api/capabilities":
            return self._send(
                200, json.dumps(_capability_projection()).encode(), "application/json"
            )
        if path in {"/.well-known/citizen-update", "/.well-known/citizen-update.json"}:
            return self._send(
                200, json.dumps(_local_update_feed()).encode(), "application/json"
            )
        if path == "/api/wake":
            return self._send(200, json.dumps(wake()).encode(), "application/json")
        self.send_error(404)


    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/api/sync":
            self._read_json()
            return self._send(200, json.dumps(sync_cycle()).encode(), "application/json")
        if path == "/api/capability/request":
            from citizen_seed.work import capability_state

            body = self._read_json()
            capability_id = str(body.get("capability_id") or body.get("capability") or "")
            out = capability_state.request_capability(HOME, capability_id)
            out["capabilities"] = _capability_projection().get("capabilities") or []
            return self._send(
                200 if out.get("ok") else 400,
                json.dumps(out).encode(),
                "application/json",
            )
        if path == "/api/live/interpret":
            body = self._read_json()
            text = body.get("text")
            if not isinstance(text, str):
                return self._send(
                    400,
                    json.dumps({"ok": False, "status": "BLOCKED", "reason": "INVALID_TEXT"}).encode(),
                    "application/json",
                )
            from citizen_seed.cognitive.live import interpret as live_interpret

            out = live_interpret(
                HOME,
                text=text,
                session_id=str(body.get("session_id") or ""),
                source=str(body.get("source") or "text"),
            )
            return self._send(200, json.dumps(out).encode(), "application/json")
        if path == "/api/work":
            body = self._read_json()
            capability_id = str(
                body.get("capability_id")
                or body.get("capability")
                or "evidence.integrity_digest"
            )
            input_payload = body.get("input")
            implementation_id = body.get("implementation_id")
            if input_payload is not None and not isinstance(input_payload, dict):
                return self._send(
                    400,
                    json.dumps(
                        {"ok": False, "status": "BLOCKED", "reason": "INVALID_INPUT"}
                    ).encode(),
                    "application/json",
                )
            from citizen_seed.work import submit_work

            out = submit_work(
                HOME,
                capability_id=capability_id,
                input_payload=input_payload if isinstance(input_payload, dict) else None,
                implementation_id=str(implementation_id) if implementation_id else None,
            )
            return self._send(200, json.dumps(out).encode(), "application/json")
        self.send_error(404)


def main(argv: list[str] | None = None) -> int:
    global UI_HOST, UI_PORT, HOME

    parser = argparse.ArgumentParser(description="Citizen Console (living organism UI)")
    parser.add_argument("--host", default=os.environ.get("CITIZEN_UI_HOST", "127.0.0.1"))
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("CITIZEN_UI_PORT", "3434")),
        help="UI port (default 3434; fully configurable)",
    )
    parser.add_argument("--home", default=str(HOME))
    args = parser.parse_args(argv)

    HOME = Path(args.home).expanduser()
    os.environ["CITIZEN_HOME"] = str(HOME)
    UI_HOST = args.host
    UI_PORT = args.port
    os.environ["CITIZEN_UI_HOST"] = UI_HOST
    os.environ["CITIZEN_UI_PORT"] = str(UI_PORT)

    print("== Citizen Console 0.1 ==", flush=True)
    print(f"home: {HOME}", flush=True)
    print(f"port: {UI_PORT} (configurable; default 3434)", flush=True)

    report = wake()
    print(json.dumps({"wake_ready": report.get("ready"), "connection": report.get("connection")}), flush=True)
    if not report.get("ready"):
        print("Citizen not ready — complete Birth with ./install.sh", file=sys.stderr)
        return 2

    # Permanent telemetry organ
    t = threading.Thread(target=telemetry_organ_loop, kwargs={"interval": 30.0}, daemon=True)
    t.start()

    url = f"http://{UI_HOST}:{UI_PORT}/"
    print(json.dumps({"ui": url, "note": "Citizen Console — organism, not dashboard"}), flush=True)
    if os.environ.get("CITIZEN_OPEN_BROWSER", "1") not in {"0", "false", "no"}:
        try:
            webbrowser.open(url)
        except Exception:
            pass

    class ReuseHTTPServer(ThreadingHTTPServer):
        allow_reuse_address = True

    try:
        httpd = ReuseHTTPServer((UI_HOST, UI_PORT), Handler)
        httpd.serve_forever()
    finally:
        _TELEMETRY_STOP.set()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
