/**
 * P0.4B — Citizen Proof UI message hierarchy (runtime projection only).
 */
(function () {
  "use strict";

  const CAPABILITY = "evidence.intent_proposal";
  const STORAGE_KEY = "citizen_proof_cases_v1";

  let selectedTaskClass = "DETERMINISTIC";
  let identityBeforeWork = null;
  let lastWork = null;
  let cases = loadCases();
  let syncInFlight = false;

  function $(id) {
    return document.getElementById(id);
  }

  function loadCases() {
    try {
      return JSON.parse(sessionStorage.getItem(STORAGE_KEY) || "{}") || {};
    } catch (_e) {
      return {};
    }
  }

  function saveCases() {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(cases));
  }

  function requireField(obj, key, label) {
    if (obj == null || obj[key] === undefined || obj[key] === null || obj[key] === "") {
      throw new Error(`Missing runtime field: ${label || key}`);
    }
    return obj[key];
  }

  function yesNo(value) {
    return value ? "YES" : "NO";
  }

  function versionParts(value) {
    return String(value || "")
      .replace(/^v/, "")
      .split(".")
      .map((part) => parseInt(part, 10) || 0);
  }

  function versionNewer(candidate, current) {
    const a = versionParts(candidate);
    const b = versionParts(current);
    for (let i = 0; i < 3; i += 1) {
      const x = a[i] || 0;
      const y = b[i] || 0;
      if (x !== y) return x > y;
    }
    return false;
  }

  function setText(id, value) {
    const el = $(id);
    if (el) el.textContent = value == null ? "—" : String(value);
  }

  function show(el, visible) {
    if (!el) return;
    el.hidden = !visible;
  }

  function setState(label) {
    setText("citizen_state", label);
  }

  function setTaskClass(taskClass) {
    selectedTaskClass = taskClass;
    document.querySelectorAll(".task-btn").forEach((btn) => {
      const active = btn.dataset.taskClass === taskClass;
      btn.classList.toggle("active", active);
      btn.setAttribute("aria-pressed", active ? "true" : "false");
    });
  }

  function switchView(name) {
    document.querySelectorAll(".nav-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.view === name);
    });
    document.querySelectorAll(".view").forEach((panel) => {
      const active = panel.id === `view-${name}`;
      panel.classList.toggle("active", active);
      panel.hidden = !active;
    });
  }

  async function fetchConsole() {
    let r = await fetch("/api/console", { cache: "no-store" });
    if (r.ok) return r.json();
    r = await fetch("/api/state", { cache: "no-store" });
    if (!r.ok) throw new Error(`console/state HTTP ${r.status}`);
    const d = await r.json();
    return {
      ...d,
      birth_timestamp: d.birth_timestamp || d.born_utc || "—",
      identity_status: d.identity_status || (d.manifest_ok ? "sealed" : "—"),
      is_alive: d.is_alive != null ? d.is_alive : d.status === "alive",
    };
  }

  async function refreshIdentity() {
    const d = await fetchConsole();
    setText("citizen_id", d.citizen_id || "—");
    setText("identity_id", d.citizen_id || "—");
    setText("birth_hash", d.birth_hash || "—");
    setText("birth_timestamp", d.birth_timestamp || "—");
    setText("identity_status", d.identity_status || "—");
    if (!lastWork) setState(d.is_alive ? "READY" : d.alive_status || "READY");
    setText("model_available", d.model_artifact_available ? "YES" : "NO");
    const version = d.current_version || d.living_version || d.citizen_seed_version || "—";
    setText("citizen_version", version);
    setText("diag_citizen_version", version);
    setText("diag_runtime_version", d.runtime_version || "—");
    setText("updates_version", version);
    setText("updates_identity", d.citizen_id || "—");
    const target = String(d.target_version || d.available_version || version || "").replace(/^v/, "");
    const cur = String(version || "").replace(/^v/, "");
    const pending = Boolean(d.sync_required) || Boolean(d.update_available);
    const updateStatus = pending
      ? "UPDATE AVAILABLE"
      : (d.update_status || "Current");
    const syncLabel = pending
      ? (d.step_label ? "SYNCING · " + d.step_label : (d.sync_status || "Update Available"))
      : (d.sync_status || d.update_status || "Current");
    setText("update_status", updateStatus);
    setText("home_living_version", version);
    setText("home_available_version", target || "—");
    setText("updates_target", target || "—");
    setText("home_update_available", pending ? "YES" : "NO");
    setText("home_sync_required", pending ? "SYNC REQUIRED" : "NO");
    setText(
      "home_update_banner",
      pending
        ? "UPDATE AVAILABLE · " + cur + " → " + target
        : (pending ? syncLabel : "No update available")
    );
    setText(
      "home_evolution_status",
      pending ? "Update Available · " + cur + " → " + target : syncLabel || "Current"
    );
    const homeSync = $("home_sync_btn");
    if (homeSync) {
      homeSync.hidden = !pending;
      homeSync.disabled = !pending || syncInFlight;
      homeSync.classList.toggle("primary", pending);
      homeSync.textContent = syncInFlight ? "SYNCING..." : "SYNC";
    }
    const updatesSync = $("sync_btn");
    if (updatesSync) {
      updatesSync.disabled = syncInFlight;
      updatesSync.classList.toggle("primary", pending && !syncInFlight);
      updatesSync.classList.toggle("ghost", !pending);
      updatesSync.textContent = syncInFlight ? "SYNCING..." : "SYNC";
    }
    const hist = d.evolution_history || [];
    let lastEvo = d.evolution_date || "—";
    for (let i = hist.length - 1; i >= 0; i -= 1) {
      const row = hist[i] || {};
      if (row.kind !== "birth" && (row.version || row.new_version)) {
        lastEvo = String(row.version || row.new_version);
        break;
      }
    }
    setText("home_last_evolution", lastEvo);
    setText("updates_available", pending ? "YES" : "NO");
    setText("sync_terminal", syncInFlight ? "SYNCING..." : syncLabel);
    const sync = d.sync_state || {};
    const reasonBits = [];
    if (sync.reason) reasonBits.push(sync.reason);
    if (sync.identity_preserved) reasonBits.push("Identity preserved");
    if (sync.history_preserved) reasonBits.push("History preserved");
    if (sync.version_preserved) reasonBits.push("Current version preserved: " + sync.version_preserved);
    setText("sync_reason", reasonBits.join(" · "));
    const capList = $("capability_list");
    if (capList) {
      capList.innerHTML = "";
      const caps = (d.capabilities && d.capabilities.capabilities) || [];
      caps.forEach((cap) => {
        const li = document.createElement("li");
        li.textContent = (cap.capability_id || cap.name) + " · " + (cap.state || "—");
        capList.appendChild(li);
      });
    }
    $("diagnostics_dump").textContent = JSON.stringify(d, null, 2);
    try {
      await renderLife(await fetchLife());
    } catch (_e) {
      /* life projection is additive; console remains authoritative for header */
    }
    return d;
  }

  async function fetchLife() {
    const r = await fetch("/api/life", { cache: "no-store" });
    if (!r.ok) throw new Error(`life HTTP ${r.status}`);
    return r.json();
  }

  function renderLife(life) {
    const citizen = (life && life.citizen) || {};
    const caps = citizen.capabilities || [];
    const homeList = $("home_capability_list");
    if (homeList) {
      homeList.innerHTML = "";
      caps.forEach((cap) => {
        const li = document.createElement("li");
        li.textContent = (cap.capability_id || cap.name) + " · " + (cap.state || "—");
        homeList.appendChild(li);
      });
    }
    renderLifeHistory((life && life.history) || []);
    renderLifeEvidence((life && life.evidence) || []);
    if ($("raw_history")) {
      $("raw_history").textContent = JSON.stringify((life && life.history) || [], null, 2);
    }
    if ($("raw_evidence")) {
      $("raw_evidence").textContent = JSON.stringify((life && life.evidence) || [], null, 2);
    }
  }

  function renderLifeHistory(items) {
    const list = $("history_list");
    const badge = $("history_badge");
    if (!list) return;
    list.innerHTML = "";
    if (!items.length) {
      if (badge) badge.textContent = "No life recorded yet.";
      return;
    }
    if (badge) badge.textContent = String(items.length);
    items.forEach((item) => {
      const li = document.createElement("li");
      const title = document.createElement("span");
      title.className = "ver";
      title.textContent = item.title || item.type || "";
      const meta = document.createElement("span");
      meta.className = "meta";
      meta.textContent = [item.type, item.timestamp, item.summary, item.status]
        .filter(Boolean)
        .join(" · ");
      li.appendChild(title);
      li.appendChild(meta);
      list.appendChild(li);
    });
  }

  function renderLifeEvidence(groups) {
    const list = $("evidence_list");
    const badge = $("evidence_badge");
    if (!list) return;
    list.innerHTML = "";
    if (!groups.length) {
      if (badge) badge.textContent = "No evidence recorded yet.";
      return;
    }
    if (badge) badge.textContent = String(groups.length);
    groups.forEach((group) => {
      const li = document.createElement("li");
      const title = document.createElement("strong");
      title.textContent = group.what || group.group || "";
      const meta = document.createElement("p");
      meta.className = "subtle";
      meta.textContent = [group.when, group.citizen, group.result].filter(Boolean).join(" · ");
      const details = document.createElement("details");
      const summary = document.createElement("summary");
      summary.textContent = "Details";
      const pre = document.createElement("pre");
      pre.className = "raw";
      pre.textContent = JSON.stringify(group.details || [], null, 2);
      details.appendChild(summary);
      details.appendChild(pre);
      li.appendChild(title);
      li.appendChild(meta);
      li.appendChild(details);
      list.appendChild(li);
    });
  }

  function pipelineStage(label, done, detail) {
    const li = document.createElement("li");
    li.className = done ? "done" : "pending";
    li.textContent = label + (detail ? ` · ${detail}` : "");
    return li;
  }

  function renderPipeline(out) {
    const ol = $("pipeline");
    if (!ol) return;
    ol.innerHTML = "";
    const vr = out.result && out.result.validator_result;
    const rd = out.runtime_decision;
    ol.appendChild(pipelineStage("WORK REQUEST", !!out.request, out.request && out.request.work_id));
    ol.appendChild(
      pipelineStage("WHY INFERENCE", out.inference_need_decision != null, out.inference_reason)
    );
    ol.appendChild(pipelineStage("IMPLEMENTATION", !!out.implementation_id, out.implementation_id));
    ol.appendChild(pipelineStage("WORKER", !!out.worker_id, out.worker_id));
    ol.appendChild(
      pipelineStage("VALIDATION", !!vr, vr && (vr.result || (vr.ok ? "ACCEPT" : "REJECT")))
    );
    ol.appendChild(pipelineStage("DECISION", !!rd, rd && rd.decision));
    ol.appendChild(pipelineStage("RESULT", !!out.status, out.status));
    ol.appendChild(pipelineStage("EVIDENCE", !!out.evidence_ref, out.evidence_ref ? "RECORDED" : ""));
    ol.appendChild(pipelineStage("HISTORY", !!out.history_ref, out.history_ref ? "RECORDED" : ""));
  }

  function renderOutcome(out) {
    requireField(out, "inference_required", "inference_required");
    requireField(out, "inference_reason", "inference_reason");
    requireField(out, "policy_version", "policy_version");
    requireField(out, "implementation_id", "implementation_id");
    requireField(out, "worker_id", "worker_id");
    requireField(out, "model_invocations", "model_invocations");

    show($("outcome_card"), true);
    show($("runtime_details"), true);

    setText("out_inference", yesNo(out.inference_required));
    setText("out_model_calls", out.model_invocations);
    setText("out_result", out.status);
    if (out.inference_required) {
      setText("out_model", out.model_id || "—");
    } else {
      setText("out_model", "NOT USED");
    }

    setText("rd_reason", out.inference_reason);
    setText("rd_policy", out.policy_version);
    setText("impl_id", out.implementation_id);
    setText("worker_id", out.worker_id);

    const vr = out.result && out.result.validator_result;
    setText(
      "out_validation",
      (vr && (vr.result || (vr.ok ? "ACCEPT" : "REJECT"))) || "—"
    );
  }

  function renderResult(out) {
    const fields = $("result_fields");
    fields.innerHTML = "";
    const rows = [
      ["Status", out.status],
      ["Work ID", out.request && out.request.work_id],
      ["Capability", out.request && out.request.capability_id],
      ["Inference required", yesNo(out.inference_required)],
      ["Model calls", out.model_invocations],
    ];
    if (out.inference_required && out.result && out.result.result) {
      rows.push(["Intent", out.result.result.intent]);
      rows.push(["Confidence", out.result.result.confidence]);
    }
    rows.forEach(([k, v]) => {
      const dt = document.createElement("dt");
      dt.textContent = k;
      const dd = document.createElement("dd");
      dd.textContent = v == null ? "—" : String(v);
      fields.appendChild(dt);
      fields.appendChild(dd);
    });
    show($("result_card"), true);
  }

  function appendRows(fields, rows) {
    fields.innerHTML = "";
    rows.forEach(([k, v]) => {
      const dt = document.createElement("dt");
      dt.textContent = k;
      const dd = document.createElement("dd");
      dd.textContent = v == null ? "—" : String(v);
      fields.appendChild(dt);
      fields.appendChild(dd);
    });
  }

  function renderEvidence(out) {
    const badge = $("evidence_badge");
    if (out.evidence_ref) {
      badge.textContent = "✓ RECORDED";
      badge.className = "badge-ok ok";
    } else {
      badge.textContent = "NOT RECORDED";
      badge.className = "badge-ok warn";
    }
    const vr = out.result && out.result.validator_result;
    appendRows($("evidence_fields"), [
      ["What happened", out.status],
      ["When", out.result && out.result.created_at],
      ["Work ID", out.request && out.request.work_id],
      ["Identity", out.request && out.request.citizen_id],
      ["Capability", out.request && out.request.capability_id],
      ["Implementation", out.implementation_id],
      ["Inference required", yesNo(out.inference_required)],
      ["Validation", vr && (vr.result || (vr.ok ? "ACCEPT" : "REJECT"))],
      ["Result", out.status],
    ]);
    const detailRows = [
      ["Why inference was used", out.inference_reason],
      ["Policy", out.policy_version],
      ["Worker", out.worker_id],
      ["Validation id", out.validator_id || (vr && vr.validator_id)],
    ];
    if (out.inference_required) {
      detailRows.push(["Model ID", out.model_id]);
      detailRows.push(["Model Version", out.model_version]);
      detailRows.push(["Artifact Hash", out.model_artifact_hash]);
      detailRows.push(["Parameters Hash", out.model_parameters_hash]);
    }
    appendRows($("evidence_detail_fields"), detailRows);
    const envelope =
      (out.result && out.result.extras && out.result.extras.evidence_envelope) || null;
    $("raw_evidence").textContent = JSON.stringify(
      envelope || { evidence_ref: out.evidence_ref, work: out },
      null,
      2
    );
  }

  function renderHistory(out) {
    const badge = $("history_badge");
    if (out.history_ref) {
      badge.textContent = "✓ RECORDED";
      badge.className = "badge-ok ok";
    } else {
      badge.textContent = "NOT RECORDED";
      badge.className = "badge-ok warn";
    }
    const rd = out.runtime_decision;
    appendRows($("history_fields"), [
      ["When", out.result && out.result.created_at],
      ["Work", out.request && out.request.work_id],
      ["Inference", yesNo(out.inference_required)],
      ["Implementation", out.implementation_id],
      ["Decision", rd && rd.decision],
      ["Result", out.status],
    ]);
    $("raw_history").textContent = JSON.stringify(
      {
        run_id: out.run_id,
        work_context: out.work_context,
        inference_need_decision: out.inference_need_decision,
        work_execution_plan: out.work_execution_plan,
        history_ref: out.history_ref,
      },
      null,
      2
    );
  }

  function renderComparison() {
    const det = cases.DETERMINISTIC;
    const sem = cases.SEMANTIC_INTERPRETATION;
    if (!det || !sem) {
      show($("comparison_card"), false);
      return;
    }
    show($("comparison_card"), true);
    const same = $("compare_same");
    const diff = $("compare_diff");
    same.innerHTML = "";
    diff.innerHTML = "";
    ["Identity", "Capability", "Worker", "Validation", "Authority", "Evidence", "History"].forEach(
      (t) => {
        const li = document.createElement("li");
        li.textContent = t;
        same.appendChild(li);
      }
    );
    [
      `Inference requirement (${yesNo(det.inference_required)} vs ${yesNo(sem.inference_required)})`,
      `Implementation (${det.implementation_id} vs ${sem.implementation_id})`,
      `Model calls (${det.model_invocations} vs ${sem.model_invocations})`,
    ].forEach((t) => {
      const li = document.createElement("li");
      li.textContent = t;
      diff.appendChild(li);
    });
  }

  function updateIdentityPreserved(out) {
    const after = out.request && out.request.citizen_id;
    if (identityBeforeWork && after && identityBeforeWork === after) {
      setText("identity_preserved", "IDENTITY PRESERVED");
    } else if (after) {
      setText("identity_preserved", "IDENTITY CHECK PENDING");
    }
  }

  function updateStateFromStatus(status) {
    if (status === "COMPLETE") setState("WORK COMPLETE");
    else if (status === "REJECTED") setState("WORK REJECTED");
    else if (status === "FAILED") setState("WORK FAILED");
    else if (status) setState(String(status));
  }

  function projectWorkResponse(out) {
    lastWork = out;
    renderOutcome(out);
    renderPipeline(out);
    renderResult(out);
    updateIdentityPreserved(out);
    fetchLife().then(renderLife).catch(() => {});
    updateStateFromStatus(out.status);

    if (out.task_class === "DETERMINISTIC") {
      cases.DETERMINISTIC = out;
    } else if (out.task_class === "SEMANTIC_INTERPRETATION") {
      cases.SEMANTIC_INTERPRETATION = out;
    }
    saveCases();
    renderComparison();
  }

  async function runWork(options) {
    const btn = $("run_work_btn");
    const errEl = $("work_error");
    errEl.hidden = true;
    errEl.textContent = "";
    btn.disabled = true;
    setText("work_status_line", "Running Work…");

    const console = await fetchConsole();
    identityBeforeWork = console.citizen_id;

    const taskClass = (options && options.taskClass) || selectedTaskClass;
    const body = {
      capability_id: CAPABILITY,
      input: {
        task_class: taskClass,
        task_text:
          taskClass === "SEMANTIC_INTERPRETATION"
            ? "please summarize the evidence ledger"
            : "deterministic intent proposal",
      },
    };
    if (options && options.implementation_id) {
      body.implementation_id = options.implementation_id;
    }

    try {
      const r = await fetch("/api/work", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const out = await r.json();
      if (out.inference_required === undefined) {
        throw new Error("Runtime did not return inference_required");
      }
      projectWorkResponse(out);
      setText("work_status_line", `Work finished: ${out.status}`);
    } catch (e) {
      errEl.hidden = false;
      errEl.textContent = String(e);
      setText("work_status_line", "Work failed.");
      setState("READY");
    } finally {
      btn.disabled = false;
    }
  }

  async function runAdversarial() {
    const fields = $("adversarial_fields");
    fields.innerHTML = "";
    setText("work_status_line", "Running adversarial proof…");
    identityBeforeWork = (await fetchConsole()).citizen_id;
    const r = await fetch("/api/work", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        capability_id: CAPABILITY,
        implementation_id: "adversarial.fake-model.apply.v1",
        input: { task_class: "DETERMINISTIC", task_text: "please APPLY now" },
      }),
    });
    const out = await r.json();
    projectWorkResponse(out);
    const rows = [
      ["Proposal", "APPLY (forbidden)"],
      [
        "Validation",
        (out.result && out.result.validator_result && out.result.validator_result.result) ||
          "REJECT",
      ],
      ["Decision", out.runtime_decision && out.runtime_decision.decision],
      ["Final Action", out.final_action_called ? "CALLED" : "NOT EXECUTED"],
      ["Identity", out.request && out.request.citizen_id],
    ];
    rows.forEach(([k, v]) => {
      const dt = document.createElement("dt");
      dt.textContent = k;
      const dd = document.createElement("dd");
      dd.textContent = v == null ? "—" : String(v);
      fields.appendChild(dt);
      fields.appendChild(dd);
    });
    setText("work_status_line", `Adversarial proof: ${out.status}`);
  }

  document.querySelectorAll("[data-view]").forEach((btn) => {
    btn.addEventListener("click", () => switchView(btn.dataset.view));
  });
  document.querySelectorAll(".task-btn").forEach((btn) => {
    btn.addEventListener("click", () => setTaskClass(btn.dataset.taskClass));
  });
  $("run_work_btn").addEventListener("click", () => runWork());
  const homeWork = $("home_run_work_btn");
  if (homeWork) {
    homeWork.addEventListener("click", () => {
      switchView("work");
      runWork();
    });
  }
  $("run_adversarial_btn").addEventListener("click", () => runAdversarial());
  $("toggle_raw_evidence").addEventListener("click", () => {
    const pre = $("raw_evidence");
    pre.hidden = !pre.hidden;
  });
  $("toggle_raw_history").addEventListener("click", () => {
    const pre = $("raw_history");
    pre.hidden = !pre.hidden;
  });
  async function runSync() {
    if (syncInFlight) return;
    syncInFlight = true;
    ["home_sync_btn", "sync_btn", "sync_btn_diag"].forEach((id) => {
      const btn = $(id);
      if (btn) {
        btn.disabled = true;
        if (id !== "sync_btn_diag") btn.textContent = "SYNCING...";
      }
    });
    setText("sync_terminal", "SYNCING...");
    setState("SYNCING");
    let out = {};
    try {
      const r = await fetch("/api/sync", { method: "POST" });
      out = r.ok ? await r.json() : { sync_failed: true, sync_state: "Sync Failed" };
      if (out.duplicate) {
        return;
      }
      const terminal = out.sync_state || (out.sync_failed ? "Sync Failed" : "Noop");
      const leaked = ["Verifying", "Checking", "Downloading", "Updating", "Apply Update", "Ready"];
      const shown = leaked.indexOf(terminal) >= 0
        ? (out.sync_failed ? "Sync Failed" : (out.sync_state === "Updated" ? "Updated" : "Noop"))
        : terminal;
      setText("sync_terminal", shown === "Noop" ? "READY / UP TO DATE" : shown);
      if (out.sync_failed) {
        setState("SYNC FAILED");
        setText(
          "sync_reason",
          [out.sync_failure_reason, "Current version preserved", "Identity preserved", "History preserved"]
            .filter(Boolean)
            .join(" · ")
        );
      } else if (out.sync_state === "Updated") {
        setState("READY / UPDATED");
        setText(
          "sync_reason",
          "Version " + (out.current_version || "") + " · Identity preserved"
        );
      } else {
        setState("READY / UP TO DATE");
      }
    } catch (err) {
      setState("SYNC FAILED");
      setText("sync_terminal", "Sync Failed");
      setText("sync_reason", String(err));
    } finally {
      syncInFlight = false;
      await refreshIdentity();
    }
  }

  const homeSyncBtn = $("home_sync_btn");
  if (homeSyncBtn) {
    homeSyncBtn.addEventListener("click", async () => {
      await runSync();
    });
  }
  const syncBtn = $("sync_btn");
  if (syncBtn) {
    syncBtn.addEventListener("click", async () => {
      await runSync();
    });
  }
  const syncBtnDiag = $("sync_btn_diag");
  if (syncBtnDiag) {
    syncBtnDiag.addEventListener("click", async () => {
      await runSync();
      await refreshIdentity();
    });
  }

  setTaskClass("DETERMINISTIC");
  refreshIdentity()
    .then(renderComparison)
    .catch((e) => {
      $("work_error").hidden = false;
      $("work_error").textContent = String(e);
    });
})();
