"""Canonical public-state adapter for the Citizen Ops/DTO layer.

The adapter consumes the INT-102 public-state envelope without redefining its
claims. It adds local fetch/cache/freshness metadata only; it never mutates
Citizen identity, Manifest, Runtime, or UpdateEngine state.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

REQUIRED_FIELDS = (
    "state_id",
    "subject",
    "value",
    "epistemic_status",
    "authority_ref",
    "evidence_refs",
    "source_version",
    "observed_at",
)
ALLOWED_EPISTEMIC = {
    "OBSERVED",
    "CERTIFIED",
    "PROPOSED",
    "ABSENT",
    "NOT_DETERMINABLE",
    "DEFERRED",
}
DEFAULT_ENDPOINT = "https://conrrad.org/.well-known/conrrad-state.json"
CACHE_FILENAME = "CANONICAL_STATE_CACHE.json"


def _parse_ts(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def validate_state(state: Any) -> tuple[bool, str]:
    if not isinstance(state, dict):
        return False, "state must be an object"
    missing = [key for key in REQUIRED_FIELDS if key not in state]
    if missing:
        return False, f"missing required fields: {','.join(missing)}"
    if state.get("epistemic_status") not in ALLOWED_EPISTEMIC:
        return False, "invalid epistemic_status"
    if not isinstance(state.get("evidence_refs"), list):
        return False, "evidence_refs must be a list"
    if not isinstance(state.get("state_id"), str) or not state["state_id"]:
        return False, "state_id must be a non-empty string"
    if _parse_ts(state.get("observed_at")) is None:
        return False, "observed_at is invalid"
    valid_until = state.get("valid_until")
    if valid_until is not None and _parse_ts(valid_until) is None:
        return False, "valid_until is invalid"
    return True, "ok"


def freshness_status(state: dict[str, Any], *, now: datetime | None = None) -> str:
    observed = _parse_ts(state.get("observed_at"))
    if observed is None:
        return "INVALID"
    now = now or datetime.now(timezone.utc)
    valid_until = _parse_ts(state.get("valid_until"))
    if valid_until is not None and now > valid_until:
        return "STALE"
    return "CURRENT"


def cache_path(ops_dir: Path) -> Path:
    return Path(ops_dir) / CACHE_FILENAME


def save_cache(ops_dir: Path, state: dict[str, Any], *, fetched_at: str) -> dict[str, Any]:
    payload = {
        "state": state,
        "cached_at": fetched_at,
        "source_version": state.get("source_version"),
        "observed_at": state.get("observed_at"),
        "projected_at": state.get("projected_at"),
        "valid_until": state.get("valid_until"),
    }
    path = cache_path(ops_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload


def load_cache(ops_dir: Path) -> dict[str, Any] | None:
    path = cache_path(ops_dir)
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    state = payload.get("state")
    ok, _ = validate_state(state)
    if not ok:
        return None
    return payload


def fetch_canonical_state(
    ops_dir: Path,
    *,
    endpoint: str | None = None,
    timeout: float = 3.0,
) -> dict[str, Any]:
    """Fetch INT-102 public state, falling back to a provenance-preserving cache."""
    url = endpoint or DEFAULT_ENDPOINT
    req = urllib.request.Request(url, method="GET", headers={"User-Agent": "CitizenState/0.1-DTO"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            state = json.loads(raw)
        ok, error = validate_state(state)
        if not ok:
            raise ValueError(error)
        fetched_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        cache = save_cache(ops_dir, state, fetched_at=fetched_at)
        return {
            "state": state,
            "status": freshness_status(state),
            "source": "live",
            "endpoint": url,
            "cache": cache,
            "error": None,
        }
    except (OSError, ValueError, json.JSONDecodeError, urllib.error.URLError) as exc:
        cache = load_cache(ops_dir)
        if cache is None:
            return {
                "state": None,
                "status": "OFFLINE",
                "source": "unavailable",
                "endpoint": url,
                "cache": None,
                "error": str(exc),
            }
        state = cache["state"]
        status = freshness_status(state)
        return {
            "state": state,
            "status": "STALE" if status == "STALE" else "OFFLINE",
            "source": "cache",
            "endpoint": url,
            "cache": cache,
            "error": str(exc),
        }
