"""Select the host adapter for this machine."""
from __future__ import annotations

import sys
from pathlib import Path

from .contract import HostResult
from .linux import LinuxHostAdapter
from .macos import MacHostAdapter
from .windows import WindowsHostAdapter


class UnsupportedHostAdapter:
    """Honest no-op host — no invented daemon."""

    def __init__(self, *, data_dir: Path, home: Path, **_: object) -> None:
        self.data_dir = Path(data_dir)
        self.home = Path(home)
        self._msg = (
            f"Host adapter is not implemented for {sys.platform}. "
            "Use 'citizen serve' on this platform."
        )

    def provision(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def start(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def stop(self) -> HostResult:
        return HostResult(True, "STOPPED", "No host service")

    def restart(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def status(self) -> HostResult:
        return HostResult(True, "unsupported", self._msg)

    def health(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def volume(self) -> dict[str, str]:
        return {"data_dir": str(self.data_dir), "home": str(self.home)}

    def network(self) -> dict[str, str]:
        return {"host": "127.0.0.1", "port": "3434"}

    def wait_health(self, attempts: int = 10, delay: float = 1.0) -> HostResult:
        return self.health()

    def logs(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def disable(self) -> HostResult:
        return HostResult(True, "REMOVED", "No host service")


def current_adapter(*, data_dir: Path, home: Path, **kwargs):
    if sys.platform.startswith("linux"):
        return LinuxHostAdapter(data_dir=data_dir, home=home, **kwargs)
    if sys.platform == "win32":
        return WindowsHostAdapter(data_dir=data_dir, home=home, **kwargs)
    if sys.platform == "darwin":
        return MacHostAdapter(data_dir=data_dir, home=home)
    return UnsupportedHostAdapter(data_dir=data_dir, home=home)
