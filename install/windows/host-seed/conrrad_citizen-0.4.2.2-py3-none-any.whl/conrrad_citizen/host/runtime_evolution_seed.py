"""RUNTIME_EVOLUTION_SEED — host-owned runtime replacement.

Not Citizen Life. Not UpdateEngine. Not HARLEMM / Sully / Omega / Worker / Model.
The seed discovers a host request, verifies a signed CLASS_PACKAGE, and asks
HostAdapter to replace the managed environment while preserving the volume.

Citizen runtime never invokes host isolation engines or Windows host tooling.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from citizen_seed.class_package import (
    ClassPackageError,
    discover_class_package,
    load_envelope,
    load_runtime_evolution_request,
    living_component_applicable,
    verify_class_package_envelope,
    write_runtime_evolution_request,
)
from conrrad_citizen.host.contract import HostResult
from conrrad_citizen.host.runtime_evolution import (
    apply_class_package,
    capture_life,
    current_image_digest,
    running_inside_environment,
)

SEED_OWNER = "HOST_ADAPTER"
SEED_ACTIONS = (
    "DISCOVER_RUNTIME_EVOLUTION_REQUEST",
    "VERIFY_SIGNED_PACKAGE",
    "RESOLVE_TARGET_RUNTIME",
    "REPLACE_MANAGED_ENVIRONMENT",
    "PRESERVE_CITIZEN_VOLUME",
    "HEALTH_CHECK",
    "ROLLBACK",
)


def discover_runtime_evolution_request(home: Path, updates_dir: Path | None = None) -> dict[str, Any]:
    """Find a persisted host request and/or CLASS_PACKAGE path. No network daemon."""
    home = Path(home)
    request = load_runtime_evolution_request(home)
    package = discover_class_package(updates_dir if updates_dir is not None else home / "updates")
    if package is None and request:
        ref = str(request.get("target_package_reference") or "").strip()
        if ref:
            candidate = Path(ref)
            if candidate.is_file():
                package = candidate
    return {
        "request": request,
        "envelope_path": package,
        "discovered": package is not None or request is not None,
    }


def apply_runtime_evolution_seed(
    *,
    host: Any,
    envelope: dict[str, Any] | None = None,
    envelope_path: Path | None = None,
    living_apply: Callable[..., dict[str, Any]] | None = None,
    linux_applier: Callable[..., HostResult] | None = None,
    resume: bool = True,
) -> HostResult:
    """Host entry: discover → verify → replace environment. Never Birth."""
    if running_inside_environment() and not os_allow_nested():
        home = Path(host.home)
        discovered = discover_runtime_evolution_request(home)
        path = envelope_path or discovered.get("envelope_path")
        write_runtime_evolution_request(
            home,
            citizen_id=_citizen_id(home),
            current_image_digest=current_image_digest(host),
            target_package_reference=str(path or ""),
            status="requested",
        )
        return HostResult(
            False,
            "HOST_RUNTIME_REPLACEMENT_REQUIRED",
            "Runtime replacement is host-owned. CLASS_PACKAGE verified; HostAdapter must apply.",
            {"birth": False, "SEED_OWNER": SEED_OWNER, "CITIZEN_PODMAN_AUTHORITY": False},
        )

    home = Path(host.home)
    data_dir = Path(getattr(host, "data_dir", home.parent))
    discovered = discover_runtime_evolution_request(home)
    path = Path(envelope_path) if envelope_path else discovered.get("envelope_path")
    if envelope is None and path is None:
        return HostResult(False, "FAILED", "no CLASS_PACKAGE or runtime evolution request", {"birth": False})

    if envelope is None:
        try:
            envelope = load_envelope(Path(path))
            verify_class_package_envelope(envelope)
            from conrrad_citizen.host.seed_receipts import append_receipt

            append_receipt(data_dir, "PACKAGE_VERIFIED")
        except ClassPackageError as exc:
            from conrrad_citizen.host.seed_receipts import append_receipt

            append_receipt(data_dir, "ERROR", code=exc.code, message=exc.message)
            return HostResult(False, exc.code, exc.message, {"birth": False, "VOLUME_PRESERVED": True})

    descriptor = envelope.get("descriptor") if isinstance(envelope, dict) else {}
    digest = current_image_digest(host)
    from citizen_seed import RUNTIME_VERSION

    before = capture_life(home, runtime_image_digest=digest or "", runtime_version=RUNTIME_VERSION)
    write_runtime_evolution_request(
        home,
        citizen_id=before.citizen_id,
        current_image_digest=before.runtime_image_digest,
        target_package_reference=str(path or descriptor.get("artifacts", {}).get("runtime_image") or ""),
        status="applying",
    )

    if callable(linux_applier):
        result = linux_applier(envelope)
    else:
        result = apply_class_package(
            host=host,
            envelope=envelope,
            envelope_path=Path(path) if path else None,
            living_apply=living_apply,
            resume=resume,
        )

    living_deferred = False
    if result.ok and isinstance(descriptor, dict):
        after = capture_life(
            home,
            runtime_image_digest=str(descriptor.get("target", {}).get("runtime_image_digest") or before.runtime_image_digest),
            runtime_version=RUNTIME_VERSION,
        )
        living_deferred = living_artifact_present_safe(descriptor) and not living_component_applicable(descriptor, after)
        write_runtime_evolution_request(
            home,
            citizen_id=after.citizen_id,
            current_image_digest=after.runtime_image_digest,
            target_package_reference=str(path or ""),
            status="deferred_living" if living_deferred else "complete",
        )
    elif not result.ok:
        write_runtime_evolution_request(
            home,
            citizen_id=before.citizen_id,
            current_image_digest=before.runtime_image_digest,
            target_package_reference=str(path or ""),
            status="failed" if result.state != "Rolled Back" else "rolled_back",
        )

    details = dict(result.details or {})
    details.update(
        {
            "SEED_OWNER": SEED_OWNER,
            "CITIZEN_PODMAN_AUTHORITY": False,
            "TWO_PHASE_INTERNAL_EVOLUTION": True,
            "LIVING_DEFERRED": living_deferred,
            "data_dir": str(data_dir),
        }
    )
    from conrrad_citizen.host.seed_receipts import append_receipt

    if result.ok:
        if details.get("runtime_replaced"):
            append_receipt(data_dir, "IMAGE_PREPARED", digest=details.get("runtime_image_digest"))
            append_receipt(data_dir, "ENVIRONMENT_SWITCHED")
        append_receipt(data_dir, "READY_AFTER_RUNTIME_EVOLUTION", birth=False)
    elif details.get("ROLLBACK"):
        append_receipt(data_dir, "ROLLBACK", message=result.message)
    else:
        append_receipt(data_dir, "ERROR", message=result.message)
    return HostResult(result.ok, result.state, result.message, details)


def living_artifact_present_safe(descriptor: dict[str, Any]) -> bool:
    from citizen_seed.class_package import living_artifact_present

    return living_artifact_present(descriptor)


def os_allow_nested() -> bool:
    import os

    return os.environ.get("CITIZEN_ALLOW_NESTED_REPLACEMENT", "") == "1"


def _citizen_id(home: Path) -> str:
    ident = Path(home) / "identity" / "identity.json"
    if not ident.is_file():
        return ""
    try:
        import json

        return str(json.loads(ident.read_text(encoding="utf-8")).get("citizen_id") or "")
    except (OSError, ValueError):
        return ""
