"""Host command runner for isolation backends. Never launches Citizen Python."""
from __future__ import annotations

import shutil
import subprocess

from conrrad_citizen.host.contract import HostResult


def which(name: str) -> str | None:
    return shutil.which(name)


def run_cmd(cmd: list[str], *, check: bool = True) -> HostResult:
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True)
    except FileNotFoundError as e:
        return HostResult(False, "FAILED", str(e), {"cmd": cmd})
    details = {
        "cmd": cmd,
        "returncode": proc.returncode,
        "stdout": proc.stdout or "",
        "stderr": proc.stderr or "",
    }
    if check and proc.returncode != 0:
        msg = (proc.stderr or proc.stdout or "command failed").strip()
        return HostResult(False, "FAILED", msg, details)
    return HostResult(True, "OK", "", details)
