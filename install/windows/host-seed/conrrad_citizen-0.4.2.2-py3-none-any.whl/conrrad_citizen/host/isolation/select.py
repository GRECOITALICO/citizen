"""Select an isolation backend. Never falls back to host Python Citizen runtime."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Callable

from conrrad_citizen.host.contract import HostResult
from conrrad_citizen.host.isolation.docker import DockerIsolationBackend
from conrrad_citizen.host.isolation.fake import FakeIsolationBackend
from conrrad_citizen.host.isolation.podman import PodmanIsolationBackend
from conrrad_citizen.host.isolation.unavailable import UnavailableIsolationBackend


def select_backend(
    *,
    volume: Path,
    host: str = "127.0.0.1",
    port: str | int = "3434",
    runner: Callable[..., HostResult] | None = None,
    requested: str | None = None,
):
    """Prefer rootless Podman, then an operational Docker engine, else unavailable.

    `CITIZEN_ISOLATION_BACKEND=fake|podman|docker|none` overrides auto-detect.
    Fake is test-only and is never implied by a missing engine.
    """
    name = (requested or os.environ.get("CITIZEN_ISOLATION_BACKEND") or "").strip().lower()
    kwargs = {"volume": Path(volume), "host": host, "port": port}
    if name == "fake":
        return FakeIsolationBackend(**kwargs)
    if name == "podman":
        return PodmanIsolationBackend(**kwargs, runner=runner)
    if name == "docker":
        return DockerIsolationBackend(**kwargs, runner=runner)
    if name in {"none", "unavailable"}:
        return UnavailableIsolationBackend("isolation backend disabled")

    podman = PodmanIsolationBackend(**kwargs, runner=runner)
    detected = podman.detect()
    if detected.available and detected.rootless:
        return podman

    docker = DockerIsolationBackend(**kwargs, runner=runner)
    docker_detected = docker.detect()
    if docker_detected.available:
        return docker

    if detected.available:
        return UnavailableIsolationBackend(
            "podman is present but not rootless; refusing a root-only isolation engine"
        )
    return UnavailableIsolationBackend(
        "No isolation backend available (need rootless Podman or an operational Docker engine)"
    )
