"""Persisted host bootstrap state. Never stores Citizen identity or Evidence."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

STATE_NAME = "bootstrap-state.json"


def state_path(data_dir: Path) -> Path:
    return Path(data_dir) / STATE_NAME


def load_state(data_dir: Path) -> dict[str, Any]:
    path = state_path(data_dir)
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def write_state(data_dir: Path, **fields: Any) -> dict[str, Any]:
    path = state_path(data_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    current = load_state(data_dir)
    current.update(fields)
    current["updated_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    path.write_text(json.dumps(current, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return current
