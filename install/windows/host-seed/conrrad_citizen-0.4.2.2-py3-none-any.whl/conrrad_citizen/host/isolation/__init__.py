"""Isolation backends: managed Citizen environment, not host Python."""

from .contract import IsolationBackend, IsolationDetect
from .docker import DockerIsolationBackend
from .fake import FakeIsolationBackend
from .podman import PodmanIsolationBackend
from .select import select_backend
from .unavailable import UnavailableIsolationBackend
from .volume import VOLUME_MOUNT, VOLUME_PLANES, ensure_volume_root, volume_is_born

__all__ = [
    "IsolationBackend",
    "IsolationDetect",
    "PodmanIsolationBackend",
    "DockerIsolationBackend",
    "FakeIsolationBackend",
    "UnavailableIsolationBackend",
    "select_backend",
    "VOLUME_MOUNT",
    "VOLUME_PLANES",
    "ensure_volume_root",
    "volume_is_born",
]
