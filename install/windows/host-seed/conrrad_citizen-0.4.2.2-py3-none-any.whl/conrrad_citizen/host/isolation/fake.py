"""Fake isolation backend for tests. Not a real container."""
from __future__ import annotations

from pathlib import Path

from conrrad_citizen.host.contract import HostResult
from conrrad_citizen.host.isolation.contract import IsolationDetect
from conrrad_citizen.host.isolation.image import ENVIRONMENT_NAME, ENVIRONMENT_PORT, default_image_ref
from conrrad_citizen.host.isolation.volume import VOLUME_MOUNT, ensure_volume_root


def _digest_of(image: str) -> str:
    text = (image or "").strip()
    if "@sha256:" in text:
        digest = text.rsplit("@", 1)[-1]
        return digest if digest.startswith("sha256:") else f"sha256:{digest}"
    return ""


class FakeIsolationBackend:
    """Records environment lifecycle. Optionally simulates in-environment boot."""

    name = "fake"

    def __init__(
        self,
        *,
        volume: Path,
        host: str = "127.0.0.1",
        port: str | int = "3434",
        execute_entrypoint: bool = False,
        image: str | None = None,
        environment: str | None = None,
    ) -> None:
        self.volume = Path(volume)
        self.host = host
        self.port = str(port)
        self.execute_entrypoint = execute_entrypoint
        self.image = image or default_image_ref()
        self.environment = environment or ENVIRONMENT_NAME
        self.calls: list[str] = []
        self.created = False
        self.running = False
        self.destroyed = 0
        self.log_text = ""
        self.last_boot: dict | None = None
        self._env_seq = 0
        self._environment_id = ""
        self.retained: list[dict[str, str | bool]] = []
        self.images_present: set[str] = {self.image, _digest_of(self.image)}
        self.images_present.discard("")
        self.pulls: list[str] = []
        self.fail_next_health = False
        self.fail_next_start = False
        self.fail_digest: str = ""

    def detect(self) -> IsolationDetect:
        return IsolationDetect(
            name="fake",
            available=True,
            rootless=True,
            reason="injected fake backend",
            details={"real_container": False},
        )

    def provision(self) -> HostResult:
        self.calls.append("provision")
        ensure_volume_root(self.volume)
        self.log_text += "provisioned fake environment image\n"
        return HostResult(True, "PROVISIONED", "Fake isolation provisioned", {
            "backend": self.name,
            "image": default_image_ref(),
            "real_container": False,
        })

    def environment_id(self) -> str:
        return self._environment_id

    def image_digest(self) -> str:
        return _digest_of(self.image)

    def set_image(self, image: str, *, expected_digest: str | None = None) -> None:
        self.image = image
        if expected_digest:
            digest = expected_digest if str(expected_digest).startswith("sha256:") else f"sha256:{expected_digest}"
            if "@sha256:" not in self.image:
                self.image = f"{self.image}@{digest}"

    def ensure_image(self, image: str | None = None, expected_digest: str | None = None) -> HostResult:
        self.calls.append("ensure_image")
        target = image or self.image
        digest = _digest_of(target) or (
            expected_digest if expected_digest and str(expected_digest).startswith("sha256:") else ""
        )
        if self.fail_digest and digest == self.fail_digest:
            return HostResult(
                False,
                "FAILED",
                "Image digest mismatch. Stopped. Citizen volume was not modified.",
                {"image": target, "expected": digest, "got": "sha256:" + ("0" * 64)},
            )
        present = target in self.images_present or (digest and digest in self.images_present)
        if present:
            return HostResult(True, "PRESENT", "Fake image ready", {
                "image": target,
                "digest": digest,
                "real_container": False,
            })
        self.pulls.append(target)
        self.images_present.add(target)
        if digest:
            self.images_present.add(digest)
        return HostResult(True, "PULLED", "Fake image pulled", {
            "image": target,
            "digest": digest,
            "real_container": False,
        })

    def create_environment(self) -> HostResult:
        self.calls.append("create_environment")
        ensure_volume_root(self.volume)
        if self.created and self._environment_id:
            return HostResult(True, "CREATED", "Environment already exists", {
                "environment": self.environment,
                "environment_id": self._environment_id,
                "volume": str(self.volume),
            })
        self._env_seq += 1
        self._environment_id = f"fake-env-{self._env_seq}"
        self.created = True
        self.log_text += f"created {self.environment} id={self._environment_id} image={self.image}\n"
        return HostResult(True, "CREATED", "Fake environment created", {
            "environment": self.environment,
            "environment_id": self._environment_id,
            "volume": str(self.volume),
            "mount": VOLUME_MOUNT,
            "image": self.image,
        })

    def start(self) -> HostResult:
        self.calls.append("start")
        if self.fail_next_start:
            self.fail_next_start = False
            return HostResult(False, "FAILED", "startup failure", {"image": self.image})
        if not self.created:
            self.create_environment()
        if self.execute_entrypoint:
            from conrrad_citizen.host.isolation.entrypoint import boot_environment

            self.last_boot = boot_environment(
                home=self.volume, serve=False, host=self.host, port=self.port
            )
        self.running = True
        self.log_text += "environment started\n"
        return HostResult(True, "STARTED", "Fake environment started", {
            **self.publish(),
            "environment_id": self._environment_id,
            "image": self.image,
        })

    def stop(self) -> HostResult:
        self.calls.append("stop")
        if not self.running:
            return HostResult(True, "STOPPED", "Already stopped")
        self.running = False
        self.log_text += "environment stopped\n"
        return HostResult(True, "STOPPED", "Fake environment stopped")

    def restart(self) -> HostResult:
        self.calls.append("restart")
        self.stop()
        return self.start()

    def status(self) -> HostResult:
        state = "running" if self.running else ("created" if self.created else "absent")
        return HostResult(True, state, "Fake environment status", {
            "environment": ENVIRONMENT_NAME,
            "running": self.running,
            "created": self.created,
            "volume": str(self.volume),
        })

    def health(self) -> HostResult:
        if self.fail_next_health and self.running:
            self.fail_next_health = False
            return HostResult(False, "FAILED", "health timeout", {"environment_id": self._environment_id})
        if self.running:
            return HostResult(True, "RUNNING", "Fake environment running")
        return HostResult(False, "STOPPED", "Fake environment not running")

    def logs(self) -> HostResult:
        return HostResult(True, "LOGS", self.log_text)

    def publish(self) -> dict[str, str]:
        return {
            "host": self.host,
            "host_port": self.port,
            "environment_port": str(ENVIRONMENT_PORT),
            "bind": f"{self.host}:{self.port}",
        }

    def destroy_environment(self) -> HostResult:
        self.calls.append("destroy_environment")
        self.running = False
        self.created = False
        self._environment_id = ""
        self.destroyed += 1
        self.log_text += "environment destroyed\n"
        return HostResult(True, "DESTROYED", "Fake environment destroyed", {
            "volume": str(self.volume),
            "volume_preserved": True,
        })

    def retain_environment(self) -> HostResult:
        """Stop current environment and keep it recoverable. Volume stays."""
        self.calls.append("retain_environment")
        retained_id = self._environment_id
        self.retained.append(
            {
                "environment_id": retained_id,
                "image": self.image,
                "environment": self.environment,
            }
        )
        self.running = False
        self.created = False
        self._environment_id = ""
        self.log_text += f"retained {retained_id}\n"
        return HostResult(True, "RETAINED", "Previous environment retained", {
            "volume": str(self.volume),
            "volume_preserved": True,
            "retained_id": retained_id,
            "retained_count": len(self.retained),
        })

    def restore_retained_environment(self) -> HostResult:
        self.calls.append("restore_retained_environment")
        if not self.retained:
            return HostResult(False, "FAILED", "no retained environment")
        prev = self.retained.pop()
        self.image = str(prev["image"])
        self._environment_id = str(prev["environment_id"])
        self.created = True
        self.running = False
        self.log_text += f"restored {self._environment_id}\n"
        return HostResult(True, "RESTORED", "Previous environment restored", {
            "volume": str(self.volume),
            "volume_preserved": True,
            "environment_id": self._environment_id,
            "image": self.image,
        })

    def owns_pid(self, pid: int) -> bool:
        return False
