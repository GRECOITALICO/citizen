"""Podman isolation invoked from Windows through WSL2.

The Windows host never gives Citizen Life Podman authority. This backend is
HostAdapter infrastructure: wsl.exe runs podman as the managed Linux user.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

from conrrad_citizen.host.contract import HostResult
from conrrad_citizen.host.isolation.contract import IsolationDetect
from conrrad_citizen.host.isolation.podman import PodmanIsolationBackend


class WslPodmanIsolationBackend(PodmanIsolationBackend):
    name = "wsl-podman"

    def __init__(
        self,
        *,
        distro: str,
        volume: Path | str,
        host: str = "127.0.0.1",
        port: str | int = "3434",
        run: Callable[..., HostResult],
        image: str | None = None,
        environment: str | None = None,
        user: str = "citizen",
    ) -> None:
        self.distro = distro
        self.user = user
        self._host_run = run

        def runner(cmd: list[str], *, check: bool = True) -> HostResult:
            wrapped = ["wsl.exe", "-d", distro, "-u", user, "--exec"] + [str(part) for part in cmd]
            return self._host_run(wrapped, check=check)

        super().__init__(
            volume=Path(str(volume)),
            host=host,
            port=port,
            runner=runner,
            image=image,
            environment=environment,
        )

    def detect(self) -> IsolationDetect:
        info = self._run(["podman", "info", "--format", "json"], check=False)
        available = int(info.details.get("returncode") or 1) == 0
        return IsolationDetect(
            name=self.name,
            available=available,
            rootless=True,
            reason="WSL2 Podman" if available else "WSL2 Podman not ready",
            details={"distro": self.distro, "real_container": available},
        )
