"""Podman isolation backend. Rootless preferred. Does not install Podman."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from conrrad_citizen.host.contract import HostResult
from conrrad_citizen.host.isolation.contract import IsolationDetect
from conrrad_citizen.host.isolation.image import (
    ENVIRONMENT_PORT,
    default_image_ref,
    ensure_image,
    environment_name,
)
from conrrad_citizen.host.isolation.process import run_cmd, which
from conrrad_citizen.host.isolation.volume import VOLUME_MOUNT, ensure_volume_root


class PodmanIsolationBackend:
    name = "podman"

    def __init__(
        self,
        *,
        volume: Path,
        host: str = "127.0.0.1",
        port: str | int = "3434",
        runner: Callable[..., HostResult] | None = None,
        image: str | None = None,
        environment: str | None = None,
    ) -> None:
        self.volume = Path(volume)
        self.host = host
        self.port = str(port)
        self.image = image or default_image_ref()
        self.environment = environment or environment_name()
        self._run = runner or run_cmd

    def detect(self) -> IsolationDetect:
        exe = which("podman")
        if not exe:
            return IsolationDetect(
                name="podman",
                available=False,
                rootless=False,
                reason="podman not found",
            )
        info = self._run(["podman", "info", "--format", "json"], check=False)
        if not info.ok or info.details.get("returncode", 0) not in (0, None):
            return IsolationDetect(
                name="podman",
                available=False,
                rootless=False,
                reason="podman info failed",
                details={"stderr": info.details.get("stderr", "")},
            )
        rootless = _podman_rootless(info.details.get("stdout") or "")
        if not rootless:
            return IsolationDetect(
                name="podman",
                available=False,
                rootless=False,
                reason="podman is not rootless",
                details={"stdout": info.details.get("stdout", "")[:200]},
            )
        return IsolationDetect(
            name="podman",
            available=True,
            rootless=True,
            reason="rootless podman available",
            details={"executable": exe},
        )

    def provision(self) -> HostResult:
        detected = self.detect()
        if not detected.available:
            return HostResult(False, "UNAVAILABLE", detected.reason, {"backend": self.name})
        ensure_volume_root(self.volume)
        image = self.ensure_image()
        if not image.ok:
            return image
        return HostResult(True, "PROVISIONED", "Podman isolation ready", {
            "backend": self.name,
            "image": self.image,
            "image_digest": (image.details or {}).get("digest"),
            "image_present": True,
            "rootless": True,
        })

    def ensure_image(self, image: str | None = None, expected_digest: str | None = None) -> HostResult:
        target = image or self.image
        return ensure_image(
            engine="podman",
            image=target,
            runner=self._run,
            expected_digest=expected_digest,
        )

    def environment_id(self) -> str:
        inspect = self._run(
            ["podman", "inspect", "--format", "{{.Id}}", self.environment],
            check=False,
        )
        if inspect.details.get("returncode") != 0:
            return ""
        return (inspect.details.get("stdout") or "").strip()

    def image_digest(self) -> str:
        inspect = self._run(
            ["podman", "inspect", "--format", "{{.ImageDigest}}", self.environment],
            check=False,
        )
        raw = (inspect.details.get("stdout") or "").strip()
        if raw.startswith("sha256:"):
            return raw
        if raw:
            return f"sha256:{raw}"
        if "@sha256:" in (self.image or ""):
            return self.image.rsplit("@", 1)[-1]
        return ""

    def set_image(self, image: str, *, expected_digest: str | None = None) -> None:
        self.image = image

    def _previous_name(self) -> str:
        return f"{self.environment}.previous"

    def create_environment(self) -> HostResult:
        detected = self.detect()
        if not detected.available:
            return HostResult(False, "UNAVAILABLE", detected.reason, {"backend": self.name})
        ensure_volume_root(self.volume)
        inspect = self._run(["podman", "inspect", self.environment], check=False)
        if inspect.details.get("returncode") == 0:
            return HostResult(True, "CREATED", "Environment already exists", {
                "environment": self.environment,
                "volume": str(self.volume),
            })
        created = self._run([
            "podman", "create",
            "--name", self.environment,
            "--replace",
            "--restart", "unless-stopped",
            "--publish", f"{self.host}:{self.port}:{ENVIRONMENT_PORT}",
            "--volume", f"{self.volume}:{VOLUME_MOUNT}:Z",
            "--env", f"CITIZEN_HOME={VOLUME_MOUNT}",
            "--env", "CITIZEN_UI_HOST=0.0.0.0",
            "--env", f"CITIZEN_UI_PORT={ENVIRONMENT_PORT}",
            "--env", "CITIZEN_OPEN_BROWSER=0",
            self.image,
        ])
        if not created.ok:
            return created
        return HostResult(True, "CREATED", "Podman environment created", {
            "environment": self.environment,
            "volume": str(self.volume),
            "mount": VOLUME_MOUNT,
        })

    def start(self) -> HostResult:
        detected = self.detect()
        if not detected.available:
            return HostResult(False, "UNAVAILABLE", detected.reason, {"backend": self.name})
        started = self._run(["podman", "start", self.environment])
        if not started.ok:
            return started
        return HostResult(True, "STARTED", "Podman environment started", self.publish())

    def stop(self) -> HostResult:
        st = self.status()
        if st.details.get("running") is False and st.state != "running":
            return HostResult(True, "STOPPED", "Already stopped")
        stopped = self._run(["podman", "stop", self.environment], check=False)
        if stopped.details.get("returncode") not in (0, None) and stopped.details.get("returncode") != 0:
            # podman stop on missing container is still success for our purposes
            err = (stopped.details.get("stderr") or "").lower()
            if "no such" in err or "not found" in err:
                return HostResult(True, "STOPPED", "Already stopped")
            if not stopped.ok:
                return stopped
        return HostResult(True, "STOPPED", "Podman environment stopped")

    def restart(self) -> HostResult:
        restarted = self._run(["podman", "restart", self.environment])
        if not restarted.ok:
            return restarted
        return HostResult(True, "STARTED", "Podman environment restarted", {
            "home": str(self.volume),
            **self.publish(),
        })

    def status(self) -> HostResult:
        inspect = self._run(
            ["podman", "inspect", "--format", "{{.State.Running}}", self.environment],
            check=False,
        )
        raw = (inspect.details.get("stdout") or "").strip().lower()
        running = raw == "true"
        state = "running" if running else ("created" if inspect.details.get("returncode") == 0 else "absent")
        return HostResult(True, state, "Podman environment status", {
            "environment": self.environment,
            "running": running,
            "volume": str(self.volume),
        })

    def health(self) -> HostResult:
        st = self.status()
        if st.details.get("running"):
            return HostResult(True, "RUNNING", "Podman environment running")
        return HostResult(False, "STOPPED", "Podman environment not running")

    def logs(self) -> HostResult:
        out = self._run(["podman", "logs", "--tail", "100", self.environment], check=False)
        text = (out.details.get("stdout") or "") + (out.details.get("stderr") or "")
        if out.details.get("returncode") == 0:
            return HostResult(True, "LOGS", text)
        return HostResult(False, "FAILED", "podman logs unavailable", out.details)

    def publish(self) -> dict[str, str]:
        return {
            "host": self.host,
            "host_port": self.port,
            "environment_port": str(ENVIRONMENT_PORT),
            "bind": f"{self.host}:{self.port}",
        }

    def destroy_environment(self) -> HostResult:
        self._run(["podman", "stop", self.environment], check=False)
        removed = self._run(["podman", "rm", "-f", self.environment], check=False)
        return HostResult(True, "DESTROYED", "Podman environment destroyed", {
            "volume": str(self.volume),
            "volume_preserved": True,
            "rm": removed.details.get("returncode"),
        })

    def owns_pid(self, pid: int) -> bool:
        inspect = self._run(
            ["podman", "inspect", "--format", "{{.State.Pid}}", self.environment],
            check=False,
        )
        raw = (inspect.details.get("stdout") or "").strip()
        return raw.isdigit() and int(raw) == int(pid)

    def retain_environment(self) -> HostResult:
        """Stop current container and rename it so the volume/port are free.

        The previous environment remains recoverable. The Citizen volume is
        not deleted. Dual-publish of 3434 is not attempted: pasta cannot bind
        the same host port twice, so the old environment is stopped first.
        Unknown listeners are never killed.
        """
        previous = self._previous_name()
        self._run(["podman", "stop", self.environment], check=False)
        # Keep a single retained predecessor.
        inspect_prev = self._run(["podman", "inspect", previous], check=False)
        if inspect_prev.details.get("returncode") == 0:
            self._run(["podman", "rm", "-f", previous], check=False)
        renamed = self._run(["podman", "rename", self.environment, previous], check=False)
        if renamed.details.get("returncode") not in (0, None) and renamed.details.get("returncode") != 0:
            err = (renamed.details.get("stderr") or "").lower()
            if "no such" not in err and "not found" not in err:
                return HostResult(False, "FAILED", "could not retain previous environment", renamed.details)
        return HostResult(True, "RETAINED", "Previous environment retained", {
            "volume": str(self.volume),
            "volume_preserved": True,
            "retained": previous,
        })

    def restore_retained_environment(self) -> HostResult:
        previous = self._previous_name()
        self._run(["podman", "stop", self.environment], check=False)
        self._run(["podman", "rm", "-f", self.environment], check=False)
        renamed = self._run(["podman", "rename", previous, self.environment], check=False)
        if renamed.details.get("returncode") not in (0, None) and renamed.details.get("returncode") != 0:
            return HostResult(False, "FAILED", "could not restore previous environment", renamed.details)
        return HostResult(True, "RESTORED", "Previous environment restored", {
            "volume": str(self.volume),
            "volume_preserved": True,
            "environment": self.environment,
        })


def _podman_rootless(stdout: str) -> bool:
    text = (stdout or "").strip()
    if not text:
        return False
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return "rootless" in text.lower()
    host = payload.get("host") if isinstance(payload, dict) else None
    if isinstance(host, dict):
        security = host.get("security")
        if isinstance(security, dict) and "rootless" in security:
            return bool(security.get("rootless"))
        if "rootless" in host:
            return bool(host.get("rootless"))
    return False
