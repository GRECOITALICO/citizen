"""Honest absence of an isolation engine. Does not fall back to host Python."""
from __future__ import annotations

from conrrad_citizen.host.contract import HostResult
from conrrad_citizen.host.isolation.contract import IsolationDetect


class UnavailableIsolationBackend:
    name = "none"

    def __init__(self, reason: str = "No isolation backend available") -> None:
        self.reason = reason

    def detect(self) -> IsolationDetect:
        return IsolationDetect(
            name="none",
            available=False,
            rootless=False,
            reason=self.reason,
        )

    def _fail(self, phase: str) -> HostResult:
        return HostResult(
            False,
            "UNAVAILABLE",
            self.reason,
            {"phase": phase, "backend": self.name},
        )

    def provision(self) -> HostResult:
        return self._fail("provision")

    def ensure_image(self) -> HostResult:
        return self._fail("ensure_image")

    def create_environment(self) -> HostResult:
        return self._fail("create_environment")

    def start(self) -> HostResult:
        return self._fail("start")

    def stop(self) -> HostResult:
        return HostResult(True, "STOPPED", "No environment")

    def restart(self) -> HostResult:
        return self._fail("restart")

    def status(self) -> HostResult:
        return HostResult(True, "unavailable", self.reason)

    def health(self) -> HostResult:
        return self._fail("health")

    def logs(self) -> HostResult:
        return self._fail("logs")

    def publish(self) -> dict[str, str]:
        return {"host": "127.0.0.1", "host_port": "3434", "environment_port": "3434"}

    def destroy_environment(self) -> HostResult:
        return HostResult(True, "DESTROYED", "No environment")

    def owns_pid(self, pid: int) -> bool:
        return False
