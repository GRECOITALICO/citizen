"""Persistent Citizen volume — life plane, independent of the environment."""
from __future__ import annotations

import json
from pathlib import Path

VOLUME_MOUNT = "/citizen"

# Complete persistent life plane. The environment rootfs must not own these.
VOLUME_PLANES = (
    "identity",
    "evidence",
    "history",
    "ops",
    "manifest",
    "assets",
    "boot",
    "updates",
    "configuration",
)

# Must never live on the Citizen volume.
VOLUME_FORBIDDEN_MARKERS = (
    "systemd unit",
    "Podman runtime",
    "Docker runtime",
    "host Python",
    "container ID",
    "image ID",
)


def identity_is_structurally_valid(root: Path) -> bool:
    """Born identity is sealed JSON with a citizen_id. Does not mint identity."""
    path = Path(root) / "identity" / "identity.json"
    if not path.is_file():
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return False
    if not isinstance(data, dict):
        return False
    cid = data.get("citizen_id")
    created = data.get("created_utc")
    return isinstance(cid, str) and cid.startswith("cit_") and bool(created)


def volume_is_born(root: Path) -> bool:
    """True when the volume already holds a sealed, structurally valid identity."""
    root = Path(root)
    if not (root / "identity" / "SEALED").is_file():
        return False
    return identity_is_structurally_valid(root)


def ensure_volume_root(root: Path) -> Path:
    """Create the volume directory only. Do not mint identity or layout planes."""
    path = Path(root)
    path.mkdir(parents=True, exist_ok=True)
    return path
