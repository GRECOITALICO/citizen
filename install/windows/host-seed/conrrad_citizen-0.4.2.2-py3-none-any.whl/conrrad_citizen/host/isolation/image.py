"""Citizen environment image — runtime in the image, life on the volume.

The public wheel is an immutable build input. This module does not rebuild it.
The image digest identifies the environment artifact. It is not a Citizen version.
The same OCI image is the portable runtime for Linux now and for Windows/macOS
hosts later (WSL2 / Linux VM). There is no Windows- or macOS-specific runtime.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

from conrrad_citizen.host.contract import HostResult

PACKAGE_VERSION = "0.4.2.1"
RUNTIME_VERSION = "0.4.2"
WHEEL_NAME = "conrrad_citizen-0.4.2.1-py3-none-any.whl"
WHEEL_SHA256 = "fe8f06d10219655bd0ebf84a1f8a08c955d65fa22a76316c3887d29fcede51e9"
WHEEL_URL = (
    "https://raw.githubusercontent.com/GRECOITALICO/citizen/"
    "citizen-runtime-0.4.2.1/release/0.4.2.1/" + WHEEL_NAME
)

LOCAL_IMAGE_REF = "localhost/conrrad-citizen:0.4.2.1-local"
PUBLIC_IMAGE_REGISTRY = "ghcr.io"
PUBLIC_IMAGE_NAME = "ghcr.io/grecoitalico/citizen"
PUBLIC_IMAGE_TAG = "0.4.2.1"
IMAGE_REF = LOCAL_IMAGE_REF  # local build tag; public install uses digest
ENVIRONMENT_NAME = "conrrad-citizen"
ENVIRONMENT_PORT = 3434


def package_root() -> Path:
    """conrrad-citizen/ directory (parent of src/)."""
    return Path(__file__).resolve().parents[4]


def dockerfile_path() -> Path:
    return package_root() / "isolation" / "Dockerfile"


def wheel_path() -> Path:
    return package_root() / "release" / PACKAGE_VERSION / WHEEL_NAME


def provenance_path() -> Path:
    return package_root() / "isolation" / "IMAGE_PROVENANCE.json"


def public_install_script() -> Path:
    return package_root() / "isolation" / "public" / "install.sh"


def environment_name() -> str:
    name = os.environ.get("CITIZEN_CONTAINER_NAME", "").strip()
    return name or ENVIRONMENT_NAME


def verify_wheel_bytes(data: bytes) -> str:
    digest = hashlib.sha256(data).hexdigest()
    if digest != WHEEL_SHA256:
        raise ValueError(f"wheel SHA256 mismatch: expected {WHEEL_SHA256} got {digest}")
    return digest


def verify_wheel_file(path: Path | None = None) -> str:
    target = Path(path) if path is not None else wheel_path()
    return verify_wheel_bytes(target.read_bytes())


def load_provenance(path: Path | None = None) -> dict:
    target = Path(path) if path is not None else provenance_path()
    if not target.is_file():
        return {}
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def provenance_digest(path: Path | None = None) -> str:
    env = os.environ.get("CITIZEN_IMAGE_DIGEST", "").strip()
    if env:
        return _normalize_digest(env)
    digest = str(load_provenance(path).get("image_digest") or "").strip()
    return _normalize_digest(digest) if digest else ""


def _normalize_digest(value: str) -> str:
    text = (value or "").strip()
    if not text:
        return ""
    if text.startswith("sha256:"):
        return text
    return f"sha256:{text}"


def _digest_match(got: str, expected: str) -> bool:
    return _normalize_digest(got) == _normalize_digest(expected)


def default_image_ref() -> str:
    """Public digest is installer truth. Tags are discovery only.

    CITIZEN_IMAGE overrides explicitly (tests / local rebuilds). Never silently
    substitute a different image when a digest is configured.
    """
    override = os.environ.get("CITIZEN_IMAGE", "").strip()
    if override:
        return override
    digest = provenance_digest()
    if digest:
        return f"{PUBLIC_IMAGE_NAME}@{digest}"
    return LOCAL_IMAGE_REF


def ensure_image(
    *,
    engine: str,
    image: str,
    runner,
    expected_digest: str | None = None,
) -> HostResult:
    """Pull if needed and verify digest. Never deletes a Citizen volume."""
    expected = _normalize_digest(expected_digest or provenance_digest() or "")
    inspect = runner(
        [engine, "image", "inspect", "--format", "{{.Digest}}", image],
        check=False,
    )
    present = inspect.details.get("returncode") == 0
    got = (inspect.details.get("stdout") or "").strip()
    if present and expected and _digest_match(got, expected):
        return HostResult(True, "PRESENT", "Environment image ready", {
            "image": image,
            "digest": _normalize_digest(got),
            "engine": engine,
        })
    if present and not expected:
        return HostResult(True, "PRESENT", "Environment image ready", {
            "image": image,
            "digest": got,
            "engine": engine,
        })
    if present and expected and not _digest_match(got, expected):
        return HostResult(
            False,
            "FAILED",
            "Image digest mismatch. Stopped. Citizen volume was not modified.",
            {
                "image": image,
                "expected": expected,
                "got": got,
                "engine": engine,
            },
        )

    pulled = runner([engine, "pull", image], check=False)
    if pulled.details.get("returncode", 1) not in (0, None) or not pulled.ok:
        return HostResult(
            False,
            "FAILED",
            "Image retrieval failed. Stopped. No Birth. Citizen volume was not modified.",
            {
                "image": image,
                "engine": engine,
                "stderr": (pulled.details.get("stderr") or pulled.message or "")[:500],
            },
        )

    inspect = runner(
        [engine, "image", "inspect", "--format", "{{.Digest}}", image],
        check=False,
    )
    got = (inspect.details.get("stdout") or "").strip()
    if expected and not _digest_match(got, expected):
        return HostResult(
            False,
            "FAILED",
            "Image digest mismatch. Stopped. Citizen volume was not modified.",
            {
                "image": image,
                "expected": expected,
                "got": got,
                "engine": engine,
            },
        )
    return HostResult(True, "PULLED", "Environment image ready", {
        "image": image,
        "digest": _normalize_digest(got) if got else expected,
        "engine": engine,
    })
