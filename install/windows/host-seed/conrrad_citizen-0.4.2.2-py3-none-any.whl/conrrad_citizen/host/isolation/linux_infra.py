"""Linux isolation infrastructure provisioning.

Installs rootless Podman when missing. Does not install Docker.
Does not install Citizen into host Python.
"""
from __future__ import annotations

import os
import shutil
from typing import Callable

from conrrad_citizen.host.contract import HostResult
from conrrad_citizen.host.isolation.process import run_cmd, which

DEBIAN_ISOLATION_PACKAGES = (
    "podman",
    "uidmap",
    "slirp4netns",
    "passt",
    "fuse-overlayfs",
    "crun",
)


def debian_like() -> bool:
    return os.path.isfile("/etc/debian_version")


def package_installed(name: str, *, runner: Callable[..., HostResult] | None = None) -> bool:
    run = runner or run_cmd
    out = run(["dpkg-query", "-W", "-f=${Status}", name], check=False)
    status = out.details.get("stdout") or ""
    return out.details.get("returncode") == 0 and "install ok installed" in status


def missing_isolation_packages(*, runner: Callable[..., HostResult] | None = None) -> list[str]:
    return [name for name in DEBIAN_ISOLATION_PACKAGES if not package_installed(name, runner=runner)]


def _privileged(cmd: list[str], *, runner: Callable[..., HostResult]) -> HostResult:
    env_cmd = ["env", "DEBIAN_FRONTEND=noninteractive", *cmd]
    pkexec = which("pkexec")
    if pkexec:
        return runner([pkexec, *env_cmd], check=False)
    sudo = which("sudo")
    if sudo:
        noninteractive = runner([sudo, "-n", *env_cmd], check=False)
        if noninteractive.details.get("returncode") == 0:
            return noninteractive
        return runner([sudo, *env_cmd], check=False)
    if os.geteuid() == 0:
        return runner(env_cmd, check=False)
    return HostResult(
        False,
        "UNAVAILABLE",
        "Host isolation packages are missing and cannot be installed without authorization.",
        {"cmd": cmd},
    )


def provision_isolation_infrastructure(
    *,
    runner: Callable[..., HostResult] | None = None,
) -> HostResult:
    """Detect missing isolation packages and install only those.

    If rootless Podman already works, this is a no-op.
    """
    run = runner or run_cmd
    exe = which("podman")
    if exe:
        info = run(["podman", "info", "--format", "json"], check=False)
        if info.ok and info.details.get("returncode") in (0, None):
            from conrrad_citizen.host.isolation.podman import _podman_rootless

            if _podman_rootless(info.details.get("stdout") or ""):
                return HostResult(True, "PRESENT", "Rootless isolation already available", {
                    "backend": "podman",
                    "rootless": True,
                    "provisioned": False,
                    "packages": [],
                })

    if not debian_like():
        return HostResult(
            False,
            "UNAVAILABLE",
            "Automatic isolation provisioning is implemented for Debian-like Linux only.",
            {"os": "unsupported"},
        )

    missing = missing_isolation_packages(runner=run)
    if missing:
        updated = _privileged(["apt-get", "update"], runner=run)
        if updated.details.get("returncode") not in (0, None):
            return HostResult(
                False,
                "UNAVAILABLE",
                "Could not prepare host isolation packages.",
                {"phase": "apt-get-update", "stderr": (updated.details.get("stderr") or "")[:400]},
            )
        installed = _privileged(
            ["apt-get", "install", "-y", "--no-install-recommends", *missing],
            runner=run,
        )
        if installed.details.get("returncode") not in (0, None):
            return HostResult(
                False,
                "UNAVAILABLE",
                "Could not install host isolation packages.",
                {
                    "phase": "apt-get-install",
                    "packages": missing,
                    "stderr": (installed.details.get("stderr") or "")[:400],
                },
            )
    else:
        installed = HostResult(True, "PRESENT", "packages present", {"packages": []})
        missing = []

    if not which("podman") and not shutil.which("podman"):
        return HostResult(
            False,
            "UNAVAILABLE",
            "Isolation engine is still missing after package installation.",
            {"packages": missing},
        )

    info = run(["podman", "info", "--format", "json"], check=False)
    from conrrad_citizen.host.isolation.podman import _podman_rootless

    rootless = _podman_rootless(info.details.get("stdout") or "")
    if info.details.get("returncode") not in (0, None) or not rootless:
        return HostResult(
            False,
            "UNAVAILABLE",
            "Isolation engine is present but not rootless.",
            {"stderr": (info.details.get("stderr") or "")[:400]},
        )
    return HostResult(True, "PROVISIONED", "Host isolation prepared", {
        "backend": "podman",
        "rootless": True,
        "provisioned": bool(missing),
        "packages": missing,
    })
