"""macOS host adapter — honest stub. No launchd is invented here."""
from __future__ import annotations

from pathlib import Path

from .contract import HostResult


class MacHostAdapter:
    def __init__(self, *, data_dir: Path, home: Path, **_: object) -> None:
        self.data_dir = Path(data_dir)
        self.home = Path(home)
        self._msg = (
            "Host adapter is not implemented for macOS. "
            "Use 'citizen serve' on this platform. No launchd is installed."
        )

    def provision(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def start(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def stop(self) -> HostResult:
        return HostResult(True, "STOPPED", "No host service")

    def restart(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def status(self) -> HostResult:
        return HostResult(True, "unsupported", self._msg)

    def health(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def volume(self) -> dict[str, str]:
        return {"data_dir": str(self.data_dir), "home": str(self.home)}

    def network(self) -> dict[str, str]:
        return {"host": "127.0.0.1", "port": "3434"}

    def wait_health(self, attempts: int = 10, delay: float = 1.0) -> HostResult:
        return self.health()

    def logs(self) -> HostResult:
        return HostResult(False, "FAILED", self._msg)

    def disable(self) -> HostResult:
        return HostResult(True, "REMOVED", "No host service")
