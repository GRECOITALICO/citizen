"""Host-owned CLASS_PACKAGE application.

UpdateEngine may request this. HostAdapter performs environment replacement.
The in-guest process never runs podman/docker or touches host credentials.

Living apply happens AFTER the new environment is READY (option C), because
the new image still boots the current living manifest (CLASS_PACKAGE keeps
RUNTIME_VERSION) and the new UpdateEngine is what later living packs need.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path
from typing import Any, Callable

from citizen_seed.class_package import (
    CurrentCitizenState,
    ClassPackageError,
    apply_living_pack,
    check_compatibility,
    count_lines,
    host_architecture,
    host_platform,
    identity_file_hash,
    load_envelope,
    needs_living_evolution,
    needs_runtime_replacement,
    normalize_digest,
    plane_hash,
    verify_class_package_envelope,
    verify_living_artifact,
)
from conrrad_citizen.host.contract import USER_ACTION_REQUIRED, HostResult
from conrrad_citizen.host.isolation.volume import volume_is_born

CHECKPOINT_SCHEMA = "conrrad.citizen.runtime_evolution_checkpoint/v1"
CHECKPOINT_NAME = "RUNTIME_EVOLUTION.json"
HOST_REQUEST_NAME = "RUNTIME_EVOLUTION_REQUEST.json"

LIVING_APPLY_ORDER = "AFTER_RUNTIME_SWITCH_WITHIN_REPLACEMENT_ENVIRONMENT"

LivingApplyFn = Callable[[Path], dict[str, Any]]


def _utc() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _host_checkpoint_path(data_dir: Path) -> Path:
    return Path(data_dir) / CHECKPOINT_NAME


def _volume_checkpoint_path(home: Path) -> Path:
    return Path(home) / "ops" / CHECKPOINT_NAME


def _request_path(home: Path) -> Path:
    return Path(home) / "ops" / HOST_REQUEST_NAME


def running_inside_environment() -> bool:
    if os.environ.get("CITIZEN_IN_ENVIRONMENT", "").strip() == "1":
        return True
    if Path("/run/.containerenv").exists() or Path("/.dockerenv").exists():
        return True
    return False


def capture_life(home: Path, *, runtime_image_digest: str, runtime_version: str) -> CurrentCitizenState:
    home = Path(home)
    ident_path = home / "identity" / "identity.json"
    citizen_id = ""
    if ident_path.is_file():
        try:
            citizen_id = str(json.loads(ident_path.read_text(encoding="utf-8")).get("citizen_id") or "")
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            citizen_id = ""
    living = ""
    runtime = runtime_version
    manifest = home / "manifest" / "current.json"
    if manifest.is_file():
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            data = {}
        if isinstance(data, dict):
            living = str(data.get("citizen_version") or "")
            runtime = str(data.get("runtime_version") or runtime_version)
    evidence = home / "evidence" / "evidence.jsonl"
    history = home / "ops" / "canonical_work_history.jsonl"
    return CurrentCitizenState(
        living_version=living,
        runtime_version=runtime,
        runtime_image_digest=normalize_digest(runtime_image_digest),
        platform=host_platform(),
        architecture=host_architecture(),
        citizen_id=citizen_id,
        identity_hash=identity_file_hash(home),
        identity_sealed=(home / "identity" / "SEALED").is_file(),
        evidence_count=count_lines(evidence),
        history_count=count_lines(history),
        evidence_hash=plane_hash(evidence),
        history_hash=plane_hash(history),
    )


def write_checkpoint(data_dir: Path, home: Path, payload: dict[str, Any]) -> dict[str, Any]:
    body = {
        "schema": CHECKPOINT_SCHEMA,
        "updated_at": _utc(),
        **payload,
    }
    # Never persist secrets.
    for key in ("secret", "token", "password", "private_key", "publisher_secret"):
        body.pop(key, None)
    text = json.dumps(body, indent=2, sort_keys=True) + "\n"
    host_path = _host_checkpoint_path(data_dir)
    host_path.parent.mkdir(parents=True, exist_ok=True)
    host_path.write_text(text, encoding="utf-8")
    vol = _volume_checkpoint_path(home)
    vol.parent.mkdir(parents=True, exist_ok=True)
    vol.write_text(text, encoding="utf-8")
    return body


def load_checkpoint(data_dir: Path, home: Path) -> dict[str, Any] | None:
    for path in (_host_checkpoint_path(data_dir), _volume_checkpoint_path(home)):
        if path.is_file():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(data, dict) and data.get("schema") == CHECKPOINT_SCHEMA:
                return data
    return None


def environment_id_of(host: Any) -> str:
    backend = getattr(host, "backend", None)
    if backend is None:
        return ""
    getter = getattr(backend, "environment_id", None)
    if callable(getter):
        return str(getter() or "")
    return str(getattr(backend, "environment", "") or "")


def current_image_digest(host: Any) -> str:
    backend = getattr(host, "backend", None)
    if backend is None:
        return ""
    getter = getattr(backend, "image_digest", None)
    if callable(getter):
        return normalize_digest(str(getter() or ""))
    image = str(getattr(backend, "image", "") or "")
    if "@sha256:" in image:
        return normalize_digest(image.rsplit("@", 1)[-1])
    return ""


def _set_backend_image(host: Any, image_ref: str, digest: str) -> None:
    backend = getattr(host, "backend", None)
    if backend is None:
        return
    setter = getattr(backend, "set_image", None)
    if callable(setter):
        setter(image_ref, expected_digest=digest)
        return
    backend.image = image_ref


def _result(ok: bool, state: str, message: str, **details: Any) -> HostResult:
    return HostResult(ok, state, message, details)


def _fail(state: str, message: str, **details: Any) -> HostResult:
    return _result(False, state, message, **details)


def _health(host: Any) -> HostResult:
    waiter = getattr(host, "wait_health", None)
    if callable(waiter):
        return waiter()
    return host.health()


def _port_guard(host: Any) -> HostResult | None:
    conflict = getattr(host, "_port_conflict", None)
    if not callable(conflict):
        return None
    occupied = conflict()
    if occupied is None:
        return None
    if occupied.state == USER_ACTION_REQUIRED:
        return occupied
    return occupied


def _ensure_image(host: Any, image_ref: str, digest: str) -> HostResult:
    backend = getattr(host, "backend", None)
    if backend is None:
        return _fail("FAILED", "no isolation backend")
    ensure = getattr(backend, "ensure_image", None)
    if callable(ensure):
        # Prefer digest-aware ensure when the backend supports it.
        try:
            return ensure(image=image_ref, expected_digest=digest)
        except TypeError:
            _set_backend_image(host, image_ref, digest)
            return ensure()
    _set_backend_image(host, image_ref, digest)
    return HostResult(True, "PRESENT", "image assumed present", {"image": image_ref, "digest": digest})


def _retain(host: Any) -> HostResult:
    backend = getattr(host, "backend", None)
    retain = getattr(backend, "retain_environment", None) if backend is not None else None
    if callable(retain):
        return retain()
    stopped = host.stop()
    if not stopped.ok:
        return stopped
    destroyed = host.destroy_environment()
    destroyed.details["retained_by_destroy"] = True
    destroyed.details["volume_preserved"] = True
    return destroyed


def _create_and_start(host: Any) -> HostResult:
    backend = getattr(host, "backend", None)
    if backend is None:
        return _fail("FAILED", "no isolation backend")
    created = backend.create_environment()
    if not created.ok:
        return created
    started = host.start()
    if not started.ok:
        return started
    return started


def _restore(host: Any) -> HostResult:
    backend = getattr(host, "backend", None)
    restore = getattr(backend, "restore_retained_environment", None) if backend is not None else None
    if callable(restore):
        restored = restore()
        if not restored.ok:
            return restored
        started = host.start()
        if started.ok:
            restored.details.update(started.details or {})
        return restored if restored.ok else started
    created = host.provision()
    if not created.ok:
        return created
    return host.start()


def _identity_ok(home: Path, before: CurrentCitizenState) -> HostResult:
    if not volume_is_born(home):
        return _fail("FAILED", "identity missing after replacement — rollback", birth=False)
    after = capture_life(
        home,
        runtime_image_digest=before.runtime_image_digest,
        runtime_version=before.runtime_version,
    )
    if after.citizen_id != before.citizen_id:
        return _fail(
            "FAILED",
            "citizen_id changed",
            SAME_CITIZEN_ID=False,
            IDENTITY_HASH_MATCH=False,
            IDENTITY_SEALED=after.identity_sealed,
        )
    if after.identity_hash != before.identity_hash:
        return _fail(
            "FAILED",
            "identity hash changed",
            SAME_CITIZEN_ID=True,
            IDENTITY_HASH_MATCH=False,
            IDENTITY_SEALED=after.identity_sealed,
        )
    if not after.identity_sealed:
        return _fail("FAILED", "identity not sealed", IDENTITY_SEALED=False)
    if after.evidence_count < before.evidence_count:
        return _fail("FAILED", "evidence lost")
    if after.history_count < before.history_count:
        return _fail("FAILED", "history lost")
    return HostResult(
        True,
        "IDENTITY_OK",
        "Citizen identity preserved",
        {
            "SAME_CITIZEN_ID": True,
            "IDENTITY_HASH_MATCH": True,
            "IDENTITY_SEALED": True,
            "citizen_id": after.citizen_id,
            "identity_hash": after.identity_hash,
            "evidence_count": after.evidence_count,
            "history_count": after.history_count,
        },
    )


def _default_living_apply(home: Path, pack_dir: str) -> dict[str, Any]:
    return apply_living_pack(home, pack_dir)


def apply_class_package(
    *,
    host: Any,
    envelope: dict[str, Any] | None = None,
    envelope_path: Path | None = None,
    living_apply: LivingApplyFn | None = None,
    resume: bool = True,
) -> HostResult:
    """One evolution request: verify, replace runtime if needed, then living.

    Never calls Birth / identity.mint.
    """
    home = Path(host.home)
    data_dir = Path(getattr(host, "data_dir", home.parent))

    if resume:
        existing = load_checkpoint(data_dir, home)
        if existing and str(existing.get("phase") or "") not in {"complete", "noop", "failed_closed"}:
            return resume_class_package(host=host, living_apply=living_apply)

    if envelope is None:
        if envelope_path is None:
            return _fail("FAILED", "CLASS_PACKAGE envelope required")
        envelope = load_envelope(envelope_path)

    try:
        descriptor = verify_class_package_envelope(envelope)
    except ClassPackageError as exc:
        return _fail(exc.code, exc.message, birth=False)

    current_digest = current_image_digest(host) or descriptor["source"]["runtime_image_digest"]
    from citizen_seed import RUNTIME_VERSION

    before = capture_life(home, runtime_image_digest=current_digest, runtime_version=RUNTIME_VERSION)
    try:
        check_compatibility(descriptor, before)
        verify_living_artifact(
            descriptor,
            pack_dir=Path(descriptor["artifacts"]["living_pack"]) if descriptor["artifacts"]["living_pack"] else None,
        )
    except ClassPackageError as exc:
        return _fail(exc.code, exc.message, birth=False, VOLUME_PRESERVED=True)

    occupied = _port_guard(host)
    if occupied is not None:
        return occupied

    evolution_id = str(uuid.uuid4())
    old_env = environment_id_of(host)
    checkpoint = {
        "evolution_id": evolution_id,
        "package_id": descriptor["package_id"],
        "phase": "verify",
        "old_runtime_digest": before.runtime_image_digest,
        "new_runtime_digest": descriptor["target"]["runtime_image_digest"],
        "old_environment_reference": old_env,
        "new_environment_reference": "",
        "old_living_version": before.living_version,
        "target_living_version": descriptor["target"]["living_version"],
        "citizen_id": before.citizen_id,
        "identity_hash": before.identity_hash,
        "birth": False,
        "envelope_path": str(envelope_path or ""),
        "living_pack": descriptor["artifacts"]["living_pack"],
        "runtime_image": descriptor["artifacts"]["runtime_image"],
        "living_apply_order": LIVING_APPLY_ORDER,
    }
    write_checkpoint(data_dir, home, checkpoint)

    runtime_needed = needs_runtime_replacement(descriptor, before)
    living_needed = needs_living_evolution(descriptor, before)
    living_deferred = bool(
        descriptor["artifacts"]["living_pack"] or descriptor["integrity"]["living_sha256"]
    ) and not living_needed and before.living_version != descriptor["target"]["living_version"]

    if not runtime_needed and not living_needed:
        checkpoint["phase"] = "deferred_living" if living_deferred else "noop"
        write_checkpoint(data_dir, home, checkpoint)
        return _result(
            True,
            "Updated" if living_deferred else "Noop",
            "runtime at target; living deferred" if living_deferred else "already at CLASS_PACKAGE target",
            birth=False,
            VOLUME_PRESERVED=True,
            IDENTITY_PRESERVED=True,
            NO_SECOND_BIRTH=True,
            OLD_ENVIRONMENT_ID=old_env,
            NEW_ENVIRONMENT_ID=old_env,
            SAME_CITIZEN_ID=True,
            living_deferred=living_deferred,
            TWO_PHASE_INTERNAL_EVOLUTION=True,
            ONE_USER_SYNC=True,
        )

    if runtime_needed:
        if running_inside_environment() and os.environ.get("CITIZEN_ALLOW_NESTED_REPLACEMENT", "") != "1":
            request = {
                **checkpoint,
                "phase": "host_request",
                "reason": "in-guest UpdateEngine cannot replace its OCI image",
            }
            write_checkpoint(data_dir, home, request)
            from citizen_seed.class_package import write_runtime_evolution_request

            write_runtime_evolution_request(
                home,
                citizen_id=before.citizen_id,
                current_image_digest=before.runtime_image_digest,
                target_package_reference=str(envelope_path or descriptor["artifacts"]["runtime_image"]),
                request_id=evolution_id,
                status="requested",
            )
            return _fail(
                "HOST_RUNTIME_REPLACEMENT_REQUIRED",
                "Runtime replacement is host-owned. CLASS_PACKAGE verified; HostAdapter must apply.",
                **request,
            )

        checkpoint["phase"] = "prepare"
        write_checkpoint(data_dir, home, checkpoint)
        image_ref = descriptor["artifacts"]["runtime_image"]
        digest = descriptor["target"]["runtime_image_digest"]
        pulled = _ensure_image(host, image_ref, digest)
        if not pulled.ok:
            checkpoint["phase"] = "failed_closed"
            write_checkpoint(data_dir, home, checkpoint)
            return _fail(
                pulled.state,
                pulled.message or "runtime image prepare failed",
                VOLUME_PRESERVED=True,
                IDENTITY_PRESERVED=True,
                image_state=pulled.state,
                **(pulled.details or {}),
            )
        checkpoint["image_prepare"] = pulled.state
        checkpoint["phase"] = "snapshot"
        write_checkpoint(data_dir, home, checkpoint)

        checkpoint["phase"] = "switch"
        write_checkpoint(data_dir, home, checkpoint)
        retained = _retain(host)
        if not retained.ok:
            return _rollback(host, checkpoint, data_dir, home, retained.message)

        _set_backend_image(host, image_ref, digest)
        started = _create_and_start(host)
        if not started.ok:
            return _rollback(host, checkpoint, data_dir, home, started.message)

        new_env = environment_id_of(host)
        checkpoint["new_environment_reference"] = new_env
        checkpoint["phase"] = "health"
        write_checkpoint(data_dir, home, checkpoint)
        health = _health(host)
        if not health.ok:
            return _rollback(host, checkpoint, data_dir, home, health.message or "health timeout")

        ident = _identity_ok(home, before)
        if not ident.ok:
            return _rollback(host, checkpoint, data_dir, home, ident.message)
        checkpoint["identity"] = ident.details
        if old_env and new_env and old_env == new_env:
            # Environment id may stay equal on backends that reuse names; Fake changes it.
            pass
        checkpoint["OLD_ENVIRONMENT_ID"] = old_env
        checkpoint["NEW_ENVIRONMENT_ID"] = new_env
        checkpoint["environment_changed"] = bool(old_env and new_env and old_env != new_env)
        checkpoint["retained"] = True
        checkpoint["volume_preserved"] = True
    else:
        new_env = old_env
        checkpoint["new_environment_reference"] = new_env
        ident = _identity_ok(home, before)
        if not ident.ok:
            return _fail(ident.state, ident.message, birth=False)

    living_state = "Noop"
    if living_needed:
        checkpoint["phase"] = "living"
        write_checkpoint(data_dir, home, checkpoint)
        applier = living_apply or (
            lambda home_path: _default_living_apply(home_path, descriptor["artifacts"]["living_pack"])
        )
        try:
            living_out = applier(home)
        except Exception as exc:
            if runtime_needed:
                return _rollback(host, checkpoint, data_dir, home, f"living apply failed: {exc}")
            return _fail("FAILED", f"living apply failed: {exc}", birth=False, VOLUME_PRESERVED=True)
        living_state = str(living_out.get("state") or "")
        if living_state in {"Sync Failed", "Rolled Back"}:
            if runtime_needed:
                return _rollback(host, checkpoint, data_dir, home, living_out.get("error") or living_state)
            return _fail("FAILED", living_out.get("error") or living_state, living_state=living_state)
        after_life = capture_life(
            home,
            runtime_image_digest=descriptor["target"]["runtime_image_digest"],
            runtime_version=descriptor["target"]["runtime_version"],
        )
        if after_life.living_version != descriptor["target"]["living_version"] and living_state != "Current":
            if runtime_needed:
                return _rollback(host, checkpoint, data_dir, home, "living version mismatch after apply")
            return _fail("FAILED", "living version mismatch after apply")

    final = _identity_ok(home, before)
    if not final.ok:
        if runtime_needed:
            return _rollback(host, checkpoint, data_dir, home, final.message)
        return final

    checkpoint["phase"] = "complete"
    checkpoint["living_state"] = living_state
    write_checkpoint(data_dir, home, checkpoint)
    after = capture_life(
        home,
        runtime_image_digest=descriptor["target"]["runtime_image_digest"],
        runtime_version=descriptor["target"]["runtime_version"],
    )
    return HostResult(
        True,
        "Updated" if (runtime_needed or living_needed) else "Noop",
        "CLASS_PACKAGE applied",
        {
            "birth": False,
            "NO_SECOND_BIRTH": True,
            "VOLUME_PRESERVED": True,
            "IDENTITY_PRESERVED": True,
            "EVIDENCE_PRESERVED": after.evidence_count >= before.evidence_count,
            "HISTORY_PRESERVED": after.history_count >= before.history_count,
            "SAME_CITIZEN_ID": True,
            "IDENTITY_HASH_MATCH": True,
            "IDENTITY_SEALED": True,
            "ROLLBACK": False,
            "OLD_ENVIRONMENT_ID": old_env,
            "NEW_ENVIRONMENT_ID": environment_id_of(host) or new_env,
            "citizen_id": after.citizen_id,
            "living_version": after.living_version,
            "runtime_version": after.runtime_version,
            "runtime_image_digest": descriptor["target"]["runtime_image_digest"],
            "package_id": descriptor["package_id"],
            "evolution_id": evolution_id,
            "living_apply_order": LIVING_APPLY_ORDER,
            "runtime_replaced": runtime_needed,
            "living_applied": living_needed,
            "living_deferred": living_deferred,
            "TWO_PHASE_INTERNAL_EVOLUTION": True,
            "ONE_USER_SYNC": True,
            "old_environment_retained": runtime_needed,
            "image_prepare": checkpoint.get("image_prepare"),
        },
    )


def _rollback(
    host: Any,
    checkpoint: dict[str, Any],
    data_dir: Path,
    home: Path,
    reason: str,
) -> HostResult:
    checkpoint["phase"] = "rollback"
    checkpoint["rollback_reason"] = reason
    write_checkpoint(data_dir, home, checkpoint)
    restored = _restore(host)
    checkpoint["phase"] = "rolled_back" if restored.ok else "rollback_failed"
    write_checkpoint(data_dir, home, checkpoint)
    born = volume_is_born(home)
    return HostResult(
        False,
        "Rolled Back" if restored.ok else "ROLLBACK_FAILED",
        reason,
        {
            "birth": False,
            "NO_SECOND_BIRTH": True,
            "VOLUME_PRESERVED": born,
            "IDENTITY_PRESERVED": born,
            "ROLLBACK": True,
            "restore_ok": restored.ok,
            "citizen_id": checkpoint.get("citizen_id"),
        },
    )


def resume_class_package(*, host: Any, living_apply: LivingApplyFn | None = None) -> HostResult:
    home = Path(host.home)
    data_dir = Path(getattr(host, "data_dir", home.parent))
    checkpoint = load_checkpoint(data_dir, home)
    if not checkpoint:
        return _fail("FAILED", "no CLASS_PACKAGE checkpoint to resume")
    phase = str(checkpoint.get("phase") or "")
    if phase in {"complete", "noop"}:
        return _result(True, "Noop", "checkpoint already complete", **checkpoint)
    if phase in {"failed_closed"}:
        return _fail("FAILED", "previous CLASS_PACKAGE attempt failed closed", **checkpoint)
    if phase in {"verify", "prepare", "snapshot", "host_request"}:
        path = checkpoint.get("envelope_path")
        if not path:
            return _fail("FAILED", "cannot resume without envelope_path")
        return apply_class_package(
            host=host,
            envelope_path=Path(path),
            living_apply=living_apply,
            resume=False,
        )
    if phase in {"switch", "health", "living", "rollback", "rollback_failed"}:
        return _rollback(host, checkpoint, data_dir, home, f"interrupted in phase {phase}")
    return apply_class_package(
        host=host,
        envelope_path=Path(str(checkpoint.get("envelope_path") or "")),
        living_apply=living_apply,
        resume=False,
    )


def apply_windows_class_package(
    *,
    adapter: Any,
    envelope: dict[str, Any] | None = None,
    envelope_path: Path | None = None,
    living_apply: LivingApplyFn | None = None,
    linux_applier: Callable[..., HostResult] | None = None,
) -> HostResult:
    """Windows HostAdapter: same seed, same OCI digest, no Birth.

    Replacement uses the same apply_class_package contract as Linux.
    The guest never performs host isolation replacement.
    """
    if callable(linux_applier):
        if envelope is None:
            if envelope_path is None:
                return _fail("FAILED", "CLASS_PACKAGE envelope required")
            envelope = load_envelope(Path(envelope_path))
        return linux_applier(envelope)
    from conrrad_citizen.host.runtime_evolution_seed import apply_runtime_evolution_seed

    return apply_runtime_evolution_seed(
        host=adapter,
        envelope=envelope,
        envelope_path=envelope_path,
        living_apply=living_apply,
        resume=True,
    )
