"""Windows bootstrap requirements planner and permission broker.

The public PowerShell door loads the same requirements manifest. This module
is the testable source of truth for inventory, plan, authorization, reboot,
and Birth boundary. It does not mint identity or apply Evolution.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

REQUIRED_FIELDS = (
    "id",
    "name",
    "description",
    "minimum_version",
    "detect",
    "verify",
    "provisioner",
    "requires_admin",
    "requires_reboot",
    "critical",
    "failure_message",
)
REQUIRED_IDS = (
    "windows_version",
    "windows_architecture",
    "powershell",
    "administrator_elevation",
    "virtualization",
    "wsl_feature",
    "virtual_machine_platform",
    "wsl_runtime",
    "wsl_version",
    "managed_distribution",
    "managed_distribution_version",
    "linux_user",
    "linux_network",
    "linux_dns",
    "linux_https",
    "container_engine",
    "rootless_prerequisites",
    "public_ghcr_access",
    "public_ubuntu_access",
    "disk_space",
    "memory",
    "port_3434",
    "persistent_storage",
    "scheduled_resume",
)
REQ_STATES = ("UNKNOWN", "PRESENT", "MISSING", "BLOCKED", "PROVISIONING", "VERIFIED")
BOOTSTRAP_PHASES = (
    "BOOTSTRAP_STARTED",
    "PREFLIGHT",
    "REQUIREMENTS_INVENTORY",
    "PLAN",
    "AUTHORIZATION_REQUIRED",
    "PROVISIONING",
    "PROVISIONING_WSL",
    "REBOOT_REQUIRED",
    "RESUMING",
    "VERIFYING",
    "VERIFYING_WSL",
    "PROVISIONING_CONTAINER_ENGINE",
    "VERIFYING_CONTAINER_ENGINE",
    "VERIFYING_PUBLIC_IMAGE",
    "CREATING_ENVIRONMENT",
    "ENVIRONMENT_READY",
    "HOST_SEED",
    "BIRTH_OR_RESUME",
    "RUNTIME_EVOLUTION",
    "VERIFYING_CITIZEN",
    "CITIZEN_READY",
    "READY",
    "POST_START_HOUSEKEEPING",
    "COMPLETE",
)
FAILURE_PHASES = (
    "USER_DECLINED",
    "PROVISION_FAILED",
    "VERIFICATION_FAILED",
    "REBOOT_RESUME_FAILED",
    "UNKNOWN_LEGACY",
    "PORT_CONFLICT",
    "UNSUPPORTED_HOST",
)
FORBIDDEN_STATE_KEYS = ("citizen_id", "identity", "secrets", "tokens", "private_keys", "private_key")
PORT_FREE = "FREE"
PORT_CURRENT_CITIZEN = "CURRENT_CITIZEN"
PORT_UNKNOWN_PROCESS = "UNKNOWN_PROCESS"
RES_KNOWN_MANAGED = "KNOWN_MANAGED_CITIZEN"
RES_KNOWN_TEST = "KNOWN_TEST_RESOURCE"
RES_UNKNOWN_LEGACY = "UNKNOWN_LEGACY_RESOURCE"
RES_NONE = "NO_CITIZEN"
PUBLIC_IMAGE_DIGEST = "sha256:446da11ded1a23a64d1c906b98383215606d257a598026e99cc8b8cdeea0635e"
UNSUPPORTED_IDS = frozenset(
    ("windows_version", "windows_architecture", "powershell", "virtualization", "disk_space", "memory")
)
NETWORK_VERIFY_IDS = frozenset(("public_ghcr_access", "public_ubuntu_access"))
TEST_RESOURCE_MARKERS = ("p09e-e2e", "p09d-e2e", "conrrad-citizen-p09")


def requirements_manifest_path() -> Path:
    return Path(__file__).resolve().parents[1] / "windows" / "requirements.json"


def load_requirements_manifest(path: Path | None = None) -> dict:
    target = Path(path) if path is not None else requirements_manifest_path()
    data = json.loads(target.read_text(encoding="utf-8"))
    validate_requirements_manifest(data)
    return data


def validate_requirements_manifest(data: dict) -> None:
    reqs = data.get("requirements")
    if not isinstance(reqs, list) or not reqs:
        raise ValueError("requirements manifest has no requirements")
    seen: set[str] = set()
    for item in reqs:
        if not isinstance(item, dict):
            raise ValueError("requirement is not an object")
        for field_name in REQUIRED_FIELDS:
            if field_name not in item:
                raise ValueError(f"requirement missing {field_name}")
        rid = str(item["id"])
        if rid in seen:
            raise ValueError(f"duplicate requirement id {rid}")
        seen.add(rid)
        if item.get("detect") in (None, "") or item.get("verify") in (None, "") or item.get("provisioner") in (None, ""):
            raise ValueError(f"requirement {rid} has empty handler id")
    missing_ids = [rid for rid in REQUIRED_IDS if rid not in seen]
    if missing_ids:
        raise ValueError(f"requirements manifest missing {missing_ids}")
    extra = seen.difference(REQUIRED_IDS)
    if extra:
        raise ValueError(f"requirements manifest has unknown ids {sorted(extra)}")
    digest = str(data.get("public_image", "")).split("@")[-1]
    if digest != PUBLIC_IMAGE_DIGEST:
        raise ValueError("manifest public_image digest is not the pinned Citizen image")


def classify_port(*, occupied: bool, known_citizen: bool = False, health_ok: bool = False) -> str:
    if not occupied:
        return PORT_FREE
    if known_citizen or health_ok:
        return PORT_CURRENT_CITIZEN
    return PORT_UNKNOWN_PROCESS


def classify_windows_resource(home: Path) -> str:
    from .windows import classify_home

    text = str(home).replace("\\", "/").lower()
    if any(token in text for token in TEST_RESOURCE_MARKERS):
        return RES_KNOWN_TEST
    kind = classify_home(home)
    if kind == "KNOWN_CITIZEN":
        return RES_KNOWN_MANAGED
    if kind in ("UNKNOWN_LEGACY_INSTALLATION", "UNKNOWN"):
        return RES_UNKNOWN_LEGACY
    return RES_NONE


def public_image_digest_ok(ref: str, actual_digest: str) -> bool:
    expected = PUBLIC_IMAGE_DIGEST.lower()
    return actual_digest.lower() == expected and expected in str(ref).lower()


def _version_tuple(text: str) -> tuple[int, ...]:
    parts: list[int] = []
    for piece in str(text).split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        if digits:
            parts.append(int(digits))
    return tuple(parts)


def version_meets(actual: str, minimum: str) -> bool:
    if not minimum:
        return True
    actual_t = _version_tuple(actual)
    minimum_t = _version_tuple(minimum)
    if actual_t and minimum_t:
        width = max(len(actual_t), len(minimum_t))
        actual_t = actual_t + (0,) * (width - len(actual_t))
        minimum_t = minimum_t + (0,) * (width - len(minimum_t))
        return actual_t >= minimum_t
    return str(actual).lower() == str(minimum).lower()


@dataclass
class HostFacts:
    windows_version: str = "10.0.22631"
    architecture: str = "AMD64"
    powershell_version: str = "5.1"
    elevated: bool = False
    virtualization: bool = True
    wsl_feature: bool = False
    vm_platform: bool = False
    wsl_runtime: bool = False
    wsl_default_version: str = ""
    distro_present: bool = False
    distro_version: str = ""
    linux_user: bool = False
    linux_network: bool = False
    linux_dns: bool = False
    linux_https: bool = False
    container_engine: str = ""
    rootless_ok: bool = False
    ghcr_ok: bool = True
    ubuntu_ok: bool = True
    disk_bytes_free: int = 20 * 1024 * 1024 * 1024
    memory_bytes: int = 8 * 1024 * 1024 * 1024
    port_3434: str = PORT_FREE
    volume_class: str = RES_NONE
    resume_task: bool = False
    authorization_granted: bool = False
    resume_marker: bool = False
    user_declined: bool = False
    reboot_resume_failed: bool = False
    image_digest: str = PUBLIC_IMAGE_DIGEST


def wsl_host_ready(facts: HostFacts) -> bool:
    return bool(facts.wsl_runtime and (facts.wsl_feature or facts.wsl_runtime) and (facts.vm_platform or facts.wsl_runtime))


def any_admin_work_pending(facts: HostFacts) -> bool:
    if not wsl_host_ready(facts):
        return True
    if not facts.wsl_runtime:
        return True
    if facts.wsl_default_version != "2" and facts.distro_version != "2" and not facts.distro_present:
        return True
    if not facts.wsl_runtime and not facts.resume_task:
        return True
    return False


def needs_reboot(facts: HostFacts) -> bool:
    return not facts.wsl_runtime


def _status_ok(ok: bool) -> str:
    return "VERIFIED" if ok else "MISSING"


def evaluate_requirement(item: dict, facts: HostFacts) -> str:
    rid = str(item["id"])
    if facts.user_declined and rid == "administrator_elevation":
        return "BLOCKED"
    if facts.volume_class == RES_UNKNOWN_LEGACY and rid == "persistent_storage":
        return "BLOCKED"
    if facts.volume_class == RES_KNOWN_TEST and rid == "persistent_storage":
        return "BLOCKED"
    if facts.port_3434 == PORT_UNKNOWN_PROCESS and rid == "port_3434":
        return "BLOCKED"

    if rid == "windows_version":
        return _status_ok(version_meets(facts.windows_version, item.get("minimum_version") or "10.0.19041"))
    if rid == "windows_architecture":
        return _status_ok(facts.architecture.upper() in ("AMD64", "X64"))
    if rid == "powershell":
        return _status_ok(version_meets(facts.powershell_version, item.get("minimum_version") or "5.1"))
    if rid == "administrator_elevation":
        if facts.elevated:
            return "VERIFIED"
        if any_admin_work_pending(facts):
            return "MISSING"
        return "PRESENT"
    if rid == "virtualization":
        return _status_ok(facts.virtualization)
    if rid == "wsl_feature":
        return _status_ok(facts.wsl_feature or facts.wsl_runtime)
    if rid == "virtual_machine_platform":
        return _status_ok(facts.vm_platform or facts.wsl_runtime)
    if rid == "wsl_runtime":
        return _status_ok(facts.wsl_runtime)
    if rid == "wsl_version":
        return _status_ok(facts.wsl_default_version == "2" or facts.distro_version == "2")
    if rid == "managed_distribution":
        return _status_ok(facts.distro_present)
    if rid == "managed_distribution_version":
        return _status_ok(facts.distro_present and facts.distro_version == "2")
    if rid == "linux_user":
        return _status_ok(facts.linux_user)
    if rid == "linux_network":
        return _status_ok(facts.linux_network)
    if rid == "linux_dns":
        return _status_ok(facts.linux_dns)
    if rid == "linux_https":
        return _status_ok(facts.linux_https)
    if rid == "container_engine":
        return _status_ok(facts.container_engine == "podman")
    if rid == "rootless_prerequisites":
        return _status_ok(facts.rootless_ok or facts.container_engine == "podman")
    if rid == "public_ghcr_access":
        return _status_ok(facts.ghcr_ok)
    if rid == "public_ubuntu_access":
        return _status_ok(facts.ubuntu_ok)
    if rid == "disk_space":
        return _status_ok(facts.disk_bytes_free >= int(item.get("minimum_version") or "10737418240"))
    if rid == "memory":
        return _status_ok(facts.memory_bytes >= int(item.get("minimum_version") or "4294967296"))
    if rid == "port_3434":
        return _status_ok(facts.port_3434 in (PORT_FREE, PORT_CURRENT_CITIZEN))
    if rid == "persistent_storage":
        return _status_ok(facts.volume_class in (RES_NONE, RES_KNOWN_MANAGED))
    if rid == "scheduled_resume":
        if not needs_reboot(facts):
            return "PRESENT"
        return _status_ok(facts.resume_task)
    return "UNKNOWN"


@dataclass
class RequirementResult:
    id: str
    status: str
    user_label: str
    failure_message: str
    requires_admin: bool
    requires_reboot: bool
    provisioner: str
    critical: bool


@dataclass
class BootstrapPlan:
    plan_id: str
    results: list[RequirementResult]
    missing: list[str]
    blocked: list[str]
    needs_admin: bool
    needs_reboot: bool
    provisioners: list[str]
    phase: str
    user_lines: list[str] = field(default_factory=list)
    install_action: str = "BLOCKED"


def _collapse_user_lines(results: list[RequirementResult]) -> list[str]:
    labels: dict[str, str] = {}
    for row in results:
        show = "OK"
        if row.status in ("MISSING", "BLOCKED", "UNKNOWN"):
            show = "MISSING"
        elif row.status == "PROVISIONING":
            show = "MISSING"
        previous = labels.get(row.user_label)
        if previous != "MISSING":
            labels[row.user_label] = show
    return [f"{label}........................ {show}" for label, show in labels.items()]


def decide_phase(facts: HostFacts, results: list[RequirementResult], missing: list[str], blocked: list[str]) -> str:
    if facts.user_declined:
        return "USER_DECLINED"
    if facts.reboot_resume_failed:
        return "REBOOT_RESUME_FAILED"
    if facts.volume_class == RES_UNKNOWN_LEGACY:
        return "UNKNOWN_LEGACY"
    if facts.volume_class == RES_KNOWN_TEST:
        return "UNKNOWN_LEGACY"
    if facts.port_3434 == PORT_UNKNOWN_PROCESS:
        return "PORT_CONFLICT"
    by_id = {row.id: row for row in results}
    if any(by_id[rid].status == "MISSING" for rid in UNSUPPORTED_IDS if rid in by_id):
        return "UNSUPPORTED_HOST"
    if "port_3434" in blocked:
        return "PORT_CONFLICT"
    if "persistent_storage" in blocked:
        return "UNKNOWN_LEGACY"
    if any(rid in missing for rid in NETWORK_VERIFY_IDS):
        return "VERIFICATION_FAILED"
    admin_needed = any(row.requires_admin and row.status == "MISSING" for row in results)
    reboot_needed = any(row.requires_reboot and row.status == "MISSING" for row in results)
    provisionable = [row for row in results if row.status == "MISSING" and row.provisioner != "none"]
    if missing and not provisionable:
        return "VERIFICATION_FAILED"
    if admin_needed and not facts.elevated:
        return "AUTHORIZATION_REQUIRED"
    if facts.resume_marker and facts.wsl_runtime:
        return "RESUMING"
    if reboot_needed and facts.elevated:
        return "PROVISIONING"
    if provisionable:
        return "PLAN" if not facts.elevated else "PROVISIONING"
    if facts.resume_marker:
        return "RESUMING"
    if birth_allowed(facts):
        return "ENVIRONMENT_READY"
    return "VERIFYING"


def install_action(facts: HostFacts) -> str:
    if not birth_allowed(facts):
        return "BLOCKED"
    if facts.volume_class == RES_KNOWN_MANAGED:
        return "RESUME"
    return "BIRTH"


def birth_allowed(facts: HostFacts) -> bool:
    if facts.volume_class in (RES_UNKNOWN_LEGACY, RES_KNOWN_TEST):
        return False
    if facts.port_3434 == PORT_UNKNOWN_PROCESS:
        return False
    if not public_image_digest_ok(f"ghcr.io/grecoitalico/citizen@{PUBLIC_IMAGE_DIGEST}", facts.image_digest):
        return False
    return bool(
        facts.wsl_runtime
        and facts.distro_present
        and facts.distro_version == "2"
        and facts.container_engine == "podman"
        and facts.ghcr_ok
        and facts.ubuntu_ok
        and facts.linux_user
        and facts.volume_class in (RES_NONE, RES_KNOWN_MANAGED)
        and facts.port_3434 in (PORT_FREE, PORT_CURRENT_CITIZEN)
    )


def plan_requirements(facts: HostFacts, manifest: dict | None = None) -> BootstrapPlan:
    data = manifest if manifest is not None else load_requirements_manifest()
    results: list[RequirementResult] = []
    missing: list[str] = []
    blocked: list[str] = []
    provisioners: list[str] = []
    for item in data["requirements"]:
        status = evaluate_requirement(item, facts)
        row = RequirementResult(
            id=item["id"],
            status=status,
            user_label=item.get("user_label") or item["name"],
            failure_message=item["failure_message"],
            requires_admin=bool(item["requires_admin"]),
            requires_reboot=bool(item["requires_reboot"]),
            provisioner=str(item["provisioner"]),
            critical=bool(item["critical"]),
        )
        results.append(row)
        if status == "BLOCKED":
            blocked.append(row.id)
        if status == "MISSING":
            missing.append(row.id)
            if row.provisioner != "none" and row.provisioner not in provisioners:
                provisioners.append(row.provisioner)
    admin_needed = any(row.requires_admin and row.status == "MISSING" for row in results) and not facts.elevated
    reboot_needed = any(row.requires_reboot and row.status == "MISSING" for row in results)
    phase = decide_phase(facts, results, missing, blocked)
    plan_id = hashlib.sha256(",".join(missing + blocked).encode("utf-8")).hexdigest()[:16]
    return BootstrapPlan(
        plan_id=plan_id,
        results=results,
        missing=missing,
        blocked=blocked,
        needs_admin=admin_needed,
        needs_reboot=reboot_needed,
        provisioners=provisioners,
        phase=phase,
        user_lines=_collapse_user_lines(results),
        install_action=install_action(facts),
    )


def report_status(status: str) -> str:
    """Map planner states to the public requirements report."""
    if status in ("VERIFIED", "PRESENT", "READY"):
        return "READY"
    if status == "BLOCKED":
        return "BLOCKED"
    return "MISSING"


def report_suffix(show: str, *, failure_message: str = "") -> str:
    if show == "MISSING":
        return " → provision"
    if show == "BLOCKED":
        note = (failure_message or "explain").strip()
        return f" → {note}"
    return ""


def persistable_state(
    phase: str,
    plan: BootstrapPlan,
    *,
    installer_version: str,
    timestamp: str = "",
    host_seed_version: str = "",
    target_digest: str = "",
    request_id: str = "",
) -> dict:
    payload = {
        "bootstrap_phase": phase,
        "phase": phase,
        "plan_id": plan.plan_id,
        "resume_marker": phase in ("REBOOT_REQUIRED", "RESUMING", "AUTHORIZATION_REQUIRED", "PROVISIONING"),
        "installer_version": installer_version,
        "requirements_state": {row.id: row.status for row in plan.results},
        "timestamp": timestamp,
        "host_seed_version": host_seed_version,
        "target_digest": target_digest,
        "request_id": request_id,
    }
    for key in FORBIDDEN_STATE_KEYS:
        payload.pop(key, None)
    return payload


def assert_state_has_no_identity(payload: dict) -> None:
    blob = json.dumps(payload).lower()
    for key in FORBIDDEN_STATE_KEYS:
        if key in payload or f'"{key}"' in blob:
            raise ValueError(f"bootstrap state must not persist {key}")


def plan_as_dict(plan: BootstrapPlan) -> dict:
    return {
        "plan_id": plan.plan_id,
        "missing": plan.missing,
        "blocked": plan.blocked,
        "needs_admin": plan.needs_admin,
        "needs_reboot": plan.needs_reboot,
        "provisioners": plan.provisioners,
        "phase": plan.phase,
        "install_action": plan.install_action,
        "results": [asdict(row) for row in plan.results],
    }
