"""Host-seed CLI. Run from WSL (not inside the Citizen container)."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Host-owned runtime evolution seed")
    parser.add_argument("--home", required=True, help="Citizen volume path (WSL)")
    parser.add_argument("--data-dir", required=True, help="CitizenHost directory")
    parser.add_argument("--envelope", default="", help="CLASS_PACKAGE.json path")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default="3434")
    args = parser.parse_args(argv)

    from conrrad_citizen.host.host_seed import HOST_SEED_VERSION, TARGET_RUNTIME_IMAGE, install_host_seed
    from conrrad_citizen.host.linux import LinuxHostAdapter
    from conrrad_citizen.host.runtime_evolution_seed import apply_runtime_evolution_seed
    from conrrad_citizen.host.seed_receipts import append_receipt

    home = Path(args.home)
    data = Path(args.data_dir)
    install_host_seed(data)
    envelope_path = Path(args.envelope) if args.envelope else data / "host-seed" / "CLASS_PACKAGE.json"
    if not envelope_path.is_file():
        updates = home / "updates" / "CLASS_PACKAGE.json"
        if updates.is_file():
            envelope_path = updates
    append_receipt(data, "RUNTIME_EVOLUTION_REQUESTED", envelope=str(envelope_path))

    host = LinuxHostAdapter(
        data_dir=data,
        home=home,
        host=args.host,
        port=args.port,
    )
    if hasattr(host.backend, "set_image"):
        host.backend.set_image(TARGET_RUNTIME_IMAGE)

    result = apply_runtime_evolution_seed(
        host=host,
        envelope_path=envelope_path if envelope_path.is_file() else None,
        resume=True,
    )
    kind = "READY_AFTER_RUNTIME_EVOLUTION" if result.ok else (
        "ROLLBACK" if result.details.get("ROLLBACK") else "ERROR"
    )
    if result.ok:
        append_receipt(data, "PACKAGE_VERIFIED")
        if result.details.get("runtime_replaced"):
            append_receipt(data, "IMAGE_PREPARED", digest=result.details.get("runtime_image_digest"))
            append_receipt(data, "ENVIRONMENT_SWITCHED")
        append_receipt(data, "READY_AFTER_RUNTIME_EVOLUTION", birth=False)
    else:
        append_receipt(data, kind, message=result.message)
    payload = {
        "ok": result.ok,
        "state": result.state,
        "message": result.message,
        "host_seed_version": HOST_SEED_VERSION,
        "birth": False,
        **(result.details or {}),
    }
    print(json.dumps(payload, indent=2))
    return 0 if result.ok else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
