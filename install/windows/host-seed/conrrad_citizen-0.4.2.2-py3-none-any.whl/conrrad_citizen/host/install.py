"""Managed Citizen install orchestration.

HostAdapter may detect, provision isolation, manage volume/environment, publish
ports, health, logs, restart, recovery, and open a browser.

It must not mint identity, run Work, Sync, or evolve.
"""
from __future__ import annotations

import json
import os
import stat
from pathlib import Path

from conrrad_citizen.host.contract import USER_ACTION_REQUIRED, HostResult
from conrrad_citizen.host.isolation.image import RUNTIME_VERSION, environment_name
from conrrad_citizen.host.isolation.state import write_state
from conrrad_citizen.host.isolation.volume import volume_is_born
from conrrad_citizen.host.linux import LinuxHostAdapter


def diagnostics_enabled() -> bool:
    return os.environ.get("CITIZEN_DIAGNOSTICS", "").strip().lower() in {"1", "true", "yes"}


def default_bin_dir() -> Path:
    return Path(os.environ.get("CITIZEN_BIN_DIR", str(Path.home() / ".local" / "bin")))


def install_host_dispatcher(*, bin_dir: Path, engine: str, environment: str) -> Path:
    """Tiny host command that execs into the managed environment. Not Citizen Python."""
    bin_dir = Path(bin_dir)
    bin_dir.mkdir(parents=True, exist_ok=True)
    path = bin_dir / "citizen"
    script = (
        "#!/bin/bash\n"
        "# Host dispatcher. Citizen runtime lives in the managed environment.\n"
        f'exec {engine} exec -i {environment} citizen "$@"\n'
    )
    path.write_text(script, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    return path


def living_version_from_volume(home: Path) -> str:
    runtime = home / "runtime" / "RUNTIME_VERSION"
    if runtime.is_file():
        text = runtime.read_text(encoding="utf-8").strip()
        if text:
            return text
    manifest = home / "manifest" / "current.json"
    if manifest.is_file():
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError, UnicodeDecodeError):
            data = {}
        if isinstance(data, dict):
            version = str(data.get("citizen_version") or data.get("runtime_version") or "").strip()
            if version:
                return version
    return RUNTIME_VERSION


def managed_install(host: LinuxHostAdapter, *, write_dispatcher: bool = False) -> HostResult:
    """Detect → infra → image → volume → environment → Birth-or-Resume inside → READY.

    Does not Sync. Does not destroy an existing volume on failure.
    """
    home = Path(host.home)
    data_dir = Path(host.data_dir)
    write_state(data_dir, phase="started", volume=str(home), port=str(host.port))

    occupied = host._port_conflict()
    if occupied is not None:
        write_state(data_dir, phase="port", state=occupied.state)
        return occupied

    already_born = volume_is_born(home)
    write_state(data_dir, phase="volume", born=already_born)

    prov = host.provision()
    if not prov.ok:
        return prov

    started = host.start()
    if not started.ok:
        return started

    health = host.wait_health()
    if not health.ok:
        write_state(data_dir, phase="health", state=health.state, message=health.message)
        return health

    opened = host.open_ui()
    version = living_version_from_volume(home)
    if write_dispatcher:
        engine = getattr(host.backend, "name", "podman")
        if engine in {"podman", "docker"}:
            install_host_dispatcher(
                bin_dir=default_bin_dir(),
                engine=engine,
                environment=getattr(host.backend, "environment", environment_name()),
            )

    write_state(
        data_dir,
        phase="ready",
        born_before=already_born,
        birth=not already_born,
        sync=False,
        version=version,
        ui=host.network().get("ui"),
        browser_opened=bool((opened.details or {}).get("opened")),
    )
    details = {
        "volume": str(home),
        "born_before": already_born,
        "birth": not already_born,
        "sync": False,
        "version": version,
        "ui": host.network().get("ui"),
        "browser_opened": bool((opened.details or {}).get("opened")),
        **host.network(),
    }
    return HostResult(True, "READY", "Citizen READY", details)
