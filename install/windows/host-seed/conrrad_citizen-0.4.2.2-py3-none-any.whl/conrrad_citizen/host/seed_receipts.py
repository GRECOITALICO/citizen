"""Local host-seed receipts. Not a telemetry server. Not Citizen Evidence."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

RECEIPT_FILE = "HOST_SEED_RECEIPTS.jsonl"
KINDS = (
    "HOST_SEED_STARTED",
    "RUNTIME_EVOLUTION_REQUESTED",
    "PACKAGE_VERIFIED",
    "IMAGE_PREPARED",
    "ENVIRONMENT_SWITCHED",
    "READY_AFTER_RUNTIME_EVOLUTION",
    "ROLLBACK",
    "ERROR",
)


def receipts_path(host_dir: Path) -> Path:
    return Path(host_dir) / RECEIPT_FILE


def append_receipt(host_dir: Path, kind: str, **fields: Any) -> dict[str, Any]:
    if kind not in KINDS:
        kind = "ERROR"
        fields = {**fields, "invalid_kind": True}
    row = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "kind": kind,
        "owner": "HOST_ADAPTER",
        **{k: v for k, v in fields.items() if k not in {"secret", "prompt", "history", "evidence"}},
    }
    path = receipts_path(host_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, sort_keys=True) + "\n")
    return row


def read_receipts(host_dir: Path) -> list[dict[str, Any]]:
    path = receipts_path(host_dir)
    if not path.is_file():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict):
            rows.append(item)
    return rows
