"""Install and recover the host-owned Runtime Evolution Seed.

Lives in CitizenHost, not in Citizen Life. Does not mint identity, store
History, or write Evidence.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .seed_receipts import append_receipt

HOST_SEED_VERSION = "0.4.2.8"
HOST_SEED_DIRNAME = "host-seed"
SOURCE_RUNTIME_DIGEST = "sha256:64df202d553c5aaff9cc0c74b01b8617e5877253778c9766d51dd59febd840da"
TARGET_RUNTIME_DIGEST = "sha256:446da11ded1a23a64d1c906b98383215606d257a598026e99cc8b8cdeea0635e"
TARGET_RUNTIME_IMAGE = f"ghcr.io/grecoitalico/citizen@{TARGET_RUNTIME_DIGEST}"
MANAGED_DISTRO = "CONRRAD-Citizen"
PRODUCT_PORT = "3434"

RECOVER = "RECOVER"
DO_NOT_REINSTALL = "DO_NOT_REINSTALL"
STOP_UNKNOWN_DISTRO = "STOP_UNKNOWN_DISTRO"
FRESH_INSTALL = "FRESH_INSTALL"


def host_seed_dir(host_dir: Path) -> Path:
    return Path(host_dir) / HOST_SEED_DIRNAME


def install_host_seed(host_dir: Path, *, package_bytes: bytes | None = None) -> dict[str, Any]:
    """Write host-seed files into CitizenHost. Never touches the Citizen volume."""
    dest = host_seed_dir(host_dir)
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "VERSION").write_text(HOST_SEED_VERSION + "\n", encoding="utf-8")
    marker = {
        "owner": "HOST_ADAPTER",
        "version": HOST_SEED_VERSION,
        "citizen_podman_authority": False,
        "manages": [
            "runtime_request",
            "class_package_verification",
            "oci_replacement",
            "container_replacement",
            "rollback",
            "health_check",
            "resume",
        ],
        "does_not_own": ["identity", "history", "evidence", "memory", "work"],
    }
    (dest / "HOST_SEED.json").write_text(json.dumps(marker, indent=2) + "\n", encoding="utf-8")
    if package_bytes is not None:
        (dest / "CLASS_PACKAGE.json").write_bytes(package_bytes)
    append_receipt(host_dir, "HOST_SEED_STARTED", version=HOST_SEED_VERSION)
    return {
        "installed": True,
        "version": HOST_SEED_VERSION,
        "path": str(dest),
        "volume_touched": False,
    }


def read_host_seed_version(host_dir: Path) -> str:
    path = host_seed_dir(host_dir) / "VERSION"
    if not path.is_file():
        return ""
    return path.read_text(encoding="utf-8").strip()


def inventory(
    *,
    distro_present: bool,
    distro_name: str = MANAGED_DISTRO,
    host_bootstrap_ours: bool = False,
    guest_managed_marker: bool = False,
    dest_vhdx_present: bool = False,
    known_citizen: bool = False,
    volume_exists: bool = False,
    port_class: str = "FREE",
    current_image_digest: str = "",
    host_seed_version: str = "",
    product_ready: bool = False,
) -> dict[str, Any]:
    owned = host_bootstrap_ours or guest_managed_marker or dest_vhdx_present
    ownership = "ABSENT"
    if distro_present and owned:
        ownership = "KNOWN_MANAGED_DISTRO"
    elif distro_present:
        ownership = "UNKNOWN_DISTRO"
    return {
        "distro": distro_name,
        "distro_present": distro_present,
        "ownership": ownership,
        "host_seed_version": host_seed_version,
        "volume_exists": volume_exists,
        "known_citizen": known_citizen,
        "container": "conrrad-citizen",
        "port": PRODUCT_PORT,
        "port_class": port_class,
        "public_runtime": TARGET_RUNTIME_IMAGE,
        "current_image_digest": current_image_digest,
        "product_ready": product_ready,
        "host_bootstrap_ours": host_bootstrap_ours,
    }


def recovery_plan(facts: dict[str, Any]) -> str:
    if facts.get("ownership") == "UNKNOWN_DISTRO":
        return STOP_UNKNOWN_DISTRO
    if facts.get("known_citizen") and facts.get("product_ready"):
        return DO_NOT_REINSTALL
    if facts.get("known_citizen") or facts.get("ownership") == "KNOWN_MANAGED_DISTRO":
        return RECOVER
    return FRESH_INSTALL


def existing_citizen_must_not_birth(plan: str) -> bool:
    return plan in {RECOVER, DO_NOT_REINSTALL}
