"""Linux host adapter — isolation backend, volume, and port ownership.

Does not launch Citizen Python on the host.
Does not mint identity, run Work, or apply Sync.
"""
from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from .contract import USER_ACTION_REQUIRED, HostResult
from .isolation.linux_infra import provision_isolation_infrastructure
from .isolation.select import select_backend
from .isolation.state import write_state
from .isolation.volume import VOLUME_MOUNT, ensure_volume_root, volume_is_born


def intended_python() -> str:
    """Retained helper. Not the Citizen environment interpreter."""
    env = os.environ.get("CITIZEN_PYTHON", "").strip()
    if env:
        return env
    return sys.executable


class LinuxHostAdapter:
    def __init__(
        self,
        *,
        data_dir: Path,
        home: Path,
        host: str | None = None,
        port: str | int | None = None,
        python: str | None = None,
        unit_dir: Path | None = None,
        runner=None,
        backend=None,
        **_: object,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.home = Path(home)
        self.host = host or os.environ.get("CITIZEN_UI_HOST", "127.0.0.1")
        self.port = str(port or os.environ.get("CITIZEN_UI_PORT", "3434"))
        self.python = python  # ignored; Citizen Python lives in the environment
        self.unit_dir = Path(unit_dir) if unit_dir is not None else None
        self._runner = runner
        self._backend_forced = backend is not None
        self.backend = backend or select_backend(
            volume=self.home,
            host=self.host,
            port=self.port,
            runner=runner,
        )

    def volume(self) -> dict[str, str]:
        return {
            "volume": str(self.home),
            "mount": VOLUME_MOUNT,
            "backend": getattr(self.backend, "name", "unknown"),
            "data_dir": str(self.data_dir),
        }

    def network(self) -> dict[str, str]:
        published = self.backend.publish()
        host = published.get("host", self.host)
        port = published.get("host_port", self.port)
        return {
            "host": host,
            "port": port,
            "ui": f"http://{host}:{port}/",
            "environment_port": published.get("environment_port", "3434"),
        }

    def provision(self) -> HostResult:
        detected = self.backend.detect()
        if not detected.available:
            if self._backend_forced:
                return HostResult(
                    False,
                    "UNAVAILABLE",
                    detected.reason,
                    {"phase": "provision", "backend": detected.name},
                )
            infra = provision_isolation_infrastructure(runner=self._runner)
            write_state(self.data_dir, phase="infra", infra=infra.state, backend=detected.name)
            if not infra.ok:
                return HostResult(
                    False,
                    infra.state,
                    infra.message,
                    {"phase": "provision", "backend": detected.name, **(infra.details or {})},
                )
            self.backend = select_backend(
                volume=self.home,
                host=self.host,
                port=self.port,
                runner=self._runner,
            )
            detected = self.backend.detect()
        if not detected.available:
            return HostResult(
                False,
                "UNAVAILABLE",
                detected.reason,
                {"phase": "provision", "backend": detected.name},
            )
        ensure_volume_root(self.home)
        prepared = self.backend.provision()
        if not prepared.ok:
            return prepared
        created = self.backend.create_environment()
        if not created.ok:
            return created
        write_state(self.data_dir, phase="environment", backend=getattr(self.backend, "name", ""))
        return HostResult(True, "PROVISIONED", "Isolation environment provisioned", {
            "backend": getattr(self.backend, "name", ""),
            "volume": str(self.home),
            **self.network(),
        })

    def start(self) -> HostResult:
        occupied = self._port_conflict()
        if occupied is not None:
            return occupied
        born = volume_is_born(self.home)
        env_up = self.backend.health().ok
        http = self._http_health()
        if born and env_up and http.ok:
            return HostResult(True, "READY", "Already healthy", http.details)
        created = self.backend.create_environment()
        if not created.ok:
            return created
        started = self.backend.start()
        if not started.ok:
            return started
        return HostResult(True, "STARTED", "Host environment started", {
            "home": str(self.home),
            **self.network(),
        })

    def stop(self) -> HostResult:
        return self.backend.stop()

    def restart(self) -> HostResult:
        occupied = self._port_conflict()
        if occupied is not None:
            return occupied
        restarted = self.backend.restart()
        if not restarted.ok:
            return restarted
        return HostResult(True, "STARTED", "Host environment restarted", {
            "home": str(self.home),
            **self.network(),
        })

    def status(self) -> HostResult:
        st = self.backend.status()
        return HostResult(True, st.state, "Host status", {
            "service": st.state,
            "backend": getattr(self.backend, "name", ""),
            **self.volume(),
            **self.network(),
            **(st.details or {}),
        })

    def health(self) -> HostResult:
        env = self.backend.health()
        http = self._http_health()
        if env.ok and http.ok:
            return HostResult(True, "READY", "Living API reachable", {
                "url": http.details.get("url"),
                "environment": env.state,
            })
        if not env.ok:
            return HostResult(False, "FAILED", "environment not running", {
                "environment": env.message,
                "url": http.details.get("url"),
            })
        return http

    def open_ui(self) -> HostResult:
        """Open the Citizen UI. Failure is not a Citizen failure if HTTP health is ok."""
        url = self.network().get("ui") or f"http://{self.host}:{self.port}/"
        if os.environ.get("CITIZEN_OPEN_BROWSER", "1") == "0":
            return HostResult(True, "SKIPPED", url, {"url": url, "opened": False})
        try:
            subprocess.Popen(
                ["xdg-open", url],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            return HostResult(True, "OPENED", url, {"url": url, "opened": True})
        except OSError:
            return HostResult(True, "SKIPPED", url, {"url": url, "opened": False})

    def wait_health(self, attempts: int | None = None, delay: float | None = None) -> HostResult:
        if attempts is None:
            attempts = int(os.environ.get("CITIZEN_HOST_HEALTH_ATTEMPTS", "10"))
        if delay is None:
            delay = float(os.environ.get("CITIZEN_HOST_HEALTH_DELAY", "1.0"))
        last = self.health()
        for _ in range(max(attempts, 1)):
            last = self.health()
            if last.ok:
                return last
            time.sleep(delay)
        return last

    def logs(self) -> HostResult:
        return self.backend.logs()

    def destroy_environment(self) -> HostResult:
        return self.backend.destroy_environment()

    def disable(self) -> HostResult:
        self.backend.stop()
        destroyed = self.backend.destroy_environment()
        return HostResult(True, "REMOVED", "Host environment removed", {
            "volume": str(self.home),
            "volume_preserved": True,
            **(destroyed.details or {}),
        })

    def repair(self) -> HostResult:
        """Recreate the environment. Never touches Citizen volume identity."""
        self.backend.destroy_environment()
        return self.provision()

    def apply_class_package(
        self,
        envelope: dict | None = None,
        *,
        envelope_path=None,
        living_apply=None,
    ) -> HostResult:
        """Host-owned CLASS_PACKAGE apply. Never Births. Guest never replaces the environment."""
        from .runtime_evolution_seed import apply_runtime_evolution_seed

        return apply_runtime_evolution_seed(
            host=self,
            envelope=envelope,
            envelope_path=envelope_path,
            living_apply=living_apply,
        )

    def _http_health(self) -> HostResult:
        url = f"http://{self.host}:{self.port}/api/living"
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                if resp.status == 200:
                    return HostResult(True, "READY", "Living API reachable", {"url": url})
        except Exception:
            pass
        return HostResult(False, "FAILED", "Living API not reachable", {"url": url})

    def _port_conflict(self, *, ignore_our_service: bool = False) -> HostResult | None:
        pid = listener_pid(self.host, int(self.port))
        if pid is None:
            return None
        if ignore_our_service or self._pid_is_ours(pid):
            return None
        return HostResult(
            False,
            USER_ACTION_REQUIRED,
            f"Port {self.port} is in use by process {pid}, which is not this Citizen. "
            "Free the port or set CITIZEN_UI_PORT. The process was not stopped.",
            {"pid": pid, "port": self.port},
        )

    def _pid_is_ours(self, pid: int) -> bool:
        owns = getattr(self.backend, "owns_pid", None)
        if callable(owns):
            return bool(owns(pid))
        return False


def listener_pid(host: str, port: int) -> int | None:
    """PID listening on host:port, or None if the port is free / unknown."""
    if _port_free(host, port):
        return None
    r = subprocess.run(
        ["ss", "-ltnp", f"sport = :{port}"],
        capture_output=True,
        text=True,
    )
    text = (r.stdout or "") + (r.stderr or "")
    marker = "pid="
    if marker in text:
        try:
            return int(text.split(marker, 1)[1].split(",")[0])
        except (ValueError, IndexError):
            pass
    r = subprocess.run(["lsof", "-ti", f"tcp:{port}"], capture_output=True, text=True)
    pids = [p for p in (r.stdout or "").split() if p.isdigit()]
    if pids:
        return int(pids[0])
    return -1


def _port_free(host: str, port: int) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.3)
            return s.connect_ex((host, port)) != 0
    except OSError:
        return True
