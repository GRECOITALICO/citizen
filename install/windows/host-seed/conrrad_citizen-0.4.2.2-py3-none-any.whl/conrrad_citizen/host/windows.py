"""Windows host adapter — WSL2 infrastructure only.

Citizen life (Birth, Work, Identity, Sync) runs inside the Linux guest
via the existing LinuxHostAdapter / citizen CLI. This module never mints
identity or applies evolution.

Rootfs for `wsl --import` (tar.gz, not the .wsl double-click package):
  URL:      https://cloud-images.ubuntu.com/wsl/releases/24.04/current/ubuntu-noble-wsl-amd64-24.04lts.rootfs.tar.gz
  Checksum: https://cloud-images.ubuntu.com/wsl/releases/24.04/current/SHA256SUMS
  Signature:https://cloud-images.ubuntu.com/wsl/releases/24.04/current/SHA256SUMS.gpg
  Equivalent checksum:
            https://cloud-images.ubuntu.com/wsl/releases/noble/current/SHA256SUMS

`wsl --import` requires a tar rootfs. The Ubuntu `.wsl` image is for
`wsl --install --from-file` and is not used here.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from .contract import USER_ACTION_REQUIRED, HostResult
from conrrad_citizen.windows.wsl_readiness import ProbeResult, bin_true_is_fatal

DISTRO = "CONRRAD-Citizen"
GUEST_DATA = "/home/citizen/.local/share/conrrad-citizen"
GUEST_HOME = f"{GUEST_DATA}/.citizen"
GUEST_VENV_PYTHON = f"{GUEST_DATA}/venv/bin/python"
GUEST_CITIZEN = f"{GUEST_DATA}/venv/bin/citizen"
MANAGED_MARKER = "/etc/conrrad-citizen-managed"
MIN_PYTHON = (3, 11)

PUBLIC_IMAGE_NAME = "ghcr.io/grecoitalico/citizen"
PUBLIC_IMAGE_DIGEST = "sha256:446da11ded1a23a64d1c906b98383215606d257a598026e99cc8b8cdeea0635e"
SOURCE_RUNTIME_DIGEST = "sha256:64df202d553c5aaff9cc0c74b01b8617e5877253778c9766d51dd59febd840da"
PUBLIC_WINDOWS_TAG = "citizen-windows-wsl2-0.4.2.8"
PUBLIC_LINUX_INSTALL_TAG = "citizen-managed-0.4.2.1"
PUBLIC_LINUX_INSTALL_URL = (
    "https://raw.githubusercontent.com/GRECOITALICO/citizen/"
    f"{PUBLIC_LINUX_INSTALL_TAG}/install.sh"
)
PUBLIC_WINDOWS_BOOTSTRAP_URL = (
    "https://raw.githubusercontent.com/GRECOITALICO/citizen/"
    f"{PUBLIC_WINDOWS_TAG}/install/windows.ps1"
)
PUBLIC_WINDOWS_REQUIREMENTS_URL = (
    "https://raw.githubusercontent.com/GRECOITALICO/citizen/"
    f"{PUBLIC_WINDOWS_TAG}/install/windows/requirements.json"
)
PUBLIC_IMAGE_REF = f"{PUBLIC_IMAGE_NAME}@{PUBLIC_IMAGE_DIGEST}"

# Historical frozen wheel (image build input). The Windows door must not pip-install it.
CANONICAL_WHEEL_NAME = "conrrad_citizen-0.4.2-py3-none-any.whl"
CANONICAL_WHEEL_SHA256 = "0b4eb6d336352901e783f747bc5f2cc1775f0822ec1be17c145143ea6a4457ce"
CANONICAL_WHEEL_URL = (
    "https://raw.githubusercontent.com/GRECOITALICO/citizen/"
    "citizen-runtime-0.4.2/release/0.4.2/" + CANONICAL_WHEEL_NAME
)

ROOTFS_NAME = "ubuntu-noble-wsl-amd64-24.04lts.rootfs.tar.gz"
ROOTFS_URL = "https://cloud-images.ubuntu.com/wsl/releases/24.04/current/" + ROOTFS_NAME
ROOTFS_SHA256SUMS_URL = "https://cloud-images.ubuntu.com/wsl/releases/24.04/current/SHA256SUMS"
ROOTFS_SHA256SUMS_GPG_URL = "https://cloud-images.ubuntu.com/wsl/releases/24.04/current/SHA256SUMS.gpg"
ROOTFS_SHA256SUMS_URL_NOBLE = "https://cloud-images.ubuntu.com/wsl/releases/noble/current/SHA256SUMS"
ROOTFS_URL_NOBLE = "https://cloud-images.ubuntu.com/wsl/releases/noble/current/" + ROOTFS_NAME
ROOTFS_SHA256SUMS_GPG_URL_NOBLE = "https://cloud-images.ubuntu.com/wsl/releases/noble/current/SHA256SUMS.gpg"
GZIP_MAGIC = b"\x1f\x8b"
_SHA256_HEX = re.compile(r"^[0-9a-fA-F]{64}$")
ALLOWED_CHECKSUM_MIME = ("", "text/plain", "application/octet-stream", "binary/octet-stream")
ROOTFS_VERIFY_FAILED = (
    "Ubuntu rootfs verification could not be completed.\n"
    "No WSL distro was imported and no Citizen was created."
)
REBOOT_USER_MESSAGE = (
    "Reboot required. Citizen has not been created yet.\n"
    "The installation will resume automatically after Windows starts."
)


@dataclass(frozen=True)
class OfficialRootfsSource:
    sums_url: str
    rootfs_url: str
    gpg_url: str


@dataclass
class HttpFetch:
    data: bytes
    status: int = 200
    content_type: str = "text/plain"
    final_url: str = ""
    url: str = ""
    error: str = ""


@dataclass
class ChecksumProbe:
    sha_url: str = ""
    sha_http_status: int | None = None
    sha_final_url: str = ""
    sha_content_type: str = ""
    sha_content_length: int | None = None
    rootfs_name: str = ROOTFS_NAME
    checksum_source_found: bool = False
    expected_sha256: str = ""
    actual_sha256: str = ""
    rootfs_url: str = ""
    gpg_url: str = ""
    reason: str = ""


OFFICIAL_ROOTFS_SOURCES = (
    OfficialRootfsSource(ROOTFS_SHA256SUMS_URL, ROOTFS_URL, ROOTFS_SHA256SUMS_GPG_URL),
    OfficialRootfsSource(ROOTFS_SHA256SUMS_URL_NOBLE, ROOTFS_URL_NOBLE, ROOTFS_SHA256SUMS_GPG_URL_NOBLE),
)
ROOTFS_SHA256SUMS_URLS = tuple(src.sums_url for src in OFFICIAL_ROOTFS_SOURCES)
ROOTFS_URLS = tuple(src.rootfs_url for src in OFFICIAL_ROOTFS_SOURCES)

WSL_START = "WSL_START"
WSL_STOP = "WSL_STOP"
WSL_RESTART = "WSL_RESTART"
WSL_HEALTH = "WSL_HEALTH"
WSL_DISTRIBUTION = "WSL_DISTRIBUTION"

PHASE_MISSING = "wsl_missing"
PHASE_ENABLE_REQUESTED = "wsl_enable_requested"
PHASE_PENDING_REBOOT = "wsl_pending_reboot"
PHASE_WSL_READY = "wsl_ready"
PHASE_DISTRO_PROVISIONING = "distro_provisioning"
PHASE_NEED_DISTRO = PHASE_DISTRO_PROVISIONING
PHASE_RUNTIME_PROVISIONING = "runtime_provisioning"
PHASE_CITIZEN_BIRTH = "citizen_birth"
PHASE_READY = "ready"
PHASE_FAILED = "failed"
PHASE_WSL1 = "wsl1_managed"

HOST_PHASES = (
    PHASE_MISSING,
    PHASE_ENABLE_REQUESTED,
    PHASE_PENDING_REBOOT,
    PHASE_WSL_READY,
    PHASE_DISTRO_PROVISIONING,
    PHASE_RUNTIME_PROVISIONING,
    PHASE_CITIZEN_BIRTH,
    PHASE_READY,
    PHASE_FAILED,
)

KNOWN_MARKERS = ("identity/SEALED", "identity/identity.json", "boot/BOOTSTRAP_DISARMED")
LEGACY_HINTS = (
    "CitizenSetup",
    "CitizenData",
    "nuclear_clean",
    r"%LOCALAPPDATA%\\CONRRAD\\CitizenData",
    ".conrrad/citizen",
)
REBOOT_MARKERS = ("reboot", "restart your computer", "pending reboot", "wsl_e_wsl_optional_component")
ELEVATION_MARKERS = (
    "access is denied",
    "access denied",
    "requested operation requires elevation",
    "error 740",
    "winerror 740",
)


def verify_artifact(path: Path, expected: str = CANONICAL_WHEEL_SHA256) -> HostResult:
    raw = Path(path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != expected.lower():
        return HostResult(False, "FAILED", "Artifact SHA256 mismatch", {
            "expected": expected,
            "actual": digest,
        })
    return HostResult(True, "VERIFIED", "Canonical runtime artifact", {
        "sha256": digest,
        "name": Path(path).name,
    })


def windows_path_to_wsl(path: Path | str) -> str:
    """Map a Windows path to the WSL /mnt drive view. Posix paths pass through."""
    text = str(path).replace("\\", "/")
    if len(text) >= 2 and text[1] == ":":
        return f"/mnt/{text[0].lower()}{text[2:]}"
    return text


def checksum_source_matches_rootfs(sums_url: str, rootfs_url: str, filename: str = ROOTFS_NAME) -> bool:
    """The checksum manifest directory must be the directory of the selected rootfs."""
    if not sums_url.endswith("/SHA256SUMS"):
        return False
    return rootfs_url == sums_url[: -len("SHA256SUMS")] + filename


def checksum_mime_ok(content_type: str) -> bool:
    raw = (content_type or "").split(";")[0].strip().lower()
    return raw in ALLOWED_CHECKSUM_MIME


def _looks_like_utf16le(data: bytes) -> bool:
    sample = data[: min(len(data), 400)]
    if len(sample) < 8:
        return False
    nuls = sum(1 for i in range(1, len(sample), 2) if sample[i] == 0)
    return nuls >= (len(sample) // 4)


def decode_checksum_bytes(data: bytes) -> str:
    """Decode official SHA256SUMS bytes. Strip UTF-16 NULs from mis-decoded Windows IWR bodies."""
    if not data:
        return ""
    if data.startswith(b"\xff\xfe"):
        text = data.decode("utf-16-le", errors="replace")
    elif data.startswith(b"\xfe\xff"):
        text = data.decode("utf-16-be", errors="replace")
    elif _looks_like_utf16le(data):
        text = data.decode("utf-16-le", errors="replace")
    else:
        text = data.decode("utf-8", errors="replace")
    return text.replace("\x00", "").replace("\ufeff", "")


def looks_like_html_or_interstitial(text: str) -> bool:
    head = (text or "").lstrip()[:2048]
    low = head.lower()
    if not low:
        return False
    if low.startswith("<!doctype html") or low.startswith("<html") or "<html" in low[:400]:
        return True
    if "<form" in low and any(token in low for token in ("login", "sign in", "password", "sso")):
        return True
    if any(token in low for token in ("proxy error", "captive portal", "authentication required")):
        return True
    return False


def parse_sha256sums(text: str, filename: str) -> str:
    """Extract a 64-hex SHA256 for filename. Ignore HTML href hits and short tokens."""
    for line in str(text).replace("\x00", "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        digest = parts[0].lower()
        if not _SHA256_HEX.fullmatch(digest):
            continue
        name = parts[-1].lstrip("*")
        if name == filename or name.endswith("/" + filename):
            return digest
    return ""


def inspect_checksum_manifest(
    *,
    text: str = "",
    data: bytes | None = None,
    content_type: str = "",
    status: int = 200,
    filename: str = ROOTFS_NAME,
) -> ChecksumProbe:
    """Classify an official checksum response. Never invent a checksum."""
    body = data if data is not None else text.encode("utf-8", errors="replace")
    decoded = decode_checksum_bytes(body) if data is not None else str(text).replace("\x00", "")
    probe = ChecksumProbe(
        sha_http_status=status,
        sha_content_type=content_type,
        sha_content_length=len(body),
        rootfs_name=filename,
    )
    if status not in (0, 200):
        probe.reason = f"http_{status}"
        return probe
    if not checksum_mime_ok(content_type):
        probe.reason = "unexpected_mime"
        return probe
    if not decoded.strip():
        probe.reason = "empty"
        return probe
    if looks_like_html_or_interstitial(decoded):
        probe.reason = "html"
        return probe
    expected = parse_sha256sums(decoded, filename)
    if not expected:
        probe.reason = "filename_missing"
        return probe
    probe.checksum_source_found = True
    probe.expected_sha256 = expected
    probe.reason = "ok"
    return probe


def normalize_http_fetch(url: str, raw: object) -> HttpFetch:
    if isinstance(raw, HttpFetch):
        return HttpFetch(
            data=raw.data,
            status=raw.status,
            content_type=raw.content_type,
            final_url=raw.final_url or url,
            url=raw.url or url,
            error=raw.error,
        )
    if isinstance(raw, bytes):
        return HttpFetch(data=raw, url=url, final_url=url)
    if isinstance(raw, dict):
        data = raw.get("data") or raw.get("bytes") or b""
        if not isinstance(data, bytes):
            data = bytes(data)
        return HttpFetch(
            data=data,
            status=int(raw.get("status") or raw.get("SHA_HTTP_STATUS") or 200),
            content_type=str(raw.get("content_type") or raw.get("SHA_CONTENT_TYPE") or ""),
            final_url=str(raw.get("final_url") or raw.get("SHA_FINAL_URL") or url),
            url=str(raw.get("url") or url),
            error=str(raw.get("error") or ""),
        )
    raise TypeError(f"unsupported fetch result {type(raw)!r}")


def retrieve_official_checksum(fetch_fn) -> ChecksumProbe:
    """Try documented 24.04 WSL SHA256SUMS, then the Noble equivalent. Official Ubuntu only."""
    last = ChecksumProbe(rootfs_name=ROOTFS_NAME, reason="no_official_source")
    for src in OFFICIAL_ROOTFS_SOURCES:
        if not checksum_source_matches_rootfs(src.sums_url, src.rootfs_url, ROOTFS_NAME):
            return ChecksumProbe(
                sha_url=src.sums_url,
                rootfs_name=ROOTFS_NAME,
                rootfs_url=src.rootfs_url,
                gpg_url=src.gpg_url,
                reason="filename_checksum_source_mismatch",
            )
        try:
            fetch = normalize_http_fetch(src.sums_url, fetch_fn(src.sums_url))
        except Exception as exc:
            last = ChecksumProbe(
                sha_url=src.sums_url,
                sha_http_status=0,
                sha_final_url=src.sums_url,
                rootfs_name=ROOTFS_NAME,
                rootfs_url=src.rootfs_url,
                gpg_url=src.gpg_url,
                reason="fetch_error",
            )
            last.sha_content_type = str(exc)
            continue
        probe = inspect_checksum_manifest(
            data=fetch.data,
            content_type=fetch.content_type,
            status=fetch.status,
            filename=ROOTFS_NAME,
        )
        probe.sha_url = fetch.url or src.sums_url
        probe.sha_final_url = fetch.final_url or src.sums_url
        probe.sha_http_status = fetch.status
        probe.sha_content_type = fetch.content_type
        probe.sha_content_length = len(fetch.data)
        probe.rootfs_url = src.rootfs_url
        probe.gpg_url = src.gpg_url
        last = probe
        if probe.checksum_source_found:
            return probe
    if last.reason == "ok":
        last.reason = "filename_missing"
    return last


def probe_diag_fields(probe: ChecksumProbe) -> dict:
    return {
        "SHA_URL": probe.sha_url,
        "SHA_HTTP_STATUS": probe.sha_http_status,
        "SHA_FINAL_URL": probe.sha_final_url,
        "SHA_CONTENT_TYPE": probe.sha_content_type,
        "SHA_CONTENT_LENGTH": probe.sha_content_length,
        "ROOTFS_NAME": probe.rootfs_name,
        "CHECKSUM_SOURCE_FOUND": probe.checksum_source_found,
        "EXPECTED_SHA256": probe.expected_sha256,
        "ACTUAL_SHA256": probe.actual_sha256,
        "checksum_reason": probe.reason,
        "checksum_source": probe.sha_url,
        "source": probe.rootfs_url,
    }


def rootfs_import_format_ok(path: Path) -> bool:
    """`wsl --import` takes a gzip-compressed tar rootfs."""
    try:
        return Path(path).read_bytes()[:2] == GZIP_MAGIC
    except OSError:
        return False


def parse_wsl_list(text: str) -> list[dict[str, str]]:
    """Parse `wsl.exe -l -v` text. UTF-16 leftovers are tolerated."""
    cleaned = text.replace("\x00", "")
    rows: list[dict[str, str]] = []
    for line in cleaned.splitlines():
        line = line.strip()
        if not line or line.lower().startswith("name") or line.lower().startswith("windows subsystem"):
            continue
        default = line.startswith("*")
        parts = line.lstrip("* ").split()
        if len(parts) < 2:
            continue
        rows.append({
            "name": parts[0],
            "state": parts[1] if len(parts) > 1 else "Unknown",
            "version": parts[2] if len(parts) > 2 else "",
            "default": "1" if default else "0",
        })
    return rows


def parse_wsl_status(text: str) -> dict[str, str]:
    cleaned = text.replace("\x00", "")
    default_version = ""
    for line in cleaned.splitlines():
        if "default version" in line.lower() or "versión predeterminada" in line.lower():
            parts = line.replace(":", " ").split()
            for part in reversed(parts):
                if part.isdigit():
                    default_version = part
                    break
    return {"default_version": default_version}


def wsl2_supported(rows: list[dict[str, str]], status: dict[str, str]) -> bool:
    if status.get("default_version") == "2":
        return True
    return any(r.get("version") == "2" for r in rows)


def wsl2_verified(
    rows: list[dict[str, str]],
    status: dict[str, str],
    *,
    distro: str = DISTRO,
    exec_ok: bool | None = None,
) -> bool:
    """True only when the managed Citizen distro itself is WSL2."""
    ours = next((r for r in rows if r.get("name") == distro), None)
    if ours is None:
        return False
    if str(ours.get("version")) != "2":
        return False
    if exec_ok is False:
        return False
    return True


def python_meets_minimum(version_text: str, minimum: tuple[int, int] = MIN_PYTHON) -> bool:
    nums = [int(p) for p in version_text.replace(",", " ").replace("(", " ").replace(")", " ").split() if p.isdigit()]
    if len(nums) < 2:
        return False
    return tuple(nums[:2]) >= minimum


def classify_home(home: Path) -> str:
    """Recognize a sealed Citizen. Unknown/legacy folders are not migrated."""
    home = Path(home)
    text = str(home).replace("\\", "/")
    if any(hint.replace("\\", "/") in text for hint in LEGACY_HINTS):
        return "UNKNOWN_LEGACY_INSTALLATION"
    if not home.exists():
        return "ABSENT"
    sealed = (home / "identity" / "SEALED").is_file()
    ident = home / "identity" / "identity.json"
    if sealed and ident.is_file():
        try:
            cid = json.loads(ident.read_text(encoding="utf-8")).get("citizen_id", "")
        except Exception:
            cid = ""
        if str(cid).startswith("cit_"):
            return "KNOWN_CITIZEN"
    if any(home.joinpath(p).exists() for p in ("CitizenSetup.py", "nuclear_clean")):
        return "UNKNOWN_LEGACY_INSTALLATION"
    if list(home.iterdir()):
        return "UNKNOWN"
    return "ABSENT"


def parse_netstat_pids(text: str, port: int) -> list[int]:
    pids: list[int] = []
    for line in text.splitlines():
        if f":{port}" not in line:
            continue
        parts = line.split()
        if parts and parts[-1].isdigit():
            pid = int(parts[-1])
            if pid > 0:
                pids.append(pid)
    return pids


def looks_like_reboot(result: HostResult) -> bool:
    if result.details.get("returncode") in (3010, 1641):
        return True
    blob = f"{result.message} {result.details.get('stdout', '')} {result.details.get('stderr', '')}".lower()
    return any(marker in blob for marker in REBOOT_MARKERS)


def looks_like_elevation(result: HostResult) -> bool:
    if result.details.get("returncode") in (5, 740):
        return True
    blob = f"{result.message} {result.details.get('stdout', '')} {result.details.get('stderr', '')}".lower()
    return any(marker in blob for marker in ELEVATION_MARKERS)


def guest_bootstrap_script() -> str:
    """Guest-side host prep only. Birth stays `citizen install`."""
    return (Path(__file__).resolve().parents[1] / "windows" / "guest_bootstrap.sh").read_text(
        encoding="utf-8"
    )


def bootstrap_script_path() -> Path:
    return Path(__file__).resolve().parents[1] / "windows" / "Install-Citizen.ps1"


class WindowsHostAdapter:
    """WSL2 host. Does not own Citizen Birth/Work/Sync."""

    def __init__(
        self,
        *,
        data_dir: Path,
        home: Path,
        host: str | None = None,
        port: str | int | None = None,
        runner=None,
        state_path: Path | None = None,
        distro: str = DISTRO,
        rootfs_path: Path | None = None,
        fetcher=None,
        backend=None,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.home = Path(home)
        self.host = host or os.environ.get("CITIZEN_UI_HOST", "127.0.0.1")
        self.port = str(port or os.environ.get("CITIZEN_UI_PORT", "3434"))
        self.distro = distro
        self._run = runner or _run
        self._fetcher = fetcher
        self.backend = backend
        if self.backend is None and os.name == "nt":
            from .isolation.wsl_podman import WslPodmanIsolationBackend

            self.backend = WslPodmanIsolationBackend(
                distro=self.distro,
                volume=windows_path_to_wsl(self.home),
                host=self.host,
                port=self.port,
                run=self._run,
                image=PUBLIC_IMAGE_REF,
            )
        self.state_path = Path(state_path) if state_path is not None else _default_state_path()
        self.rootfs_path = Path(rootfs_path) if rootfs_path is not None else (
            self.state_path.parent / ROOTFS_NAME
        )
        self._verify_diag: dict = {}

    def volume(self) -> dict[str, str]:
        return {
            "host_state": str(self.state_path),
            "host_volume": str(self.home),
            "wsl_distribution": self.distro,
            "guest_data": windows_path_to_wsl(self.home),
            "guest_home": windows_path_to_wsl(self.home),
            "image": PUBLIC_IMAGE_REF,
        }

    def network(self) -> dict[str, str]:
        return {
            "host": self.host,
            "port": self.port,
            "ui": f"http://{self.host}:{self.port}/",
        }

    def provision(self) -> HostResult:
        detect = self.detect()
        if detect.state == PHASE_PENDING_REBOOT:
            return detect
        if detect.state == PHASE_WSL1:
            upgraded = self._upgrade_managed_to_wsl2()
            if not upgraded.ok:
                return upgraded
            detect = self.detect()
        if not detect.ok:
            enabled = self.enable_wsl()
            if not enabled.ok:
                return enabled
            detect = self.detect()
            if detect.state in (PHASE_PENDING_REBOOT, PHASE_ENABLE_REQUESTED) or not detect.ok:
                return detect if detect.state in (PHASE_PENDING_REBOOT, PHASE_ENABLE_REQUESTED) else enabled
        conflict = self._port_conflict()
        if conflict is not None:
            return conflict
        self._set_phase(PHASE_DISTRO_PROVISIONING, wsl2=False)
        distro = self.ensure_distro(detect.details.get("distributions") or [])
        if not distro.ok:
            return distro
        user = self.ensure_guest_user()
        if not user.ok:
            return user
        self._set_phase(PHASE_RUNTIME_PROVISIONING, wsl2=True)
        runtime = self.ensure_runtime()
        if not runtime.ok:
            return runtime
        verified = self.detect()
        if not verified.details.get("wsl2"):
            return self._fail("WSL2 was not verified for the managed Citizen distro. No Citizen was born.")
        self._set_phase(PHASE_WSL_READY, wsl2=True)
        return HostResult(True, "PROVISIONED", "Windows WSL2 host prepared", {
            **self.volume(),
            **self.network(),
            "image": PUBLIC_IMAGE_REF,
            "wsl2": True,
            "untouched_distros": [
                r.get("name") for r in (detect.details.get("distributions") or [])
                if r.get("name") and r.get("name") != self.distro
            ],
        })

    def guest_install(self) -> HostResult:
        """Host prep, then Linux `citizen install` inside WSL2. Never a Windows runtime."""
        host_kind = classify_home(self.home)
        if host_kind == "UNKNOWN_LEGACY_INSTALLATION":
            return HostResult(False, "UNKNOWN_LEGACY_INSTALLATION", (
                "An unrecognized legacy Citizen-like install was found. "
                "It was not migrated or overwritten."
            ))
        kind = self.classify_guest_home()
        if kind == "UNKNOWN_LEGACY_INSTALLATION":
            return HostResult(False, "UNKNOWN_LEGACY_INSTALLATION", (
                "An unrecognized legacy Citizen-like install was found. "
                "It was not migrated or overwritten."
            ))
        if kind == "UNKNOWN":
            return HostResult(False, "UNKNOWN", "Guest home is not a known Citizen. Not touched.")
        prov = self.provision()
        if not prov.ok:
            return prov
        self._set_phase(PHASE_CITIZEN_BIRTH, wsl2=True)
        started = self._guest(["install"])
        if not started.ok:
            return started
        health = self.wait_health()
        details = {
            **self.network(),
            "install": started.details.get("stdout", ""),
            "existing": kind == "KNOWN_CITIZEN",
        }
        self._set_phase(PHASE_READY, wsl2=True)
        if health.ok:
            return HostResult(True, "READY", "Citizen READY", details)
        return HostResult(True, "INSTALLED", started.message or "Citizen installed", details)

    def start(self) -> HostResult:
        conflict = self._port_conflict()
        if conflict is not None:
            return conflict
        if self.health().ok:
            return HostResult(True, "READY", "Already healthy", self.network())
        if self.backend is not None:
            started = self.backend.start()
            if not started.ok:
                return started
            return HostResult(True, "STARTED", "Host environment started", {
                **self.network(),
                **(started.details or {}),
            })
        wsl = self.wsl_start()
        if not wsl.ok:
            return wsl
        return self._guest(["start"])

    def stop(self) -> HostResult:
        if self.backend is not None:
            return self.backend.stop()
        return self._guest(["stop"])

    def apply_class_package(
        self,
        envelope: dict | None = None,
        *,
        envelope_path=None,
        living_apply=None,
        linux_applier=None,
    ) -> HostResult:
        """Same CLASS_PACKAGE semantics as Linux. WSL2 consumes the same OCI digest.

        Does not mint identity. Does not modify Windows bootstrap pins.
        """
        from .runtime_evolution import apply_windows_class_package

        return apply_windows_class_package(
            adapter=self,
            envelope=envelope,
            envelope_path=envelope_path,
            living_apply=living_apply,
            linux_applier=linux_applier,
        )

    def restart(self) -> HostResult:
        conflict = self._port_conflict()
        if conflict is not None:
            return conflict
        wsl = self.wsl_restart()
        if not wsl.ok:
            return wsl
        return self._guest(["restart"])

    def status(self) -> HostResult:
        wsl = self.wsl_health()
        return HostResult(True, wsl.state, "Host status", {
            "wsl": wsl.state,
            "service": wsl.details.get("service", wsl.state),
            **self.volume(),
            **self.network(),
        })

    def health(self) -> HostResult:
        url = f"http://{self.host}:{self.port}/api/living"
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                if resp.status == 200:
                    return HostResult(True, "READY", "Living API reachable", {"url": url})
        except Exception:
            pass
        return HostResult(False, "FAILED", "Living API not reachable", {"url": url})

    def wait_health(self, attempts: int | None = None, delay: float | None = None) -> HostResult:
        if attempts is None:
            attempts = int(os.environ.get("CITIZEN_HOST_HEALTH_ATTEMPTS", "10"))
        if delay is None:
            delay = float(os.environ.get("CITIZEN_HOST_HEALTH_DELAY", "1.0"))
        last = self.health()
        for _ in range(max(attempts, 1)):
            last = self.health()
            if last.ok:
                return last
            time.sleep(delay)
        return last

    def logs(self) -> HostResult:
        return self._guest(["logs"])

    def disable(self) -> HostResult:
        self._guest(["stop"])
        return HostResult(True, "REMOVED", "Windows host left WSL distro in place", self.volume())

    def detect(self) -> HostResult:
        listed = self._run(["wsl.exe", "-l", "-v"], check=False)
        if self._wsl_missing(listed):
            self._set_phase(PHASE_MISSING, wsl2=False)
            return HostResult(False, PHASE_MISSING, (
                "wsl.exe is not available. The host can enable WSL2; Windows may require "
                "UAC or a reboot. No Citizen was born."
            ), {"phase": PHASE_MISSING, "wsl_available": False, "wsl2": False, "wsl2_supported": False})
        if not listed.ok and looks_like_reboot(listed):
            return self._pending_reboot(
                "WSL2 is installed but Windows requires a reboot before it is operational. "
                "The same bootstrap will resume after reboot. No Citizen was born."
            )
        rows = parse_wsl_list((listed.details.get("stdout") or "") + (listed.details.get("stderr") or ""))
        status_run = self._run(["wsl.exe", "--status"], check=False)
        if not status_run.ok and looks_like_reboot(status_run):
            return self._pending_reboot(
                "WSL2 is installed but Windows requires a reboot before it is operational. "
                "The same bootstrap will resume after reboot. No Citizen was born."
            )
        status = parse_wsl_status(status_run.details.get("stdout") or "")
        ours = next((r for r in rows if r["name"] == self.distro), None)
        supported = wsl2_supported(rows, status)
        exec_ok = None
        if ours is not None and str(ours.get("version")) == "2":
            exec_ok = self._distro_exec_ok()
        citizen_wsl2 = wsl2_verified(rows, status, distro=self.distro, exec_ok=exec_ok)
        details = {
            "distributions": rows,
            "ours": ours or {},
            "wsl_available": True,
            "wsl2": citizen_wsl2,
            "wsl2_supported": supported,
            "unrelated": [r["name"] for r in rows if r["name"] != self.distro],
            "default_version": status.get("default_version", ""),
        }
        if ours is not None and str(ours.get("version")) == "1":
            self._set_phase(PHASE_WSL1, wsl2=False)
            return HostResult(False, PHASE_WSL1, (
                f"{self.distro} exists as WSL1 and is not treated as WSL2. "
                "An in-place upgrade will be attempted. Other distros were not changed. "
                "No Citizen was born."
            ), details)
        if not supported:
            return HostResult(False, "UNAVAILABLE", "WSL is present but WSL2 was not verified.", details)
        if ours is None:
            self._set_phase(PHASE_DISTRO_PROVISIONING, wsl2=False)
            return HostResult(True, PHASE_DISTRO_PROVISIONING, "WSL2 supported; Citizen distro missing", details)
        if not citizen_wsl2:
            return HostResult(False, "UNAVAILABLE", (
                f"{self.distro} exists but was not verified as WSL2 (version 2 + executable)."
            ), details)
        return HostResult(True, WSL_DISTRIBUTION, "WSL2 verified for CONRRAD-Citizen", details)

    def enable_wsl(self) -> HostResult:
        probe = self._run(["wsl.exe", "-l", "-v"], check=False)
        if self._wsl_missing(probe):
            for feature in ("Microsoft-Windows-Subsystem-Linux", "VirtualMachinePlatform"):
                r = self._run([
                    "dism.exe", "/online", "/enable-feature",
                    f"/featurename:{feature}", "/all", "/norestart",
                ], check=False)
                if looks_like_elevation(r):
                    return self.request_elevation()
                if not r.ok and not looks_like_reboot(r):
                    return self._pending_reboot(
                        "Windows features for WSL2 were requested. Reboot, then the same "
                        "bootstrap resumes. No Citizen was born."
                    )
            return self._pending_reboot(
                "WSL2 Windows features were enabled. Reboot, then the same bootstrap resumes. "
                "No Citizen was born."
            )
        installed = self._run(["wsl.exe", "--install", "--no-distribution"], check=False)
        if looks_like_elevation(installed):
            return self.request_elevation()
        self._run(["wsl.exe", "--set-default-version", "2"], check=False)
        if looks_like_reboot(installed) or (not installed.ok and self._wsl_missing(installed)):
            return self._pending_reboot(
                "WSL2 enablement requires a Windows reboot. After reboot, the same bootstrap "
                "resumes. No Citizen was born."
            )
        if not installed.ok:
            return self._fail(installed.message or "wsl --install failed")
        return HostResult(True, "WSL_ENABLED", "WSL install requested", installed.details)

    def request_elevation(self) -> HostResult:
        """Relaunch the same bootstrap elevated. Do not ask for a second command."""
        self._set_phase(PHASE_ENABLE_REQUESTED, wsl2=False)
        script = bootstrap_script_path()
        cmd = [
            "powershell.exe", "-NoProfile", "-Command",
            "Start-Process -FilePath 'powershell.exe' -Verb RunAs -Wait "
            f"-ArgumentList '-NoProfile -ExecutionPolicy Bypass -File \"{script}\"'",
        ]
        r = self._run(cmd, check=False)
        phase = self.load_state().get("phase", PHASE_ENABLE_REQUESTED)
        details = {"phase": phase, "wsl2": False, "cmd": r.details.get("cmd")}
        if not r.ok:
            return HostResult(False, PHASE_ENABLE_REQUESTED, (
                "WSL2 enablement requires Administrator / UAC approval. "
                "The bootstrap requested elevation. No Citizen was born."
            ), details)
        if phase == PHASE_PENDING_REBOOT:
            return HostResult(False, PHASE_PENDING_REBOOT, (
                "WSL2 enablement requires a reboot. The same bootstrap will resume. "
                "No Citizen was born."
            ), details)
        return HostResult(False, PHASE_ENABLE_REQUESTED, (
            "The bootstrap relaunched itself elevated. No Citizen was born before WSL2 is ready."
        ), details)

    def ensure_distro(self, rows: list[dict[str, str]] | None = None) -> HostResult:
        if rows is None:
            listed = self._run(["wsl.exe", "-l", "-v"], check=False)
            rows = parse_wsl_list(listed.details.get("stdout") or "")
        names = [r.get("name") for r in rows]
        ours = next((r for r in rows if r.get("name") == self.distro), None)
        untouched = [n for n in names if n and n != self.distro]
        if ours is not None and str(ours.get("version")) == "1":
            return self._upgrade_managed_to_wsl2(untouched=untouched)
        if ours is not None and str(ours.get("version")) == "2":
            return HostResult(True, WSL_DISTRIBUTION, "Citizen distro present", {
                "distro": self.distro,
                "untouched": untouched,
            })
        rootfs = self._ensure_rootfs()
        if not rootfs.ok:
            return rootfs
        dest = self.state_path.parent / "distro"
        dest.mkdir(parents=True, exist_ok=True)
        imported = self._run([
            "wsl.exe", "--import", self.distro, str(dest), str(self.rootfs_path), "--version", "2",
        ], check=False)
        if not imported.ok:
            return HostResult(False, PHASE_DISTRO_PROVISIONING, (
                f"Citizen distro {self.distro} is missing and could not be imported. "
                f"Verified rootfs: {self.rootfs_path}. Other WSL distributions were not changed."
            ), {"untouched": untouched, "rootfs": str(self.rootfs_path)})
        return HostResult(True, WSL_DISTRIBUTION, "Citizen distro provisioned", {
            "distro": self.distro,
            "untouched": untouched,
            **{k: v for k, v in (rootfs.details or {}).items() if k not in ("bytes", "text")},
        })

    def ensure_guest_user(self) -> HostResult:
        r = self._guest_raw(
            "id -u citizen >/dev/null 2>&1 || useradd -m -s /bin/bash citizen; "
            f"mkdir -p {GUEST_HOME} {GUEST_DATA}/artifact; "
            "chown -R citizen:citizen /home/citizen; "
            f"printf '{DISTRO}\\n' > {MANAGED_MARKER}; "
            "grep -q 'CONRRAD-managed' /etc/wsl.conf 2>/dev/null || "
            "printf '\\n# CONRRAD-managed=CONRRAD-Citizen\\n[user]\\ndefault=citizen\\n' >> /etc/wsl.conf"
        )
        if not r.ok:
            return HostResult(False, PHASE_FAILED, "Could not prepare the managed citizen user.", r.details)
        return HostResult(True, "GUEST_USER", "Managed citizen user ready", {
            "guest_data": GUEST_DATA,
            "guest_home": GUEST_HOME,
            "managed_marker": MANAGED_MARKER,
        })

    def ensure_python(self) -> HostResult:
        r = self._guest_raw(
            "python3 -c 'import sys; print(sys.version_info[0], sys.version_info[1])' "
            "|| python3.11 -c 'import sys; print(sys.version_info[0], sys.version_info[1])'"
        )
        text = (r.details.get("stdout") or "").strip()
        if r.ok and python_meets_minimum(text):
            return HostResult(True, "PYTHON_OK", text, {"version": text})
        install = self._guest_raw(
            "export DEBIAN_FRONTEND=noninteractive; "
            "apt-get update -y && apt-get install -y python3.11 python3.11-venv python3-pip curl ca-certificates && "
            "python3.11 -c 'import sys; print(sys.version_info[0], sys.version_info[1])'"
        )
        text = (install.details.get("stdout") or "").strip()
        if install.ok and python_meets_minimum(text):
            return HostResult(True, "PYTHON_OK", text, {"version": text, "provisioned": True})
        return HostResult(False, PHASE_FAILED, "Guest Python >= 3.11 is required and was not available.", {
            "version": text,
        })

    def ensure_runtime(self) -> HostResult:
        """Isolation packages inside WSL. Never pip, never a Windows Python runtime."""
        present = self._guest_raw("command -v podman >/dev/null && echo PRESENT || echo ABSENT")
        if "PRESENT" in (present.details.get("stdout") or ""):
            return HostResult(True, "RUNTIME", "Managed isolation present", {
                "image": PUBLIC_IMAGE_REF,
                "image_digest": PUBLIC_IMAGE_DIGEST,
                "engine": "podman",
            })
        installed = self._guest_raw(
            "export DEBIAN_FRONTEND=noninteractive; "
            "apt-get update -y && apt-get install -y --no-install-recommends "
            "podman uidmap slirp4netns passt fuse-overlayfs crun curl ca-certificates python3 && "
            "command -v podman >/dev/null && echo PROVISIONED"
        )
        if "PROVISIONED" not in (installed.details.get("stdout") or "") and not installed.ok:
            return HostResult(False, PHASE_FAILED, "Managed isolation could not be prepared in the guest.", {
                **installed.details,
                "image": PUBLIC_IMAGE_REF,
            })
        if "PROVISIONED" not in (installed.details.get("stdout") or "") and "PRESENT" not in (installed.details.get("stdout") or ""):
            if not installed.ok:
                return HostResult(False, PHASE_FAILED, "Managed isolation could not be prepared in the guest.", {
                    **installed.details,
                    "image": PUBLIC_IMAGE_REF,
                })
        return HostResult(True, "RUNTIME", "Managed isolation ready", {
            "image": PUBLIC_IMAGE_REF,
            "image_digest": PUBLIC_IMAGE_DIGEST,
            "engine": "podman",
        })

    def classify_guest_home(self) -> str:
        vol = windows_path_to_wsl(self.home)
        ident = self._guest_raw(f"cat {vol}/identity/identity.json 2>/dev/null || true")
        sealed = self._guest_raw(f"test -f {vol}/identity/SEALED && echo SEALED || true")
        raw = (ident.details.get("stdout") or "").strip()
        if "SEALED" in (sealed.details.get("stdout") or "") and raw:
            try:
                cid = json.loads(raw).get("citizen_id", "")
            except Exception:
                cid = ""
            if str(cid).startswith("cit_"):
                return "KNOWN_CITIZEN"
        if raw:
            return "UNKNOWN"
        return "ABSENT"

    def wsl_start(self) -> HostResult:
        r = self._run(["wsl.exe", "-d", self.distro, "--exec", "/bin/true"], check=False)
        if "returncode" not in (r.details or {}) and not r.ok:
            return HostResult(False, WSL_START, r.message, r.details)
        probe = ProbeResult(
            "bin_true",
            int(r.details.get("returncode") or 0),
            r.details.get("stdout") or "",
            r.details.get("stderr") or r.message or "",
        )
        if bin_true_is_fatal(probe):
            return HostResult(False, WSL_START, r.message or "managed distro cannot execute", r.details)
        return HostResult(True, WSL_START, "WSL distribution started", {"distro": self.distro})

    def wsl_stop(self) -> HostResult:
        r = self._run(["wsl.exe", "-t", self.distro], check=False)
        if not r.ok:
            return HostResult(False, WSL_STOP, r.message, r.details)
        return HostResult(True, WSL_STOP, "WSL distribution stopped", {"distro": self.distro})

    def wsl_restart(self) -> HostResult:
        stopped = self.wsl_stop()
        if not stopped.ok:
            return stopped
        return self.wsl_start()

    def wsl_health(self) -> HostResult:
        listed = self._run(["wsl.exe", "-l", "-v"], check=False)
        rows = parse_wsl_list(listed.details.get("stdout") or "")
        ours = next((r for r in rows if r["name"] == self.distro), None)
        state = (ours or {}).get("state") or "Unknown"
        return HostResult(True, WSL_HEALTH, state, {
            "service": state,
            "distro": self.distro,
            "citizen_state": "unknown",
        })

    def _port_conflict(self) -> HostResult | None:
        r = self._run(["netstat", "-ano"], check=False)
        pids = parse_netstat_pids(r.details.get("stdout") or "", int(self.port))
        if not pids:
            return None
        if self.health().ok:
            return None
        pid = pids[0]
        return HostResult(
            False,
            USER_ACTION_REQUIRED,
            f"Port {self.port} is in use by process {pid}, which is not this Citizen. "
            "Free the port or set CITIZEN_UI_PORT. The process was not stopped.",
            {"pid": pid, "port": self.port},
        )

    def _guest(self, args: list[str]) -> HostResult:
        verb = args[0] if args else ""
        if verb == "install":
            return self._run_public_linux_install()
        env_name = "conrrad-citizen"
        mapping = {
            "start": f"podman start {env_name}",
            "stop": f"podman stop {env_name}",
            "restart": f"podman restart {env_name}",
            "logs": f"podman logs --tail 200 {env_name}",
        }
        shell = mapping.get(verb)
        if not shell:
            return HostResult(False, "FAILED", f"unknown host operation {verb}")
        return self._guest_raw(shell, user="citizen")

    def _run_public_linux_install(self) -> HostResult:
        vol = windows_path_to_wsl(self.home)
        shell = (
            f"export CITIZEN_HOME='{vol}' CITIZEN_DATA_DIR='{vol}' "
            f"CITIZEN_IMAGE='{PUBLIC_IMAGE_REF}' CITIZEN_OPEN_BROWSER=0 "
            f"CITIZEN_LINUX_INSTALL_URL='{PUBLIC_LINUX_INSTALL_URL}'; "
            "curl -fsSL \"$CITIZEN_LINUX_INSTALL_URL\" | bash"
        )
        return self._guest_raw(shell)

    def _guest_raw(self, shell: str, *, user: str | None = None) -> HostResult:
        cmd = ["wsl.exe", "-d", self.distro]
        if user:
            cmd.extend(["-u", user])
        cmd.extend(["--exec", "/bin/bash", "-lc", shell])
        return self._run(cmd, check=False)

    def _distro_exec_ok(self) -> bool:
        r = self._run(["wsl.exe", "-d", self.distro, "--exec", "/bin/true"], check=False)
        if "returncode" not in (r.details or {}) and not r.ok:
            return False
        probe = ProbeResult(
            "bin_true",
            int(r.details.get("returncode") or 0),
            r.details.get("stdout") or "",
            r.details.get("stderr") or r.message or "",
        )
        return not bin_true_is_fatal(probe)

    def _wsl_missing(self, result: HostResult) -> bool:
        blob = f"{result.message} {result.details.get('cmd', '')}".lower()
        return "no such file" in blob or ("not found" in blob and "wsl" in blob)

    def _upgrade_managed_to_wsl2(self, untouched: list[str] | None = None) -> HostResult:
        r = self._run(["wsl.exe", "--set-version", self.distro, "2"], check=False)
        if looks_like_reboot(r):
            return self._pending_reboot(
                f"{self.distro} WSL1→WSL2 conversion needs a reboot. The same bootstrap resumes. "
                "No Citizen was born."
            )
        if r.ok:
            listed = self._run(["wsl.exe", "-l", "-v"], check=False)
            rows = parse_wsl_list(listed.details.get("stdout") or "")
            if wsl2_verified(rows, {}, distro=self.distro):
                return HostResult(True, WSL_DISTRIBUTION, "Managed distro upgraded to WSL2 in place", {
                    "distro": self.distro,
                    "untouched": untouched or [],
                })
        return HostResult(False, "MANAGED_REPROVISION_REQUIRED", (
            f"{self.distro} is WSL1 and could not be upgraded in place. "
            "It was not unregistered. Identity was not deleted. "
            "Other WSL distributions were not changed."
        ), {"distro": self.distro, "untouched": untouched or [], "wsl2": False})

    def _pending_reboot(self, message: str) -> HostResult:
        text = REBOOT_USER_MESSAGE
        if message and message not in text:
            text = f"{REBOOT_USER_MESSAGE}\n{message}"
        self._set_phase(PHASE_PENDING_REBOOT, wsl2=False)
        self._register_resume()
        return HostResult(False, PHASE_PENDING_REBOOT, text, {
            "phase": PHASE_PENDING_REBOOT,
            "wsl2": False,
        })

    def _fail(self, message: str, extra: dict | None = None) -> HostResult:
        details = {"phase": PHASE_FAILED, "wsl2": False}
        if extra:
            details.update({
                k: v for k, v in extra.items()
                if k not in ("citizen_id", "identity", "evidence", "history")
            })
        self._set_phase(PHASE_FAILED, wsl2=False)
        return HostResult(False, PHASE_FAILED, message, details)

    def _register_resume(self) -> None:
        script = bootstrap_script_path()
        cmd = f'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "{script}"'
        self._run([
            "schtasks.exe", "/Create", "/TN", "CONRRAD Citizen Host Resume",
            "/TR", cmd, "/SC", "ONLOGON", "/RL", "HIGHEST", "/F",
        ], check=False)
        self._run([
            "reg.exe", "add",
            r"HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce",
            "/v", "CONRRADCitizenHost", "/t", "REG_SZ", "/d", cmd, "/f",
        ], check=False)

    def _persist_diag(self) -> None:
        payload = self.load_state()
        payload.update(self._verify_diag)
        payload.setdefault("distro", self.distro)
        payload.setdefault("phase", PHASE_DISTRO_PROVISIONING)
        payload["BOOTSTRAP_PHASE"] = payload.get("phase")
        self._write_state(payload)

    def _ensure_rootfs(self) -> HostResult:
        def fetch(url: str) -> HttpFetch:
            result = self._download_http(url)
            details = result.details or {}
            return HttpFetch(
                data=details.get("bytes") or b"",
                status=int(details.get("SHA_HTTP_STATUS") or (200 if result.ok else 0)),
                content_type=str(details.get("SHA_CONTENT_TYPE") or ("text/plain" if result.ok else "")),
                final_url=str(details.get("SHA_FINAL_URL") or url),
                url=str(details.get("url") or url),
                error="" if result.ok else (result.message or "fetch_failed"),
            )

        probe = retrieve_official_checksum(fetch)
        self._verify_diag = probe_diag_fields(probe)
        if not probe.checksum_source_found or not probe.expected_sha256:
            return self._fail(ROOTFS_VERIFY_FAILED, extra=probe_diag_fields(probe))
        if not checksum_source_matches_rootfs(probe.sha_url, probe.rootfs_url, ROOTFS_NAME):
            mismatch = probe_diag_fields(probe)
            mismatch["checksum_reason"] = "filename_checksum_source_mismatch"
            return self._fail(ROOTFS_VERIFY_FAILED, extra=mismatch)
        expected = probe.expected_sha256
        gpg = self._download_http(probe.gpg_url)
        if gpg.ok and gpg.details.get("bytes"):
            verified = self._verify_sums_gpg(fetch(probe.sha_url).data, gpg.details["bytes"])
            if verified is False:
                return self._fail(
                    "Ubuntu SHA256SUMS.gpg signature validation failed. Rootfs was not imported.",
                    extra=probe_diag_fields(probe),
                )
        if self.rootfs_path.is_file():
            digest = hashlib.sha256(self.rootfs_path.read_bytes()).hexdigest()
            probe.actual_sha256 = digest
            self._verify_diag = probe_diag_fields(probe)
            if digest == expected and rootfs_import_format_ok(self.rootfs_path):
                self._persist_diag()
                return HostResult(True, "ROOTFS", "Cached rootfs verified against official SHA256SUMS", {
                    "path": str(self.rootfs_path),
                    "sha256": digest,
                    **probe_diag_fields(probe),
                })
            try:
                self.rootfs_path.unlink()
            except OSError:
                pass
        self.rootfs_path.parent.mkdir(parents=True, exist_ok=True)
        downloaded = self._download_http(probe.rootfs_url, dest=self.rootfs_path)
        if not downloaded.ok:
            return self._fail(
                ROOTFS_VERIFY_FAILED,
                extra={**probe_diag_fields(probe), "source": probe.rootfs_url},
            )
        digest = hashlib.sha256(self.rootfs_path.read_bytes()).hexdigest()
        probe.actual_sha256 = digest
        self._verify_diag = probe_diag_fields(probe)
        if digest != expected:
            try:
                self.rootfs_path.unlink()
            except OSError:
                pass
            return self._fail(
                "Ubuntu rootfs SHA256 did not match official SHA256SUMS. File was discarded. "
                "Rootfs was not imported.",
                extra=probe_diag_fields(probe),
            )
        if not rootfs_import_format_ok(self.rootfs_path):
            try:
                self.rootfs_path.unlink()
            except OSError:
                pass
            return self._fail(
                "Rootfs is not a gzip tar image required by wsl --import. File was discarded.",
                extra=probe_diag_fields(probe),
            )
        self._persist_diag()
        return HostResult(True, "ROOTFS", "Rootfs verified against official SHA256SUMS", {
            "path": str(self.rootfs_path),
            "sha256": digest,
            **probe_diag_fields(probe),
        })

    def _verify_sums_gpg(self, sums: bytes, sig: bytes) -> bool | None:
        """True if gpg confirmed the sums; False if gpg rejected; None if gpg absent."""
        gpg = self._run(["gpg.exe", "--version"], check=False)
        if not gpg.ok:
            gpg = self._run(["gpg", "--version"], check=False)
        if not gpg.ok:
            return None
        sums_path = self.state_path.parent / "SHA256SUMS"
        sig_path = self.state_path.parent / "SHA256SUMS.gpg"
        sums_path.write_bytes(sums)
        sig_path.write_bytes(sig)
        check = self._run(["gpg", "--verify", str(sig_path), str(sums_path)], check=False)
        if not check.ok:
            check = self._run(["gpg.exe", "--verify", str(sig_path), str(sums_path)], check=False)
        blob = f"{check.message} {check.details.get('stdout', '')} {check.details.get('stderr', '')}".lower()
        if "good signature" in blob:
            return True
        if check.ok:
            return True
        return False

    def _download_text(self, url: str) -> HostResult:
        raw = self._download_http(url)
        if not raw.ok:
            return raw
        text = decode_checksum_bytes(raw.details.get("bytes") or b"")
        return HostResult(True, text, text, {**raw.details, "text": text})

    def _download_bytes(self, url: str, dest: Path | None = None) -> HostResult:
        return self._download_http(url, dest=dest)

    def _download_http(self, url: str, dest: Path | None = None) -> HostResult:
        try:
            if self._fetcher is not None:
                fetch = normalize_http_fetch(url, self._fetcher(url))
            else:
                with urllib.request.urlopen(url, timeout=120) as resp:
                    data = resp.read()
                    fetch = HttpFetch(
                        data=data,
                        status=int(getattr(resp, "status", 200) or 200),
                        content_type=str(resp.headers.get("Content-Type") or ""),
                        final_url=str(resp.geturl() or url),
                        url=url,
                    )
        except urllib.error.HTTPError as exc:
            body = b""
            try:
                body = exc.read() or b""
            except Exception:
                body = b""
            ctype = ""
            try:
                ctype = str(exc.headers.get("Content-Type") or "") if exc.headers else ""
            except Exception:
                ctype = ""
            return HostResult(False, PHASE_FAILED, str(exc), {
                "url": url,
                "bytes": body,
                "SHA_URL": url,
                "SHA_HTTP_STATUS": int(exc.code or 0),
                "SHA_FINAL_URL": url,
                "SHA_CONTENT_TYPE": ctype,
                "SHA_CONTENT_LENGTH": len(body),
            })
        except Exception as exc:
            return HostResult(False, PHASE_FAILED, str(exc), {
                "url": url,
                "bytes": b"",
                "SHA_URL": url,
                "SHA_HTTP_STATUS": 0,
                "SHA_FINAL_URL": url,
                "SHA_CONTENT_TYPE": "",
                "SHA_CONTENT_LENGTH": 0,
            })
        if dest is not None:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(fetch.data)
        return HostResult(True, "DOWNLOADED", "", {
            "url": url,
            "bytes": fetch.data,
            "SHA_URL": fetch.url or url,
            "SHA_HTTP_STATUS": fetch.status,
            "SHA_FINAL_URL": fetch.final_url or url,
            "SHA_CONTENT_TYPE": fetch.content_type,
            "SHA_CONTENT_LENGTH": len(fetch.data),
        })

    def _set_phase(self, phase: str, *, wsl2: bool) -> None:
        payload = {
            "phase": phase,
            "BOOTSTRAP_PHASE": phase,
            "distro": self.distro,
            "wsl2": bool(wsl2),
            **self._verify_diag,
        }
        payload["BOOTSTRAP_PHASE"] = phase
        payload["phase"] = phase
        self._write_state(payload)

    def _write_state(self, payload: dict) -> None:
        clean = {k: v for k, v in payload.items() if k not in ("citizen_id", "identity", "evidence", "history")}
        clean.setdefault("distro", self.distro)
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.write_text(json.dumps(clean, indent=2) + "\n", encoding="utf-8")

    def load_state(self) -> dict:
        if not self.state_path.is_file():
            return {}
        try:
            return json.loads(self.state_path.read_text(encoding="utf-8"))
        except Exception:
            return {}


def _default_state_path() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("XDG_STATE_HOME") or str(Path.home())
    return Path(base) / "CONRRAD" / "CitizenHost" / "bootstrap.json"


def _run(cmd: list[str], *, check: bool = True) -> HostResult:
    import subprocess
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True)
    except FileNotFoundError as e:
        return HostResult(False, "FAILED", str(e), {"cmd": cmd})
    details = {
        "cmd": cmd,
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }
    if check and proc.returncode != 0:
        return HostResult(False, "FAILED", (proc.stderr or proc.stdout or "command failed").strip(), details)
    return HostResult(True, "OK", "", details)
