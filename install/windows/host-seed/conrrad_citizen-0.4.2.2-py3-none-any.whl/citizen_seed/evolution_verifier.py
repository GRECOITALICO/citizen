"""Fail-closed verification for remote evolution descriptors."""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from typing import Any, Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .release_contract import ContractError

# MISSION-033: Formal Key Rollover and Trust Root Recovery
# In production, this would be injected via CD/CI build arguments or isolated config.
# Key format: spki_der_base64
_TRUSTED_KEYS_DB = {
    "mission-033-governed-key": "MCowBQYDK2VwAyEAVbFoA2dv4Uo33ni9lSPucP8ToNoIWNzD6f1KXIlgjcM="
}

# The following keys have been permanently rejected/retired and MUST NOT be trusted:
# - mission-023-governed-key (Private key lost)
# - mission-024-governed-key (Private key compromised)
# - mission-025-governed-key (Private key lost)

@dataclass(frozen=True)
class TrustRoot:
    key_id: str
    public_key: Ed25519PublicKey

def _get_trust_root(key_id: str) -> TrustRoot:
    b64_der = _TRUSTED_KEYS_DB.get(key_id)
    if not b64_der:
        raise ContractError(f"Unknown signing_key_id: {key_id}")
    try:
        der = base64.b64decode(b64_der, validate=True)
        public_key = serialization.load_der_public_key(der)
        if not isinstance(public_key, Ed25519PublicKey):
            raise ContractError("Trust root is not Ed25519")
        return TrustRoot(key_id=key_id, public_key=public_key)
    except Exception as exc:
        raise ContractError(f"Failed to load trust root {key_id}") from exc

def verify_descriptor_signature(envelope: Mapping[str, Any]) -> dict[str, Any]:
    """
    Verify the envelope's Ed25519 signature over the canonicalized descriptor.
    Returns the valid descriptor if successful, raises ContractError otherwise.
    """
    if "descriptor" not in envelope or "signature" not in envelope or "signing_key_id" not in envelope:
        raise ContractError("Envelope missing required descriptor, signature, or signing_key_id")
    
    descriptor = envelope["descriptor"]
    signature_b64 = envelope["signature"]
    key_id = envelope["signing_key_id"]
    
    trust_root = _get_trust_root(key_id)
    
    try:
        signature = base64.b64decode(signature_b64, validate=True)
    except Exception as exc:
        raise ContractError("Invalid base64 signature") from exc
        
    if len(signature) != 64:
        raise ContractError("Ed25519 signature must be 64 bytes")
        
    canon_desc = json.dumps(descriptor, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    
    try:
        trust_root.public_key.verify(signature, canon_desc)
    except InvalidSignature as exc:
        raise ContractError("Evolution descriptor signature is invalid") from exc
        
    return descriptor
