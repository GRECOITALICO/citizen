"""HIT — Semantic Protocol Translator (P0.10B.1).

Deterministic interface translation only. HIT does not govern, infer, or execute.
Lexical words such as interpret / explain / summarize / meaning are not Work.
A later milestone may add an interface LoRA; this file must remain model-blind.
"""
from __future__ import annotations

import re
import uuid

from .contracts import (
    HIT_CONTRACT_VERSION,
    INTERFACE_CONVERSATION,
    INTERFACE_FACT_QUERY,
    INTERFACE_WORK_REQUEST,
    OntologyRequest,
)
from . import session as hit_session

_FACT_RULES: tuple[tuple[str, str], ...] = (
    (r"versi[oó]n|\bversion\b", "version"),
    (r"\bready\b|est[aá]s listo|est[aá]s ready", "ready"),
    (r"capacid|\bcapabilities\b", "capabilities"),
    (r"citizen\s*id|\bidentid|\btu id\b|\bcu[aá]l es tu id\b", "citizen_id"),
    (r"qui[eé]n eres|who are you", "identity"),
    (r"cu[aá]ndo evolucion|\bwhen (did you )?evolv", "last_evolution"),
)

_CAPABILITY_IDS: tuple[tuple[str, str], ...] = (
    ("evidence.integrity_digest", "run_integrity_digest"),
    ("evidence.intent_proposal", "propose_intent"),
    ("evidence.history_digest", "run_history_digest"),
)

_EXPLICIT_WORK = re.compile(
    r"haz el work|run work|ejecuta(?:r)?(?:\s+el)?\s+trabajo|"
    r"realiza(?:r)? esta operaci[oó]n|ejecuta(?:r)? esta capacidad|"
    r"\bwork request\b",
    re.IGNORECASE,
)
_ACTION = re.compile(
    r"\b(ejecuta(?:r)?|run|corre|compute|calcula(?:r)?|realiza(?:r)?)\b",
    re.IGNORECASE,
)
_DIGEST_TARGET = re.compile(
    r"integrity\s+digest|digest de integridad|evidence\.integrity_digest",
    re.IGNORECASE,
)
_INTENT_TARGET = re.compile(
    r"intent.?proposal|propuesta de intenci[oó]n|evidence\.intent_proposal",
    re.IGNORECASE,
)
_CONVERSATION_MODEL = re.compile(
    r"expl[ií]c|explain|contin[uú]a|\bcontinue\b|opin|qu[eé] opin|"
    r"por qu[eé]|\bwhy\b|resume lo|summarize|significa|meaning|"
    r"h[aá]blame|what do you think|qu[eé] significa",
    re.IGNORECASE,
)


def translate(
    text: str,
    *,
    session_id: str = "",
    source: str = "text",
) -> OntologyRequest:
    raw = text if isinstance(text, str) else ""
    stripped = raw.strip()
    prior = hit_session.remember_user_turn(session_id, stripped)
    request_id = f"hit_{uuid.uuid4().hex[:12]}"
    source_interface = (source or "text").strip() or "text"

    if not stripped:
        return _ontology(
            request_id,
            INTERFACE_CONVERSATION,
            normalized_intent="empty",
            subject="",
            action="none",
            prior=prior,
            source_interface=source_interface,
            ambiguity="EMPTY_TEXT",
        )

    work_cap, work_action = _match_work(stripped)
    if work_cap or work_action:
        return _ontology(
            request_id,
            INTERFACE_WORK_REQUEST,
            normalized_intent=work_action or "explicit_work",
            subject=stripped[:240],
            action=work_action or "explicit_work",
            prior=prior,
            source_interface=source_interface,
            capability=work_cap,
            entities=_entities(stripped),
        )

    fact = _match_fact(stripped)
    if fact:
        return _ontology(
            request_id,
            INTERFACE_FACT_QUERY,
            normalized_intent=fact,
            subject=fact,
            action="query_runtime_fact",
            prior=prior,
            source_interface=source_interface,
        )

    return _ontology(
        request_id,
        INTERFACE_CONVERSATION,
        normalized_intent="conversation",
        subject=stripped[:240],
        action="talk",
        prior=prior,
        source_interface=source_interface,
        entities=_entities(stripped),
        conversation_inference_required=_needs_conversation_model(stripped),
    )


def _ontology(
    request_id: str,
    kind: str,
    *,
    normalized_intent: str,
    subject: str,
    action: str,
    prior: tuple[str, ...],
    source_interface: str,
    capability: str | None = None,
    entities: tuple[str, ...] = (),
    ambiguity: str | None = None,
    conversation_inference_required: bool = False,
) -> OntologyRequest:
    return OntologyRequest(
        request_id=request_id,
        request_type=kind,
        normalized_intent=normalized_intent,
        subject=subject,
        entities=entities,
        constraints=(),
        explicit_user_action=action,
        conversational_context=prior,
        requested_capability=capability,
        ambiguity=ambiguity,
        source_interface=source_interface,
        conversation_inference_required=conversation_inference_required,
    )


def _match_fact(text: str) -> str | None:
    for pattern, name in _FACT_RULES:
        if re.search(pattern, text, re.IGNORECASE):
            return name
    return None


def _match_work(text: str) -> tuple[str | None, str]:
    for cap_id, action in _CAPABILITY_IDS:
        if cap_id in text.lower():
            return cap_id, action
    if _EXPLICIT_WORK.search(text):
        return None, "run_work"
    if _ACTION.search(text) and _DIGEST_TARGET.search(text):
        return "evidence.integrity_digest", "run_integrity_digest"
    if _ACTION.search(text) and _INTENT_TARGET.search(text):
        return "evidence.intent_proposal", "propose_intent"
    return None, ""


def _needs_conversation_model(text: str) -> bool:
    return bool(_CONVERSATION_MODEL.search(text))


def _entities(text: str) -> tuple[str, ...]:
    found = re.findall(r"\b(evidence|history|identity|capability|citizen)\b", text, re.I)
    return tuple(sorted({item.lower() for item in found}))


def contract_meta() -> dict[str, str]:
    return {"component": "HIT", "version": HIT_CONTRACT_VERSION, "role": "translator"}
