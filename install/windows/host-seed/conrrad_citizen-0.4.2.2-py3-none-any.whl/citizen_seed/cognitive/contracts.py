"""P0.10B HIT/HARLEMM contracts. Not Work. Not Sully. Not RuntimeDecision."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

HIT_CONTRACT_VERSION = "p0.10b.1"
HARLEMM_CONTRACT_VERSION = "p0.10b"
IWP_SCHEMA_VERSION = "conrrad-inference-work-package/v1"

INTERFACE_CONVERSATION = "CONVERSATION"
INTERFACE_FACT_QUERY = "FACT_QUERY"
INTERFACE_WORK_REQUEST = "WORK_REQUEST"
INTERFACE_KINDS = frozenset(
    {INTERFACE_CONVERSATION, INTERFACE_FACT_QUERY, INTERFACE_WORK_REQUEST}
)

# HARLEMM has exactly two governance classes (ADR-008). Interface kinds are not these.
HARLEMM_DETERMINISTIC = "DETERMINISTIC"
HARLEMM_INFERENCE_REQUIRED = "INFERENCE_REQUIRED"

SULLY_NOT_IMPLEMENTED = "SULLY_NOT_IMPLEMENTED"

FORBIDDEN_IWP_KEYS = frozenset(
    {
        "prompt",
        "model",
        "model_name",
        "modelFamily",
        "model_family",
        "lora",
        "loraStack",
        "lora_stack",
        "provider",
        "gpu",
        "vram",
        "ollama",
    }
)


@dataclass(frozen=True)
class OntologyRequest:
    """HIT output. Ontology/request — never a model-selection artifact."""

    request_id: str
    request_type: str
    normalized_intent: str
    subject: str
    entities: tuple[str, ...]
    constraints: tuple[str, ...]
    explicit_user_action: str
    conversational_context: tuple[str, ...]
    requested_capability: str | None
    ambiguity: str | None
    source_interface: str
    task_class_hint: str | None = None
    conversation_inference_required: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class DeterministicPlan:
    """HARLEMM plan. HARLEMM does not execute it."""

    execute_work: bool
    reason: str
    capability_id: str | None = None
    input: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "execute_work": self.execute_work,
            "reason": self.reason,
            "capability_id": self.capability_id,
            "input": dict(self.input),
        }


def _reject_forbidden(payload: dict[str, Any], *, path: str = "") -> None:
    for key, value in payload.items():
        loc = f"{path}.{key}" if path else key
        if key in FORBIDDEN_IWP_KEYS:
            raise ValueError(f"IWP_FORBIDDEN_FIELD:{loc}")
        if isinstance(value, dict):
            _reject_forbidden(value, path=loc)


@dataclass(frozen=True)
class InferenceWorkPackage:
    """ADR-009 conceptual IWP. No prompt. No model. No LoRA. No provider."""

    task_id: str
    task_class: str
    difficulty: str
    priority: str
    expected_output: dict[str, Any]
    budget: dict[str, Any]
    deadline: dict[str, Any]
    confidence: dict[str, Any]
    metadata: dict[str, Any]
    objective: str
    project: dict[str, Any]
    constraints: tuple[str, ...]
    dependencies: tuple[str, ...]
    context: dict[str, Any]
    deterministic_inputs: dict[str, Any]
    validation: tuple[str, ...]
    creativity: str

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "schemaVersion": IWP_SCHEMA_VERSION,
            "header": {
                "taskId": self.task_id,
                "taskClass": self.task_class,
                "difficulty": self.difficulty,
                "priority": self.priority,
                "expectedOutput": dict(self.expected_output),
                "budget": dict(self.budget),
                "deadline": dict(self.deadline),
                "confidence": dict(self.confidence),
                "metadata": dict(self.metadata),
            },
            "payload": {
                "objective": self.objective,
                "project": dict(self.project),
                "constraints": list(self.constraints),
                "dependencies": list(self.dependencies),
                "context": dict(self.context),
                "deterministicInputs": dict(self.deterministic_inputs),
                "validation": list(self.validation),
                "creativity": self.creativity,
            },
        }
        _reject_forbidden(payload)
        return payload


@dataclass(frozen=True)
class HarlemmDecision:
    classification: str
    inference_required: bool
    reason: str
    used_transitional_policy: bool
    deterministic_plan: DeterministicPlan | None = None
    iwp: InferenceWorkPackage | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "classification": self.classification,
            "inference_required": self.inference_required,
            "reason": self.reason,
            "used_transitional_policy": self.used_transitional_policy,
            "transitional_note": (
                "decide_inference_need is an INTERNAL seed, not HARLEMM"
                if self.used_transitional_policy
                else None
            ),
            "deterministic_plan": (
                self.deterministic_plan.to_dict() if self.deterministic_plan else None
            ),
            "iwp": self.iwp.to_dict() if self.iwp else None,
        }
