"""P0.10B cognitive boundary: HIT translator + HARLEMM governor.

Not a rename of citizen_seed.work. Sully is not implemented here.
"""

from .contracts import (
    HARLEMM_DETERMINISTIC,
    HARLEMM_INFERENCE_REQUIRED,
    INTERFACE_CONVERSATION,
    INTERFACE_FACT_QUERY,
    INTERFACE_WORK_REQUEST,
    SULLY_NOT_IMPLEMENTED,
)
from .hit import translate
from .harlemm import classify
from .live import interpret

__all__ = [
    "translate",
    "classify",
    "interpret",
    "HARLEMM_DETERMINISTIC",
    "HARLEMM_INFERENCE_REQUIRED",
    "INTERFACE_CONVERSATION",
    "INTERFACE_FACT_QUERY",
    "INTERFACE_WORK_REQUEST",
    "SULLY_NOT_IMPLEMENTED",
]
