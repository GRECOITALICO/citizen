"""HIT → HARLEMM interpret loop. Conversation is not Work."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from citizen_seed import PACKAGE_VERSION, RUNTIME_VERSION
from citizen_seed.identity import load as load_identity
from citizen_seed.paths import layout
from citizen_seed.work.capability_state import project as project_capabilities
from citizen_seed.work.registry import local_registry

from .contracts import (
    HARLEMM_INFERENCE_REQUIRED,
    INTERFACE_CONVERSATION,
    INTERFACE_FACT_QUERY,
    SULLY_NOT_IMPLEMENTED,
    OntologyRequest,
)
from . import harlemm
from . import hit
from . import session as hit_session


def interpret(
    home: Path,
    *,
    text: str,
    session_id: str = "",
    source: str = "text",
    execute_work: bool = True,
) -> dict[str, Any]:
    """Translate, classify, optionally execute bounded Work. Never calls Sully."""
    home = Path(home)
    ontology = hit.translate(text, session_id=session_id, source=source)
    decision = harlemm.classify(ontology)
    facts = _runtime_facts(home) if ontology.request_type == INTERFACE_FACT_QUERY else None

    work_result: dict[str, Any] | None = None
    status = "OK"
    if (
        execute_work
        and ontology.request_type != INTERFACE_CONVERSATION
        and ontology.request_type != INTERFACE_FACT_QUERY
        and decision.deterministic_plan is not None
        and decision.deterministic_plan.execute_work
        and decision.deterministic_plan.capability_id
    ):
        from citizen_seed.work import submit_work

        work_result = submit_work(
            home,
            capability_id=decision.deterministic_plan.capability_id,
            input_payload=dict(decision.deterministic_plan.input),
        )
        status = str(work_result.get("status") or "OK")
    elif decision.classification == HARLEMM_INFERENCE_REQUIRED:
        status = SULLY_NOT_IMPLEMENTED

    conversation_inference_required = bool(
        ontology.request_type == INTERFACE_CONVERSATION
        and ontology.conversation_inference_required
    )

    return {
        "ok": True,
        "status": status,
        "request_id": ontology.request_id,
        "classification": decision.classification,
        "interface_kind": ontology.request_type,
        "inference_required": decision.inference_required,
        "conversation_inference_required": conversation_inference_required,
        "normalized_request": ontology.to_dict(),
        "deterministic_plan": (
            decision.deterministic_plan.to_dict() if decision.deterministic_plan else None
        ),
        "iwp": decision.iwp.to_dict() if decision.iwp else None,
        "ambiguity": ontology.ambiguity,
        "facts": facts,
        "work": work_result,
        "diagnostics": {
            "hit": hit.contract_meta(),
            "harlemm": harlemm.contract_meta(),
            "sully": "NOT_IMPLEMENTED",
            "session": hit_session.session_debug(session_id),
            "transitional_policy_seed": decision.used_transitional_policy,
        },
    }


def _runtime_facts(home: Path) -> dict[str, Any]:
    citizen_id = ""
    ready = False
    try:
        ident = load_identity(layout(home)["identity"])
        citizen_id = ident.citizen_id
        ready = (home / "identity" / "SEALED").is_file() or bool(citizen_id)
    except FileNotFoundError:
        ready = False
    caps = []
    try:
        proj = project_capabilities(home)
        caps = [c.get("capability_id") for c in (proj.get("capabilities") or []) if isinstance(c, dict)]
    except Exception:
        caps = list(local_registry().keys())
    return {
        "runtime_version": RUNTIME_VERSION,
        "package_version": PACKAGE_VERSION,
        "citizen_id": citizen_id,
        "ready": ready,
        "capabilities": caps,
    }


def ontology_only(payload: OntologyRequest | dict[str, Any]) -> dict[str, Any]:
    """HARLEMM entry for already-translated ontology (no raw NL)."""
    if isinstance(payload, dict):
        raise TypeError("HARLEMM_REJECTS_RAW_NL")
    return harlemm.classify(payload).to_dict()
