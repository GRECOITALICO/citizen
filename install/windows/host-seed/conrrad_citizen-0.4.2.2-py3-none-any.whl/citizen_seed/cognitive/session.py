"""Temporary in-memory HIT session context. Never Citizen History or Evidence."""
from __future__ import annotations

from collections import deque
from threading import Lock
from typing import Any

SESSION_WINDOW = 8

_LOCK = Lock()
_SESSIONS: dict[str, deque[str]] = {}


def remember_user_turn(session_id: str, text: str) -> tuple[str, ...]:
    """Append one user utterance. Returns the bounded window *before* this turn."""
    sid = (session_id or "").strip() or "anonymous"
    clipped = text.strip()[:2000]
    with _LOCK:
        window = _SESSIONS.setdefault(sid, deque(maxlen=SESSION_WINDOW))
        prior = tuple(window)
        if clipped:
            window.append(clipped)
        return prior


def context_for(session_id: str) -> tuple[str, ...]:
    sid = (session_id or "").strip() or "anonymous"
    with _LOCK:
        window = _SESSIONS.get(sid)
        return tuple(window) if window else ()


def reset_sessions() -> None:
    with _LOCK:
        _SESSIONS.clear()


def session_debug(session_id: str) -> dict[str, Any]:
    """Diagnostics only. Not a persistence API."""
    return {
        "session_id": (session_id or "").strip() or "anonymous",
        "window": list(context_for(session_id)),
        "persistent": False,
        "storage": "memory",
    }
