"""Citizen cognitive HARLEMM (ADR-008/009) — P0.10B initial boundary.

HARLEMM classifies ontology. It does not select inference resources.
It does not execute Work. It does not become RuntimeDecision.

TRANSITIONAL: `decide_inference_need` may be consulted as an INTERNAL seed when a
Work-shaped capability is already known. That function is not HARLEMM.
"""
from __future__ import annotations

from .contracts import (
    HARLEMM_CONTRACT_VERSION,
    HARLEMM_DETERMINISTIC,
    HARLEMM_INFERENCE_REQUIRED,
    DeterministicPlan,
    HarlemmDecision,
    InferenceWorkPackage,
    INTERFACE_FACT_QUERY,
    INTERFACE_CONVERSATION,
    OntologyRequest,
)

# Known deterministic Citizen capabilities (capability ids only — not implementations).
_DIGEST = "evidence.integrity_digest"
_HISTORY = "evidence.history_digest"
_INTENT = "evidence.intent_proposal"


def classify(ontology: OntologyRequest) -> HarlemmDecision:
    if not isinstance(ontology, OntologyRequest):
        raise TypeError("HARLEMM_REJECTS_RAW_NL")

    if ontology.request_type in {INTERFACE_CONVERSATION, INTERFACE_FACT_QUERY}:
        return HarlemmDecision(
            classification=HARLEMM_DETERMINISTIC,
            inference_required=False,
            reason="INTERFACE_NON_WORK",
            used_transitional_policy=False,
            deterministic_plan=DeterministicPlan(
                execute_work=False,
                reason="conversation_or_fact_is_not_work",
                capability_id=None,
                input={},
            ),
            iwp=None,
        )

    capability = ontology.requested_capability
    if capability in {_DIGEST, _HISTORY}:
        source = "evidence.jsonl" if capability == _DIGEST else "canonical_work_history.jsonl"
        return HarlemmDecision(
            classification=HARLEMM_DETERMINISTIC,
            inference_required=False,
            reason="REGISTERED_DETERMINISTIC_CAPABILITY",
            used_transitional_policy=False,
            deterministic_plan=DeterministicPlan(
                execute_work=True,
                reason="bounded_capability",
                capability_id=capability,
                input={"source": source},
            ),
        )

    if capability == _INTENT:
        return _intent_via_transitional_seed(ontology)

    return HarlemmDecision(
        classification=HARLEMM_INFERENCE_REQUIRED,
        inference_required=True,
        reason="INFERENCE_REQUIRED_UNBOUND",
        used_transitional_policy=False,
        iwp=_emit_iwp(ontology, task_class="unspecified_generation"),
    )


def _intent_via_transitional_seed(ontology: OntologyRequest) -> HarlemmDecision:
    """Reuse proven WorkContext policy as a seed. Do not select an implementation."""
    from citizen_seed.work.inference_policy import decide_inference_need
    from citizen_seed.work.work_context import (
        TASK_CLASS_DETERMINISTIC,
        TASK_CLASS_SEMANTIC_INTERPRETATION,
        parse_work_context,
    )

    hint = ontology.task_class_hint or TASK_CLASS_DETERMINISTIC
    if hint not in {TASK_CLASS_DETERMINISTIC, TASK_CLASS_SEMANTIC_INTERPRETATION}:
        hint = TASK_CLASS_SEMANTIC_INTERPRETATION
    ctx = parse_work_context(
        work_id=ontology.request_id,
        capability_id=_INTENT,
        input_payload={
            "task_text": ontology.subject,
            "task_class": hint,
        },
    )
    seed = decide_inference_need(ctx)
    if seed is None or seed.inference_required:
        return HarlemmDecision(
            classification=HARLEMM_INFERENCE_REQUIRED,
            inference_required=True,
            reason="TRANSITIONAL_SEED_INFERENCE_REQUIRED",
            used_transitional_policy=True,
            iwp=_emit_iwp(ontology, task_class=hint),
        )
    return HarlemmDecision(
        classification=HARLEMM_DETERMINISTIC,
        inference_required=False,
        reason="TRANSITIONAL_SEED_DETERMINISTIC",
        used_transitional_policy=True,
        deterministic_plan=DeterministicPlan(
            execute_work=True,
            reason="bounded_intent_capability",
            capability_id=_INTENT,
            input={
                "task_text": ontology.subject,
                "task_class": hint,
            },
        ),
    )


def _emit_iwp(ontology: OntologyRequest, *, task_class: str) -> InferenceWorkPackage:
    return InferenceWorkPackage(
        task_id=ontology.request_id,
        task_class=task_class,
        difficulty="medium",
        priority="normal",
        expected_output={"format": "structured", "kind": "inference_result"},
        budget={"maxCostUsd": 0.0},
        deadline={"targetSeconds": 30},
        confidence={"minimum": 0.0},
        metadata={"source": "harlemm-p0.10b", "requestType": ontology.request_type},
        objective=ontology.normalized_intent or ontology.subject,
        project={},
        constraints=ontology.constraints,
        dependencies=(),
        context={"subject": ontology.subject, "entities": list(ontology.entities)},
        deterministic_inputs={},
        validation=(),
        creativity="low",
    )


def contract_meta() -> dict[str, str]:
    return {
        "component": "HARLEMM",
        "version": HARLEMM_CONTRACT_VERSION,
        "role": "cognitive_governor",
    }
