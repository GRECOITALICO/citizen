"""CLASS_PACKAGE — coordinated runtime + living evolution descriptor.

Not Birth. Not a Citizen replacement. Not an in-guest self-updater.
Runtime artifact is an OCI digest. Living artifact is the existing signed pack.
Integrity reuses Ed25519 envelopes (mission-033-governed-key) — distinct kind.
"""
from __future__ import annotations

import json
import os
import platform as py_platform
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .crypto import canonical_json, sha256_bytes, sha256_file
from .evolution_semantics import compare_versions
from .evolution_verifier import verify_descriptor_signature
from .release_contract import ContractError

SCHEMA_VERSION = "conrrad-class-package/v1"
ENVELOPE_KIND = "conrrad-class-package"
LIVING_EVOLUTION_SCHEMA = "conrrad-evolution-v1"
CLASS_PACKAGE_FILENAME = "CLASS_PACKAGE.json"

DIGEST_RE = re.compile(r"^sha256:[a-f0-9]{64}$")
SHA256_RE = re.compile(r"^[a-f0-9]{64}$")
FLOATING_TAGS = frozenset({"latest", "main", "master", "head"})
ALLOWED_MIGRATION = frozenset({"none", "required"})

# P0.11I.1 implements CLASS_PACKAGE only: RUNTIME_VERSION string does not advance.
CLASS_RUNTIME_BUMP_UNSUPPORTED = (
    "CLASS_RUNTIME_BUMP is not applied by P0.11I.1; runtime_version must stay unchanged"
)


class ClassPackageError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(frozen=True)
class CurrentCitizenState:
    living_version: str
    runtime_version: str
    runtime_image_digest: str
    platform: str = "linux"
    architecture: str = "amd64"
    citizen_id: str = ""
    identity_hash: str = ""
    identity_sealed: bool = False
    evidence_count: int = 0
    history_count: int = 0
    evidence_hash: str = ""
    history_hash: str = ""


def _require_mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ClassPackageError("INVALID_SCHEMA", f"{label} must be an object")
    return value


def _text(value: Any) -> str:
    return str(value or "").strip()


def normalize_digest(value: str) -> str:
    text = _text(value).lower()
    if not text:
        return ""
    if text.startswith("sha256:"):
        return text
    if SHA256_RE.match(text):
        return f"sha256:{text}"
    return text


def digest_hex(value: str) -> str:
    return normalize_digest(value).removeprefix("sha256:")


def is_floating_runtime_ref(ref: str) -> bool:
    text = _text(ref)
    if not text:
        return True
    if "@sha256:" in text:
        digest = text.rsplit("@", 1)[-1]
        return not DIGEST_RE.match(normalize_digest(digest))
    if ":" in text.split("/")[-1]:
        tag = text.rsplit(":", 1)[-1].split("@", 1)[0].lower()
        if tag in FLOATING_TAGS:
            return True
    return True


def runtime_ref_digest(ref: str) -> str:
    text = _text(ref)
    if "@sha256:" not in text:
        raise ClassPackageError(
            "INVALID_RUNTIME_DIGEST",
            "runtime_image must be an immutable digest reference (name@sha256:…)",
        )
    digest = normalize_digest(text.rsplit("@", 1)[-1])
    if not DIGEST_RE.match(digest):
        raise ClassPackageError("INVALID_RUNTIME_DIGEST", f"invalid OCI digest: {digest}")
    return digest


def validate_descriptor(descriptor: Mapping[str, Any]) -> dict[str, Any]:
    data = _require_mapping(descriptor, "descriptor")
    if _text(data.get("schema")) == LIVING_EVOLUTION_SCHEMA:
        raise ClassPackageError(
            "INVALID_SCHEMA",
            "living Evolution kind cannot be used as a CLASS_PACKAGE",
        )
    if _text(data.get("schema_version")) != SCHEMA_VERSION:
        raise ClassPackageError(
            "INVALID_SCHEMA",
            f"schema_version must be {SCHEMA_VERSION}",
        )
    if not _text(data.get("package_id")):
        raise ClassPackageError("INVALID_SCHEMA", "package_id required")

    source = _require_mapping(data.get("source"), "source")
    target = _require_mapping(data.get("target"), "target")
    artifacts = _require_mapping(data.get("artifacts"), "artifacts")
    integrity = _require_mapping(data.get("integrity"), "integrity")
    compatibility = _require_mapping(data.get("compatibility"), "compatibility")
    migration = _require_mapping(data.get("migration"), "migration")
    rollback = _require_mapping(data.get("rollback"), "rollback")
    metadata = _require_mapping(data.get("metadata"), "metadata")

    for label, plane in (("source", source), ("target", target)):
        digest = normalize_digest(plane.get("runtime_image_digest", ""))
        if not DIGEST_RE.match(digest):
            raise ClassPackageError(
                "INVALID_RUNTIME_DIGEST",
                f"{label}.runtime_image_digest must be sha256:<64 hex>",
            )
        plane["runtime_image_digest"] = digest
        if not _text(plane.get("living_version")) or not _text(plane.get("runtime_version")):
            raise ClassPackageError("INVALID_SCHEMA", f"{label} versions required")

    runtime_image = _text(artifacts.get("runtime_image"))
    if is_floating_runtime_ref(runtime_image):
        raise ClassPackageError(
            "INVALID_RUNTIME_DIGEST",
            "runtime_image must not use latest/main/floating tags; digest is authoritative",
        )
    image_digest = runtime_ref_digest(runtime_image)
    if image_digest != target["runtime_image_digest"]:
        raise ClassPackageError(
            "INVALID_RUNTIME_DIGEST",
            "artifacts.runtime_image digest must match target.runtime_image_digest",
        )
    artifacts["runtime_image"] = runtime_image
    artifacts["living_pack"] = _text(artifacts.get("living_pack"))

    runtime_sha = _text(integrity.get("runtime_sha256")).lower()
    if not SHA256_RE.match(runtime_sha):
        raise ClassPackageError("INVALID_RUNTIME_DIGEST", "integrity.runtime_sha256 must be 64 hex")
    if runtime_sha != digest_hex(target["runtime_image_digest"]):
        raise ClassPackageError(
            "INVALID_RUNTIME_DIGEST",
            "integrity.runtime_sha256 must match target.runtime_image_digest",
        )
    living_sha = _text(integrity.get("living_sha256")).lower()
    if living_sha and not SHA256_RE.match(living_sha):
        raise ClassPackageError("INVALID_LIVING_HASH", "integrity.living_sha256 must be 64 hex or empty")
    integrity["runtime_sha256"] = runtime_sha
    integrity["living_sha256"] = living_sha

    for key in (
        "minimum_supported_runtime",
        "minimum_supported_living",
        "platform",
        "architecture",
    ):
        if not _text(compatibility.get(key)):
            raise ClassPackageError("INVALID_SCHEMA", f"compatibility.{key} required")

    runtime_mig = _text(migration.get("runtime"))
    living_mig = _text(migration.get("living"))
    if runtime_mig not in ALLOWED_MIGRATION or living_mig not in ALLOWED_MIGRATION:
        raise ClassPackageError("INVALID_MIGRATION", "migration.runtime/living must be none|required")
    if source["runtime_version"] != target["runtime_version"] and runtime_mig != "required":
        raise ClassPackageError("INVALID_MIGRATION", CLASS_RUNTIME_BUMP_UNSUPPORTED)
    if source["runtime_version"] != target["runtime_version"]:
        raise ClassPackageError("INCOMPATIBLE_RUNTIME", CLASS_RUNTIME_BUMP_UNSUPPORTED)

    if not _text(rollback.get("previous_runtime_image")) or not _text(
        rollback.get("previous_living_version")
    ):
        raise ClassPackageError("INVALID_SCHEMA", "rollback previous_* required")
    for key in ("created_at", "release_id", "provenance"):
        if not _text(metadata.get(key)):
            raise ClassPackageError("INVALID_SCHEMA", f"metadata.{key} required")

    data["source"] = source
    data["target"] = target
    data["artifacts"] = artifacts
    data["integrity"] = integrity
    data["compatibility"] = compatibility
    data["migration"] = migration
    data["rollback"] = rollback
    data["metadata"] = metadata
    return data


def verify_class_package_envelope(envelope: Mapping[str, Any]) -> dict[str, Any]:
    """Verify Ed25519 envelope then CLASS_PACKAGE schema. Fail-closed."""
    data = _require_mapping(envelope, "envelope")
    kind = _text(data.get("kind"))
    if kind and kind != ENVELOPE_KIND:
        raise ClassPackageError("INVALID_SCHEMA", f"envelope kind must be {ENVELOPE_KIND}")
    try:
        descriptor = verify_descriptor_signature(data)
    except ContractError as exc:
        raise ClassPackageError("INVALID_SIGNATURE", str(exc)) from exc
    return validate_descriptor(descriptor)


def living_artifact_sha256(path: Path | str | None) -> str:
    if not path:
        return ""
    target = Path(path)
    if target.is_file() and target.name == "ARTIFACT_SHA256":
        return target.read_text(encoding="utf-8").strip().lower()
    if target.is_dir():
        marker = target / "ARTIFACT_SHA256"
        if marker.is_file():
            return marker.read_text(encoding="utf-8").strip().lower()
        manifest = target / "manifest.json"
        if manifest.is_file():
            return sha256_file(manifest)
    if target.is_file():
        return sha256_file(target)
    raise ClassPackageError("INVALID_LIVING_HASH", f"living artifact not found: {path}")


def verify_living_artifact(descriptor: Mapping[str, Any], *, pack_dir: Path | None = None) -> str:
    expected = _text(descriptor["integrity"].get("living_sha256")).lower()
    living_ref = pack_dir or _text(descriptor["artifacts"].get("living_pack"))
    if descriptor["source"]["living_version"] == descriptor["target"]["living_version"] and not expected:
        return ""
    if not expected:
        raise ClassPackageError("INVALID_LIVING_HASH", "living_sha256 required when living changes")
    if not living_ref:
        raise ClassPackageError("INVALID_LIVING_HASH", "living_pack required when living_sha256 is set")
    actual = living_artifact_sha256(living_ref)
    if actual != expected:
        raise ClassPackageError(
            "INVALID_LIVING_HASH",
            f"living SHA256 mismatch: expected {expected} got {actual}",
        )
    return actual


def living_artifact_present(descriptor: Mapping[str, Any]) -> bool:
    artifacts = descriptor.get("artifacts") if isinstance(descriptor.get("artifacts"), dict) else {}
    integrity = descriptor.get("integrity") if isinstance(descriptor.get("integrity"), dict) else {}
    return bool(_text(artifacts.get("living_pack")) or _text(integrity.get("living_sha256")))


def living_component_applicable(descriptor: Mapping[str, Any], current: CurrentCitizenState) -> bool:
    """Living apply is separate from runtime replacement. Defer if source living differs."""
    if not living_artifact_present(descriptor):
        return False
    target = descriptor["target"]
    source = descriptor["source"]
    if current.living_version == target["living_version"]:
        return False
    if compare_versions(target["living_version"], current.living_version) < 0:
        return False
    return current.living_version == source["living_version"]


def check_runtime_compatibility(descriptor: Mapping[str, Any], current: CurrentCitizenState) -> None:
    compat = descriptor["compatibility"]
    source = descriptor["source"]
    target = descriptor["target"]

    current_platform = _text(current.platform).lower() or host_platform()
    current_arch = _text(current.architecture).lower() or host_architecture()
    if current_platform != _text(compat["platform"]).lower():
        raise ClassPackageError("INCOMPATIBLE_PLATFORM", "wrong platform")
    if current_arch != _text(compat["architecture"]).lower():
        raise ClassPackageError("INCOMPATIBLE_PLATFORM", "wrong architecture")

    if compare_versions(current.runtime_version, compat["minimum_supported_runtime"]) < 0:
        raise ClassPackageError("INCOMPATIBLE_RUNTIME", "unsupported current runtime")
    if compare_versions(target["runtime_version"], current.runtime_version) < 0:
        raise ClassPackageError("DOWNGRADE", "runtime downgrade is forbidden")

    already_runtime = (
        normalize_digest(current.runtime_image_digest) == target["runtime_image_digest"]
        and current.runtime_version == target["runtime_version"]
    )
    if already_runtime:
        return
    if current.runtime_version != source["runtime_version"]:
        raise ClassPackageError("INCOMPATIBLE_RUNTIME", "current runtime does not match package source")
    if normalize_digest(current.runtime_image_digest) != source["runtime_image_digest"]:
        raise ClassPackageError(
            "INCOMPATIBLE_RUNTIME",
            "current runtime image digest does not match package source",
        )


def check_living_compatibility(descriptor: Mapping[str, Any], current: CurrentCitizenState) -> None:
    target = descriptor["target"]
    if compare_versions(target["living_version"], current.living_version) < 0:
        raise ClassPackageError("DOWNGRADE", "living downgrade is forbidden")
    if not living_artifact_present(descriptor):
        return
    compat = descriptor["compatibility"]
    if compare_versions(current.living_version, compat["minimum_supported_living"]) < 0:
        raise ClassPackageError("INCOMPATIBLE_LIVING", "unsupported current living")


def check_compatibility(descriptor: Mapping[str, Any], current: CurrentCitizenState) -> None:
    """Runtime plane is independent of living source match.

    A runtime-only bridge (no living pack) may replace the image while living
    stays put. A living pack whose source living does not match is deferred,
    not a fail-closed runtime block.
    """
    check_runtime_compatibility(descriptor, current)
    check_living_compatibility(descriptor, current)
    already_target = (
        current.living_version == descriptor["target"]["living_version"]
        and normalize_digest(current.runtime_image_digest) == descriptor["target"]["runtime_image_digest"]
        and current.runtime_version == descriptor["target"]["runtime_version"]
    )
    if already_target:
        return
    if living_component_applicable(descriptor, current):
        return
    if living_artifact_present(descriptor) and current.living_version != descriptor["source"]["living_version"]:
        return


def needs_runtime_replacement(descriptor: Mapping[str, Any], current: CurrentCitizenState) -> bool:
    return normalize_digest(current.runtime_image_digest) != descriptor["target"]["runtime_image_digest"]


def needs_living_evolution(descriptor: Mapping[str, Any], current: CurrentCitizenState) -> bool:
    return living_component_applicable(descriptor, current)


def host_platform() -> str:
    return (os.environ.get("CITIZEN_PLATFORM") or py_platform.system() or "linux").strip().lower()


def host_architecture() -> str:
    machine = (os.environ.get("CITIZEN_ARCH") or py_platform.machine() or "amd64").strip().lower()
    if machine in {"x86_64", "amd64"}:
        return "amd64"
    if machine in {"aarch64", "arm64"}:
        return "arm64"
    return machine


def discover_class_package(updates_dir: Path | None) -> Path | None:
    if updates_dir is None:
        return None
    root = Path(updates_dir)
    if not root.is_dir():
        return None
    named = root / CLASS_PACKAGE_FILENAME
    if named.is_file():
        return named
    matches = sorted(root.glob("*.class-package.json"))
    return matches[0] if matches else None


def load_envelope(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ClassPackageError("INVALID_SCHEMA", f"cannot read CLASS_PACKAGE: {exc}") from exc
    if not isinstance(data, dict):
        raise ClassPackageError("INVALID_SCHEMA", "CLASS_PACKAGE envelope must be an object")
    return data


def build_descriptor(
    *,
    package_id: str,
    source: CurrentCitizenState | Mapping[str, str],
    target_living: str,
    target_runtime_version: str,
    target_digest: str,
    runtime_image: str,
    living_pack: str = "",
    living_sha256: str = "",
    minimum_supported_runtime: str = "0.4.2",
    minimum_supported_living: str = "0.4.0",
    platform: str = "linux",
    architecture: str = "amd64",
    runtime_migration: str = "none",
    living_migration: str = "none",
    created_at: str = "2026-08-24T00:00:00Z",
    release_id: str = "",
    provenance: str = "P0.11I.1",
) -> dict[str, Any]:
    if isinstance(source, CurrentCitizenState):
        src = {
            "living_version": source.living_version,
            "runtime_version": source.runtime_version,
            "runtime_image_digest": normalize_digest(source.runtime_image_digest),
        }
    else:
        src = {
            "living_version": _text(source.get("living_version")),
            "runtime_version": _text(source.get("runtime_version")),
            "runtime_image_digest": normalize_digest(source.get("runtime_image_digest", "")),
        }
    digest = normalize_digest(target_digest)
    if "@" in runtime_image:
        previous_image = f"{runtime_image.rsplit('@', 1)[0]}@{src['runtime_image_digest']}"
    else:
        previous_image = src["runtime_image_digest"]
    return {
        "package_id": package_id,
        "schema_version": SCHEMA_VERSION,
        "source": src,
        "target": {
            "living_version": target_living,
            "runtime_version": target_runtime_version,
            "runtime_image_digest": digest,
        },
        "artifacts": {
            "runtime_image": runtime_image,
            "living_pack": living_pack,
        },
        "integrity": {
            "runtime_sha256": digest_hex(digest),
            "living_sha256": _text(living_sha256).lower(),
        },
        "compatibility": {
            "minimum_supported_runtime": minimum_supported_runtime,
            "minimum_supported_living": minimum_supported_living,
            "platform": platform,
            "architecture": architecture,
        },
        "migration": {"runtime": runtime_migration, "living": living_migration},
        "rollback": {
            "previous_runtime_image": previous_image,
            "previous_living_version": src["living_version"],
        },
        "metadata": {
            "created_at": created_at,
            "release_id": release_id or package_id,
            "provenance": provenance,
        },
    }


REQUEST_SCHEMA = "conrrad.citizen.runtime_evolution_request/v1"
REQUEST_FILENAME = "RUNTIME_EVOLUTION_REQUEST.json"
REQUEST_STATUSES = frozenset(
    {"requested", "applying", "complete", "rolled_back", "failed", "deferred_living"}
)


def write_runtime_evolution_request(
    home: Path,
    *,
    citizen_id: str,
    current_image_digest: str,
    target_package_reference: str,
    request_id: str = "",
    status: str = "requested",
    created_at: str = "",
) -> dict[str, Any]:
    """Guest-safe host request. No secrets, prompts, History, or Evidence."""
    import time
    import uuid

    body = {
        "schema": REQUEST_SCHEMA,
        "request_id": request_id or str(uuid.uuid4()),
        "citizen_id": _text(citizen_id),
        "current_image_digest": normalize_digest(current_image_digest),
        "target_package_reference": _text(target_package_reference),
        "created_at": created_at or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "status": status if status in REQUEST_STATUSES else "requested",
    }
    path = Path(home) / "ops" / REQUEST_FILENAME
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(body, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return body


def load_runtime_evolution_request(home: Path) -> dict[str, Any] | None:
    path = Path(home) / "ops" / REQUEST_FILENAME
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    return data


def build_runtime_bridge_descriptor(
    *,
    current: CurrentCitizenState | Mapping[str, str],
    target_digest: str,
    runtime_image: str,
    package_id: str = "citizen-runtime-bridge-0.4.2.2",
    release_id: str = "0.4.2.2",
    provenance: str = "P0.11I.3B",
) -> dict[str, Any]:
    """Runtime-only CLASS_PACKAGE. Living artifact omitted. Living version preserved."""
    if isinstance(current, CurrentCitizenState):
        living = current.living_version
    else:
        living = _text(current.get("living_version"))
    return build_descriptor(
        package_id=package_id,
        source=current,
        target_living=living,
        target_runtime_version="0.4.2",
        target_digest=target_digest,
        runtime_image=runtime_image,
        living_pack="",
        living_sha256="",
        living_migration="none",
        runtime_migration="none",
        release_id=release_id,
        provenance=provenance,
    )


def apply_living_pack(home: Path, pack_dir: str = "") -> dict[str, Any]:
    """In-guest living apply. HostAdapter never calls this for Python/runtime files."""
    from .updater import one_click_package, one_click_update

    if pack_dir:
        return one_click_package(home=home, package_dir=Path(pack_dir))
    return one_click_update(home=home)


def canonical_descriptor_bytes(descriptor: Mapping[str, Any]) -> bytes:
    return canonical_json(descriptor)


def identity_file_hash(home: Path) -> str:
    path = Path(home) / "identity" / "identity.json"
    if not path.is_file():
        return ""
    return sha256_bytes(path.read_bytes())


def plane_hash(path: Path) -> str:
    if not path.is_file():
        return ""
    return sha256_bytes(path.read_bytes())


def count_lines(path: Path) -> int:
    if not path.is_file():
        return 0
    return sum(1 for line in path.read_text(encoding="utf-8").splitlines() if line.strip())
