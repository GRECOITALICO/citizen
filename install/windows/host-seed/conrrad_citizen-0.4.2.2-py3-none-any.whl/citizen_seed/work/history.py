"""Canonical Work history plane — ops/canonical_work_history.jsonl."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

HISTORY_NAME = "canonical_work_history.jsonl"


def history_path(home: Path) -> Path:
    d = Path(home) / "ops"
    d.mkdir(parents=True, exist_ok=True)
    return d / HISTORY_NAME


def append_history(home: Path, row: dict[str, Any]) -> Path:
    path = history_path(home)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, sort_keys=True) + "\n")
    return path


def read_history(home: Path) -> list[dict[str, Any]]:
    path = history_path(home)
    if not path.is_file():
        return []
    out: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out
