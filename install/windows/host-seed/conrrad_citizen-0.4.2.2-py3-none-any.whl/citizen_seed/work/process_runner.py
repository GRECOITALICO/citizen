"""Trusted-runtime process launcher for untrusted implementations.

Parent owns: process creation, timeout, termination, output limits, decoding.
Child owns: implementation execution only (via implementation_runner).
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Mapping

from .implementation_registry import resolve_module
from .ipc import ImplementationRequest, ImplementationResponse, read_json, sha256_json, write_json

# Secrets / runtime env keys stripped from child environment
FORBIDDEN_ENV_PREFIXES = (
    "GITHUB_",
    "GH_",
    "AWS_",
    "OPENAI_",
    "ANTHROPIC_",
    "TOKEN",
    "SECRET",
    "PASSWORD",
    "PRIVATE_KEY",
)
FORBIDDEN_ENV_EXACT = frozenset(
    {
        "CITIZEN_HOME",
        "HOME",  # replaced with staging dir
        "PYTHONPATH",  # replaced with minimal package path
    }
)


def _package_src_path() -> str:
    """Directory containing citizen_seed package (for child PYTHONPATH)."""
    here = Path(__file__).resolve()
    # .../citizen_seed/work/process_runner.py → .../src
    src = here.parents[2]
    return str(src)


def minimal_child_environment(staging_dir: Path) -> dict[str, str]:
    """Explicit minimal environment — no credentials or runtime secrets.

    PYTHONPATH_CONTROL_PLANE_COUPLING=PARTIAL:
    Child still needs the citizen_seed package root to load implementation modules
    and IPC helpers. It does NOT receive CITIZEN_HOME, writers, or secrets.
    Full removal of package PYTHONPATH requires packaging a standalone runner wheel
    (deferred). Implementations must not import control-plane writers.
    """
    env: dict[str, str] = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": os.environ.get("LANG", "C.UTF-8"),
        "LC_ALL": os.environ.get("LC_ALL", "C.UTF-8"),
        "PYTHONUNBUFFERED": "1",
        "PYTHONPATH": _package_src_path(),
        "HOME": str(staging_dir),
        "CITIZEN_IMPL_ISOLATED": "1",
        "CITIZEN_IMPL_STAGING": str(staging_dir),
        "CITIZEN_PYTHONPATH_CONTROL_PLANE_COUPLING": "PARTIAL",
    }
    # Explicit non-secret model artifact override (tests / ops)
    artifact = os.environ.get("CITIZEN_INTENT_MODEL_ARTIFACT")
    if artifact:
        env["CITIZEN_INTENT_MODEL_ARTIFACT"] = artifact
    return env


def _check_input_size(request: ImplementationRequest, max_input_bytes: int) -> str | None:
    n = request.serialized_byte_length()
    if n > max_input_bytes:
        return f"RESOURCE_EXHAUSTION:max_input_bytes:{n}>{max_input_bytes}"
    return None


def run_implementation_process(
    *,
    work_id: str,
    capability_id: str,
    implementation_id: str,
    scoped_input: Mapping[str, Any],
    resource_limits: Mapping[str, Any],
    request_timestamp: str,
    timeout_ms: int,
    max_input_bytes: int,
    max_output_bytes: int,
) -> dict[str, Any]:
    """Launch implementation in a separate process; return worker-compatible dict."""
    if resolve_module(implementation_id) is None:
        return {
            "status": "BLOCKED",
            "implementation_id": implementation_id,
            "error": "UNKNOWN_IMPLEMENTATION",
            "result": None,
            "process_isolated": False,
        }

    req = ImplementationRequest(
        work_id=work_id,
        capability_id=capability_id,
        implementation_id=implementation_id,
        scoped_input=dict(scoped_input),
        resource_limits=dict(resource_limits),
        request_timestamp=request_timestamp,
        deadline_ms=timeout_ms,
    )
    size_err = _check_input_size(req, max_input_bytes)
    if size_err:
        return {
            "status": "FAILED",
            "implementation_id": implementation_id,
            "error": size_err,
            "result": None,
            "process_isolated": True,
            "timeout_status": "NOT_RUN",
        }

    staging = Path(tempfile.mkdtemp(prefix="citizen-impl-"))
    request_path = staging / "request.json"
    response_path = staging / "response.json"

    try:
        write_json(str(request_path), req.to_dict())

        cmd = [
            sys.executable,
            "-m",
            "citizen_seed.work.implementation_runner",
            "--request-file",
            str(request_path),
            "--response-file",
            str(response_path),
        ]
        env = minimal_child_environment(staging)
        timeout_sec = max(0.001, timeout_ms / 1000.0)

        proc = subprocess.Popen(
            cmd,
            cwd=str(staging),
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
        )
        implementation_process_id = proc.pid
        timeout_status = "OK"
        exit_status: int | None = None

        try:
            _, stderr = proc.communicate(timeout=timeout_sec)
            exit_status = proc.returncode
        except subprocess.TimeoutExpired:
            timeout_status = "TIMEOUT"
            proc.kill()
            try:
                _, stderr = proc.communicate(timeout=2)
            except Exception:  # noqa: BLE001
                stderr = ""
            exit_status = proc.returncode
            return {
                "status": "FAILED",
                "implementation_id": implementation_id,
                "error": "TIMEOUT",
                "result": None,
                "process_isolated": True,
                "implementation_process_id": implementation_process_id,
                "process_exit_status": exit_status,
                "timeout_status": timeout_status,
                "stderr_tail": (stderr or "")[-500:],
            }

        if not response_path.is_file():
            return {
                "status": "FAILED",
                "implementation_id": implementation_id,
                "error": f"PROCESS_NO_RESPONSE:exit={exit_status}",
                "result": None,
                "process_isolated": True,
                "implementation_process_id": implementation_process_id,
                "process_exit_status": exit_status,
                "timeout_status": timeout_status,
            }

        raw_size = response_path.stat().st_size
        if raw_size > max_output_bytes:
            return {
                "status": "FAILED",
                "implementation_id": implementation_id,
                "error": f"RESOURCE_EXHAUSTION:max_output_bytes:{raw_size}>{max_output_bytes}",
                "result": None,
                "process_isolated": True,
                "implementation_process_id": implementation_process_id,
                "process_exit_status": exit_status,
                "timeout_status": timeout_status,
            }

        try:
            resp_data = read_json(str(response_path))
            resp = ImplementationResponse.from_dict(resp_data)
        except Exception as exc:  # noqa: BLE001
            return {
                "status": "FAILED",
                "implementation_id": implementation_id,
                "error": f"RESPONSE_DECODE:{type(exc).__name__}:{exc}",
                "result": None,
                "process_isolated": True,
                "implementation_process_id": implementation_process_id,
                "process_exit_status": exit_status,
                "timeout_status": timeout_status,
            }

        if resp.status != "COMPLETE" or resp.result is None:
            return {
                "status": "FAILED",
                "implementation_id": implementation_id,
                "error": resp.error or "IMPLEMENTATION_FAILED",
                "result": None,
                "process_isolated": True,
                "implementation_process_id": implementation_process_id,
                "process_exit_status": exit_status,
                "timeout_status": timeout_status,
                "attack_probe": resp.attack_probe,
            }

        result_size = len(
            __import__("json").dumps(resp.result, sort_keys=True, separators=(",", ":")).encode("utf-8")
        )
        if result_size > max_output_bytes:
            return {
                "status": "FAILED",
                "implementation_id": implementation_id,
                "error": f"RESOURCE_EXHAUSTION:max_output_bytes:{result_size}>{max_output_bytes}",
                "result": None,
                "process_isolated": True,
                "implementation_process_id": implementation_process_id,
                "process_exit_status": exit_status,
                "timeout_status": timeout_status,
            }

        output_hash = resp.output_hash or sha256_json(resp.result)
        return {
            "status": "COMPLETE",
            "implementation_id": implementation_id,
            "error": None,
            "result": resp.result,
            "process_isolated": True,
            "implementation_process_id": implementation_process_id,
            "process_exit_status": exit_status,
            "timeout_status": timeout_status,
            "output_hash": output_hash,
            "attack_probe": resp.attack_probe,
        }
    finally:
        # Best-effort staging cleanup
        import shutil

        try:
            shutil.rmtree(staging, ignore_errors=True)
        except OSError:
            pass


def spawn_timestamp() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
