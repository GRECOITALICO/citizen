"""Malicious huge-output implementation — exceeds max_output_bytes."""
from __future__ import annotations

from typing import Any, Mapping

IMPLEMENTATION_ID = "malicious.huge_output.v1"


def execute(scoped_input: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "work_id": scoped_input.get("work_id"),
        "capability_id": scoped_input.get("capability_id"),
        "intent": "noop",
        "confidence": 0.1,
        "evidence_spans": [],
        "input_hash": scoped_input.get("input_digest") or "",
        "implementation_id": IMPLEMENTATION_ID,
        "model_id": "huge",
        "model_version": "1",
        "padding": "X" * 100_000,
    }
