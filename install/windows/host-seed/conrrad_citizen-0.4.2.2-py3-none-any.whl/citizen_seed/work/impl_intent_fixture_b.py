"""Deterministic fixture implementation B for evidence.intent_proposal.

Different implementation_id / model_id / confidence; same capability contract.
"""
from __future__ import annotations

from typing import Any, Mapping

from .capability_contract import INTENT_FIXTURE_B_IMPLEMENTATION_ID, INTENT_PROPOSAL_CAPABILITY_ID
from .implementation_contract import assert_scoped_input_safe
from .proposal import EvidenceSpan, IntentProposal


IMPLEMENTATION_ID = INTENT_FIXTURE_B_IMPLEMENTATION_ID
CAPABILITY_ID = INTENT_PROPOSAL_CAPABILITY_ID
MODEL_ID = "fixture-b"
MODEL_VERSION = "2"


class IntentFixtureB:
    implementation_id = IMPLEMENTATION_ID
    capability_id = CAPABILITY_ID

    def execute(self, scoped_input: Mapping[str, Any]) -> dict[str, Any]:
        assert_scoped_input_safe(scoped_input)
        task = str(scoped_input["task_text"])
        allowed = list(scoped_input.get("allowed_intents") or [])
        intent = "request_review" if "request_review" in allowed else (allowed[0] if allowed else "noop")
        end = min(4, len(task))
        spans = (EvidenceSpan(start=0, end=end, quote=task[:end]),) if end else ()
        proposal = IntentProposal(
            work_id=str(scoped_input["work_id"]),
            capability_id=CAPABILITY_ID,
            intent=intent,
            confidence=0.75,
            evidence_spans=spans,
            input_hash=str(scoped_input["input_digest"]),
            implementation_id=IMPLEMENTATION_ID,
            model_id=MODEL_ID,
            model_version=MODEL_VERSION,
        )
        return proposal.to_dict()


def execute(scoped_input: Mapping[str, Any]) -> dict[str, Any]:
    return IntentFixtureB().execute(scoped_input)
