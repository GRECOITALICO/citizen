"""Independent validator for evidence.history_digest.

Does NOT import the implementation module. Uses citizen_seed.crypto.sha256_file
on the canonical Work history plane — a separate path from hashlib.sha256(read_bytes()).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from citizen_seed.crypto import sha256_file
from citizen_seed.work.capability_contract import HISTORY_DIGEST_VALIDATOR_ID
from citizen_seed.work.history import history_path

VALIDATOR_ID = HISTORY_DIGEST_VALIDATOR_ID


def validate(home: Path, candidate: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    if not isinstance(candidate, dict):
        return {
            "ok": False,
            "result": "REJECT",
            "validator_id": VALIDATOR_ID,
            "validated_outside_implementation": True,
            "errors": ["CANDIDATE_NOT_OBJECT"],
        }

    path = history_path(Path(home))
    if not path.is_file():
        return {
            "ok": False,
            "result": "REJECT",
            "validator_id": VALIDATOR_ID,
            "validated_outside_implementation": True,
            "errors": ["HISTORY_MISSING"],
        }

    expected_hex = sha256_file(path)
    expected_bytes = int(path.stat().st_size)
    expected_digest = f"sha256:{expected_hex}"

    if candidate.get("digest") != expected_digest:
        errors.append("DIGEST_MISMATCH")
    if candidate.get("algorithm") != "sha256":
        errors.append("ALGORITHM_MISMATCH")
    if candidate.get("input_hash") != expected_hex:
        errors.append("INPUT_HASH_MISMATCH")
    if candidate.get("bytes") != expected_bytes:
        errors.append("BYTE_COUNT_MISMATCH")

    ok = len(errors) == 0
    return {
        "ok": ok,
        "result": "ACCEPT" if ok else "REJECT",
        "validator_id": VALIDATOR_ID,
        "validated_outside_implementation": True,
        "expected_digest": expected_digest,
        "expected_bytes": expected_bytes,
        "errors": errors,
    }
