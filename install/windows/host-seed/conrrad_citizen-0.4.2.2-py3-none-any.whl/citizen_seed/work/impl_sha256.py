"""Deterministic SHA-256 implementation — scoped input only (no Citizen object)."""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Mapping

from .implementation_contract import assert_scoped_input_safe

IMPLEMENTATION_ID = "deterministic.sha256"


def execute(scoped_input: Mapping[str, Any]) -> dict[str, Any]:
    """Hash evidence bytes provided by the runtime (side-effect free)."""
    assert_scoped_input_safe(scoped_input)
    payload = scoped_input.get("content_bytes")
    if not isinstance(payload, (bytes, bytearray)):
        raise ValueError("SCOPED_INPUT_MISSING_CONTENT_BYTES")
    digest_hex = hashlib.sha256(bytes(payload)).hexdigest()
    source = str(scoped_input.get("source") or "evidence/evidence.jsonl")
    return {
        "digest": f"sha256:{digest_hex}",
        "algorithm": "sha256",
        "input_hash": digest_hex,
        "bytes": len(payload),
        "source": source,
        "source_present": True,
        "implementation_id": IMPLEMENTATION_ID,
    }


def evidence_path(home: Path) -> Path:
    return Path(home) / "evidence" / "evidence.jsonl"


def run(home: Path) -> dict[str, Any]:
    """Legacy adapter — prefer execute(scoped_input)."""
    path = evidence_path(home)
    if not path.is_file():
        raise FileNotFoundError("EVIDENCE_MISSING: evidence/evidence.jsonl not found")
    return execute({"content_bytes": path.read_bytes(), "source": "evidence/evidence.jsonl"})
