"""Final action surface — runtime-owned; never handed to implementations."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


class FinalAction(Protocol):
    def __call__(self, *, work_id: str, decision: str, payload: dict[str, Any]) -> Any: ...


@dataclass
class FinalActionSpy:
    """Test double — records calls; proves unauthorized paths never invoke it."""

    calls: list[dict[str, Any]] = field(default_factory=list)

    def __call__(self, *, work_id: str, decision: str, payload: dict[str, Any]) -> dict[str, Any]:
        row = {"work_id": work_id, "decision": decision, "payload": dict(payload)}
        self.calls.append(row)
        return {"ok": True, "recorded": row}


def noop_final_action(*, work_id: str, decision: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Default production final action for P0.3A: record-only accept/reject (no side effects)."""
    return {
        "ok": True,
        "work_id": work_id,
        "decision": decision,
        "action": "RECORD_ONLY",
        "payload_keys": sorted(payload.keys()),
    }
