"""Capability registry — capability id stable; implementation bindings replaceable."""
from __future__ import annotations

from typing import Any, Callable, Mapping

from .capability_contract import (
    HISTORY_DIGEST_CAPABILITY_ID,
    INTENT_FIXTURE_A_IMPLEMENTATION_ID,
    INTENT_FIXTURE_B_IMPLEMENTATION_ID,
    INTENT_PROPOSAL_CAPABILITY_ID,
    INTENT_PROPOSAL_VALIDATOR_ID,
    INTEGRITY_DIGEST_CAPABILITY_ID,
    INTEGRITY_DIGEST_IMPLEMENTATION_ID,
    INTEGRITY_DIGEST_VALIDATOR_ID,
    LOCAL_MODEL_IMPLEMENTATION_ID,
    history_digest_contract,
    integrity_digest_contract,
    intent_proposal_contract,
)

# Backward-compatible exports (existing deterministic Work)
CAPABILITY_ID = INTEGRITY_DIGEST_CAPABILITY_ID
CAPABILITY_VERSION = "1.0.0"
WORKER_ID = "evidence-worker"
IMPLEMENTATION_ID = INTEGRITY_DIGEST_IMPLEMENTATION_ID
VALIDATOR_ID = INTEGRITY_DIGEST_VALIDATOR_ID

INTENT_CAPABILITY_ID = INTENT_PROPOSAL_CAPABILITY_ID
INTENT_VALIDATOR_ID = INTENT_PROPOSAL_VALIDATOR_ID
HISTORY_CAPABILITY_ID = HISTORY_DIGEST_CAPABILITY_ID


def capability_spec() -> dict[str, Any]:
    c = integrity_digest_contract()
    return {
        "capability_id": c.capability_id,
        "version": c.version,
        "name": "Evidence Integrity Digest",
        "input_schema": c.input_schema,
        "output_schema": c.output_schema,
        "implementation_id": c.default_implementation_id,
        "validator_id": c.validator_id,
        "worker_id": c.worker_id,
        "implementation_bindings": list(c.implementation_bindings),
        "tools_allowed": list(c.tools_allowed),
        "resource_limits": c.resource_limits,
    }


def intent_capability_spec() -> dict[str, Any]:
    c = intent_proposal_contract()
    return {
        "capability_id": c.capability_id,
        "version": c.version,
        "name": "Evidence Intent Proposal",
        "input_schema": c.input_schema,
        "output_schema": c.output_schema,
        "implementation_id": c.default_implementation_id,
        "validator_id": c.validator_id,
        "worker_id": c.worker_id,
        "implementation_bindings": list(c.implementation_bindings),
        "tools_allowed": list(c.tools_allowed),
        "resource_limits": c.resource_limits,
    }


def history_capability_spec() -> dict[str, Any]:
    c = history_digest_contract()
    return {
        "capability_id": c.capability_id,
        "version": c.version,
        "name": "Work History Digest",
        "input_schema": c.input_schema,
        "output_schema": c.output_schema,
        "implementation_id": c.default_implementation_id,
        "validator_id": c.validator_id,
        "worker_id": c.worker_id,
        "implementation_bindings": list(c.implementation_bindings),
        "tools_allowed": list(c.tools_allowed),
        "resource_limits": c.resource_limits,
        "grant_required": True,
    }


def local_registry() -> dict[str, dict[str, Any]]:
    return {
        CAPABILITY_ID: capability_spec(),
        INTENT_CAPABILITY_ID: intent_capability_spec(),
        HISTORY_CAPABILITY_ID: history_capability_spec(),
    }


def resolve_capability(capability_id: str) -> dict[str, Any] | None:
    return local_registry().get(capability_id)


def resolve_implementation(
    capability_id: str,
    implementation_id: str | None = None,
) -> str | None:
    binding = resolve_capability(capability_id)
    if binding is None:
        return None
    impl = implementation_id or str(binding["implementation_id"])
    allowed = set(binding.get("implementation_bindings") or [binding["implementation_id"]])
    if impl not in allowed:
        return None
    return impl


from .inference_policy import resolve_inference_policy, resolve_work_execution

ImplementationFn = Callable[[Mapping[str, Any]], Mapping[str, Any]]


def default_implementation_table() -> dict[str, ImplementationFn]:
    """In-process table for contract-unit tests only. Production uses child process."""
    from . import impl_intent_fixture_a, impl_intent_fixture_b, impl_local_intent_linear, impl_sha256

    return {
        INTEGRITY_DIGEST_IMPLEMENTATION_ID: impl_sha256.execute,
        INTENT_FIXTURE_A_IMPLEMENTATION_ID: impl_intent_fixture_a.execute,
        INTENT_FIXTURE_B_IMPLEMENTATION_ID: impl_intent_fixture_b.execute,
        LOCAL_MODEL_IMPLEMENTATION_ID: impl_local_intent_linear.execute,
    }
