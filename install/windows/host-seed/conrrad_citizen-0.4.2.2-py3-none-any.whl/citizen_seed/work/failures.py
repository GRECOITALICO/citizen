"""Failure contract — no failure path may change identity/authority/policy or run final action."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


UNKNOWN_CAPABILITY = "UNKNOWN_CAPABILITY"
INVALID_SCHEMA = "INVALID_SCHEMA"
UNKNOWN_INTENT = "UNKNOWN_INTENT"
VALIDATOR_REJECT = "VALIDATOR_REJECT"
MODEL_UNAVAILABLE = "MODEL_UNAVAILABLE"
MODEL_LOAD_FAILURE = "MODEL_LOAD_FAILURE"
TIMEOUT = "TIMEOUT"
RESOURCE_EXHAUSTION = "RESOURCE_EXHAUSTION"
INTEGRITY_FAILURE = "INTEGRITY_FAILURE"
WORKER_FAILURE = "WORKER_FAILURE"
IDENTITY_MISSING = "IDENTITY_MISSING"

STATUS_BLOCKED = "BLOCKED"
STATUS_REJECTED = "REJECTED"
STATUS_FAILED = "FAILED"
STATUS_COMPLETE = "COMPLETE"


@dataclass(frozen=True)
class FailureSpec:
    code: str
    status: str
    may_change_identity: bool = False
    may_change_authority: bool = False
    may_change_policy: bool = False
    may_perform_final_action: bool = False


FAILURE_CATALOG: dict[str, FailureSpec] = {
    UNKNOWN_CAPABILITY: FailureSpec(UNKNOWN_CAPABILITY, STATUS_BLOCKED),
    INVALID_SCHEMA: FailureSpec(INVALID_SCHEMA, STATUS_REJECTED),
    UNKNOWN_INTENT: FailureSpec(UNKNOWN_INTENT, STATUS_REJECTED),
    VALIDATOR_REJECT: FailureSpec(VALIDATOR_REJECT, STATUS_REJECTED),
    MODEL_UNAVAILABLE: FailureSpec(MODEL_UNAVAILABLE, STATUS_FAILED),
    MODEL_LOAD_FAILURE: FailureSpec(MODEL_LOAD_FAILURE, STATUS_FAILED),
    TIMEOUT: FailureSpec(TIMEOUT, STATUS_FAILED),
    RESOURCE_EXHAUSTION: FailureSpec(RESOURCE_EXHAUSTION, STATUS_FAILED),
    INTEGRITY_FAILURE: FailureSpec(INTEGRITY_FAILURE, STATUS_BLOCKED),
    WORKER_FAILURE: FailureSpec(WORKER_FAILURE, STATUS_FAILED),
    IDENTITY_MISSING: FailureSpec(IDENTITY_MISSING, STATUS_BLOCKED),
}


def failure_envelope(code: str, **extra: Any) -> dict[str, Any]:
    spec = FAILURE_CATALOG.get(code) or FailureSpec(code, STATUS_FAILED)
    return {
        "ok": False,
        "status": spec.status,
        "reason": code,
        "may_change_identity": spec.may_change_identity,
        "may_change_authority": spec.may_change_authority,
        "may_change_policy": spec.may_change_policy,
        "may_perform_final_action": spec.may_perform_final_action,
        **extra,
    }
