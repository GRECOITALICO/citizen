"""P0.1/P0.3A Work plane — capability → worker → implementation → validator → decision → evidence → history."""

from .contracts import WorkRequest, WorkResult
from .engine import model_invocations, reset_model_invocation_counter, submit_work
from .registry import (
    CAPABILITY_ID,
    IMPLEMENTATION_ID,
    INTENT_CAPABILITY_ID,
    VALIDATOR_ID,
    WORKER_ID,
    resolve_capability,
    resolve_implementation,
)

__all__ = [
    "WorkRequest",
    "WorkResult",
    "submit_work",
    "resolve_capability",
    "resolve_implementation",
    "CAPABILITY_ID",
    "INTENT_CAPABILITY_ID",
    "WORKER_ID",
    "IMPLEMENTATION_ID",
    "VALIDATOR_ID",
    "model_invocations",
    "reset_model_invocation_counter",
]
