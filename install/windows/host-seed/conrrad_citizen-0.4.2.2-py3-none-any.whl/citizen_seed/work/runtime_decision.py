"""Runtime-owned decision stage — sole authority for ACCEPT/REJECT of proposals."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping


ACCEPT_PROPOSAL = "ACCEPT_PROPOSAL"
REJECT_PROPOSAL = "REJECT_PROPOSAL"


@dataclass(frozen=True)
class RuntimeDecision:
    decision: str  # ACCEPT_PROPOSAL | REJECT_PROPOSAL
    reason: str
    work_id: str
    capability_id: str
    implementation_id: str
    validator_ok: bool
    final_action_authorized: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def decide_from_validation(
    *,
    work_id: str,
    capability_id: str,
    implementation_id: str,
    validation: Mapping[str, Any],
) -> RuntimeDecision:
    """Only runtime decides. Validator never executes final actions."""
    ok = bool(validation.get("ok"))
    if ok:
        return RuntimeDecision(
            decision=ACCEPT_PROPOSAL,
            reason="VALIDATOR_ACCEPT",
            work_id=work_id,
            capability_id=capability_id,
            implementation_id=implementation_id,
            validator_ok=True,
            final_action_authorized=True,
        )
    return RuntimeDecision(
        decision=REJECT_PROPOSAL,
        reason=str(validation.get("reason") or "VALIDATOR_REJECT"),
        work_id=work_id,
        capability_id=capability_id,
        implementation_id=implementation_id,
        validator_ok=False,
        final_action_authorized=False,
    )
