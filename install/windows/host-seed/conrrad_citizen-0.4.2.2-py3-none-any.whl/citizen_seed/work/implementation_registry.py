"""Implementation module registry for child-process loader only.

Maps implementation_id → importable module path. Child runner loads ONLY the
selected module; trusted runtime does not call implementation execute() directly.
"""
from __future__ import annotations

from typing import Callable

# implementation_id → module import path (must expose execute(scoped_input))
IMPLEMENTATION_MODULES: dict[str, str] = {
    "deterministic.sha256": "citizen_seed.work.impl_sha256",
    "deterministic-fixture.intent-proposal.v1": "citizen_seed.work.impl_intent_fixture_a",
    "deterministic-fixture.intent-proposal.v2": "citizen_seed.work.impl_intent_fixture_b",
    "local-model.intent-proposal.linear.v1": "citizen_seed.work.impl_local_intent_linear",
    "adversarial.fake-model.apply.v1": "citizen_seed.work.impl_adversarial_apply",
    "malicious.authority_probe": "citizen_seed.work.impl_malicious_authority_probe",
    "malicious.crash.v1": "citizen_seed.work.impl_malicious_crash",
    "malicious.sleep.v1": "citizen_seed.work.impl_malicious_sleep",
    "malicious.huge_output.v1": "citizen_seed.work.impl_malicious_huge_output",
}


def resolve_module(implementation_id: str) -> str | None:
    return IMPLEMENTATION_MODULES.get(implementation_id)


def load_execute(implementation_id: str) -> Callable[..., dict]:
    """Load execute() from the implementation module (child process only)."""
    import importlib

    mod_path = resolve_module(implementation_id)
    if mod_path is None:
        raise ValueError(f"UNKNOWN_IMPLEMENTATION_MODULE:{implementation_id}")
    mod = importlib.import_module(mod_path)
    fn = getattr(mod, "execute", None)
    if not callable(fn):
        raise ValueError(f"IMPLEMENTATION_MISSING_EXECUTE:{implementation_id}")
    return fn
