"""Capability contract — stable capability identity vs replaceable implementations."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class CapabilityContract:
    """Smallest explicit capability contract.

    Capability id stays stable while implementation bindings may change.
    """

    capability_id: str
    version: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    validator_id: str
    implementation_bindings: tuple[str, ...]
    default_implementation_id: str
    worker_id: str = "evidence-worker"
    tools_allowed: tuple[str, ...] = ()
    resource_limits: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --- Existing deterministic capability (kept) ---

INTEGRITY_DIGEST_CAPABILITY_ID = "evidence.integrity_digest"
INTEGRITY_DIGEST_VALIDATOR_ID = "evidence.integrity_digest.validator"
INTEGRITY_DIGEST_IMPLEMENTATION_ID = "deterministic.sha256"

# History-plane digest — same implementation, different source. Unlockable by a
# signed capability_grant asset delivered through Sync (evolution 0.4.3).
HISTORY_DIGEST_CAPABILITY_ID = "evidence.history_digest"
HISTORY_DIGEST_VALIDATOR_ID = "evidence.history_digest.validator"
HISTORY_DIGEST_GRANT_ASSET_ID = "capability_grant.evidence.history_digest"

# --- Intent proposal capability ---

INTENT_PROPOSAL_CAPABILITY_ID = "evidence.intent_proposal"
INTENT_PROPOSAL_VALIDATOR_ID = "evidence.intent_proposal.validator"
LOCAL_MODEL_IMPLEMENTATION_ID = "local-model.intent-proposal.linear.v1"
# Alias kept for older tests/docs
FUTURE_LOCAL_MODEL_IMPLEMENTATION_ID = LOCAL_MODEL_IMPLEMENTATION_ID
# Fixture implementations for substitution / boundary tests:
INTENT_FIXTURE_A_IMPLEMENTATION_ID = "deterministic-fixture.intent-proposal.v1"
INTENT_FIXTURE_B_IMPLEMENTATION_ID = "deterministic-fixture.intent-proposal.v2"

ALLOWED_INTENTS: tuple[str, ...] = (
    "summarize",
    "flag_anomaly",
    "noop",
    "request_review",
    "ABSTAIN",
)


def integrity_digest_contract() -> CapabilityContract:
    return CapabilityContract(
        capability_id=INTEGRITY_DIGEST_CAPABILITY_ID,
        version="1.0.0",
        input_schema={
            "type": "object",
            "properties": {
                "source": {
                    "type": "string",
                    "enum": ["evidence.jsonl", "evidence/evidence.jsonl"],
                },
            },
            "required": ["source"],
            "additionalProperties": False,
        },
        output_schema={
            "type": "object",
            "properties": {
                "digest": {"type": "string"},
                "algorithm": {"type": "string"},
                "input_hash": {"type": "string"},
                "bytes": {"type": "integer"},
                "source": {"type": "string"},
            },
            "required": ["digest", "algorithm", "input_hash", "bytes"],
        },
        validator_id=INTEGRITY_DIGEST_VALIDATOR_ID,
        implementation_bindings=(INTEGRITY_DIGEST_IMPLEMENTATION_ID,),
        default_implementation_id=INTEGRITY_DIGEST_IMPLEMENTATION_ID,
        tools_allowed=(),
        resource_limits={
            "max_input_bytes": 8_388_608,
            "max_output_bytes": 65_536,
            "max_evidence_spans": 0,
            "timeout_ms": 5_000,
            "enforcement": {
                "max_input_bytes": "ENFORCED",
                "max_output_bytes": "ENFORCED",
                "max_evidence_spans": "ENFORCED",
                "timeout_ms": "ENFORCED",
                "memory_limit": "NOT_IMPLEMENTED",
            },
        },
    )


def history_digest_contract() -> CapabilityContract:
    """Deterministic digest of the canonical Work history plane."""
    return CapabilityContract(
        capability_id=HISTORY_DIGEST_CAPABILITY_ID,
        version="1.0.0",
        input_schema={
            "type": "object",
            "properties": {
                "source": {
                    "type": "string",
                    "enum": [
                        "canonical_work_history.jsonl",
                        "ops/canonical_work_history.jsonl",
                    ],
                },
            },
            "required": ["source"],
            "additionalProperties": False,
        },
        output_schema={
            "type": "object",
            "properties": {
                "digest": {"type": "string"},
                "algorithm": {"type": "string"},
                "input_hash": {"type": "string"},
                "bytes": {"type": "integer"},
                "source": {"type": "string"},
            },
            "required": ["digest", "algorithm", "input_hash", "bytes"],
        },
        validator_id=HISTORY_DIGEST_VALIDATOR_ID,
        implementation_bindings=(INTEGRITY_DIGEST_IMPLEMENTATION_ID,),
        default_implementation_id=INTEGRITY_DIGEST_IMPLEMENTATION_ID,
        tools_allowed=(),
        resource_limits={
            "max_input_bytes": 8_388_608,
            "max_output_bytes": 65_536,
            "max_evidence_spans": 0,
            "timeout_ms": 5_000,
            "enforcement": {
                "max_input_bytes": "ENFORCED",
                "max_output_bytes": "ENFORCED",
                "max_evidence_spans": "ENFORCED",
                "timeout_ms": "ENFORCED",
                "memory_limit": "NOT_IMPLEMENTED",
            },
        },
    )


def intent_proposal_contract() -> CapabilityContract:
    return CapabilityContract(
        capability_id=INTENT_PROPOSAL_CAPABILITY_ID,
        version="1.0.0",
        input_schema={
            "type": "object",
            "properties": {
                "work_id": {"type": "string"},
                "capability_id": {"type": "string"},
                "task_text": {"type": "string"},
                "allowed_intents": {
                    "type": "array",
                    "items": {"type": "string"},
                },
                "input_digest": {"type": "string"},
                "language": {"type": "string"},
            },
            "required": [
                "work_id",
                "capability_id",
                "task_text",
                "allowed_intents",
                "input_digest",
            ],
            "additionalProperties": False,
        },
        output_schema={
            "type": "object",
            "properties": {
                "work_id": {"type": "string"},
                "capability_id": {"type": "string"},
                "intent": {"type": "string"},
                "confidence": {"type": "number"},
                "evidence_spans": {"type": "array"},
                "input_hash": {"type": "string"},
                "implementation_id": {"type": "string"},
                "model_id": {"type": "string"},
                "model_version": {"type": "string"},
            },
            "required": [
                "work_id",
                "capability_id",
                "intent",
                "confidence",
                "evidence_spans",
                "input_hash",
                "implementation_id",
                "model_id",
                "model_version",
            ],
        },
        validator_id=INTENT_PROPOSAL_VALIDATOR_ID,
        implementation_bindings=(
            LOCAL_MODEL_IMPLEMENTATION_ID,
            INTENT_FIXTURE_A_IMPLEMENTATION_ID,
            INTENT_FIXTURE_B_IMPLEMENTATION_ID,
        ),
        default_implementation_id=INTENT_FIXTURE_A_IMPLEMENTATION_ID,
        tools_allowed=(),  # TOOLS_ALLOWED = NONE
        resource_limits={
            "max_input_bytes": 8_192,
            "max_output_bytes": 8_192,
            "max_evidence_spans": 8,
            "timeout_ms": 2_000,
            "enforcement": {
                "max_input_bytes": "ENFORCED",
                "max_output_bytes": "ENFORCED",
                "max_evidence_spans": "ENFORCED",
                "timeout_ms": "ENFORCED",
                "memory_limit": "NOT_IMPLEMENTED",
            },
        },
    )
