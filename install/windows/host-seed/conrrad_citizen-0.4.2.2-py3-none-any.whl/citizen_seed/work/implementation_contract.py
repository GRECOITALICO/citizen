"""Side-effect-free implementation interface.

Implementation.execute(input) -> Proposal|dict

Implementations MUST NOT receive writers for identity, history, evidence,
capability registry, policy, or final-action execution.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol, runtime_checkable

# Explicit denylist of keys that must never appear on scoped implementation input.
FORBIDDEN_SCOPED_INPUT_KEYS: frozenset[str] = frozenset(
    {
        "identity",
        "identity_writer",
        "history",
        "history_writer",
        "evidence",
        "evidence_writer",
        "capability_registry",
        "registry_mutator",
        "policy",
        "policy_mutator",
        "final_action",
        "final_action_executor",
        "citizen",
        "citizen_object",
        "home",
        "filesystem",
        "credentials",
        "environment",
        "env",
        "runtime_config",
        "tools",
        "mcp",
    }
)


@runtime_checkable
class Implementation(Protocol):
    """Capability implementation: pure function over scoped input."""

    implementation_id: str
    capability_id: str

    def execute(self, scoped_input: Mapping[str, Any]) -> Mapping[str, Any]:
        """Return proposal/result DATA only. No side effects."""


@dataclass(frozen=True)
class ImplementationContract:
    implementation_id: str
    capability_id: str
    side_effects: str = "NONE"
    tools_allowed: tuple[str, ...] = ()
    receives_citizen_object: bool = False
    may_write_evidence: bool = False
    may_write_history: bool = False
    may_mutate_identity: bool = False
    may_mutate_policy: bool = False
    may_execute_final_action: bool = False


def assert_scoped_input_safe(scoped_input: Mapping[str, Any]) -> None:
    """Reject undeclared authority surfaces on implementation input."""
    bad = FORBIDDEN_SCOPED_INPUT_KEYS.intersection(scoped_input.keys())
    if bad:
        raise ValueError(f"FORBIDDEN_SCOPED_INPUT:{','.join(sorted(bad))}")
