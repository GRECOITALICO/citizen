"""Pure-Python multiclass linear intent classifier (stdlib only)."""
from __future__ import annotations

import math
import re
import time
from collections import Counter
from typing import Any

TOKEN_RE = re.compile(r"[a-z0-9_]+")


def tokenize(text: str) -> list[str]:
    return TOKEN_RE.findall(text.lower())


def softmax(logits: list[float]) -> list[float]:
    m = max(logits) if logits else 0.0
    exps = [math.exp(x - m) for x in logits]
    s = sum(exps) or 1.0
    return [e / s for e in exps]


class IntentLinearModel:
    """Loaded multiclass linear classifier."""

    def __init__(self, artifact: dict[str, Any]):
        self.model_id = str(artifact["model_id"])
        self.model_version = str(artifact["model_version"])
        self.algorithm = str(artifact.get("algorithm") or "multiclass-linear")
        self.artifact_hash = str(artifact["artifact_hash"])
        self.parameters_hash = str(artifact["parameters_hash"])
        params = artifact["parameters"]
        self.labels: list[str] = list(params["labels"])
        self.vocab: list[str] = list(params["vocab"])
        self.vocab_index = {t: i for i, t in enumerate(self.vocab)}
        self.weights: list[list[float]] = params["weights"]
        self.bias: list[float] = list(params["bias"])
        self.abstain_threshold = float(params.get("abstain_confidence_threshold") or 0.28)
        self.n_feat = len(self.vocab)
        self.n_lab = len(self.labels)
        if len(self.weights) != self.n_lab or any(len(row) != self.n_feat for row in self.weights):
            raise ValueError("MODEL_SCHEMA:weights_shape")
        if len(self.bias) != self.n_lab:
            raise ValueError("MODEL_SCHEMA:bias_shape")

    def vectorize(self, text: str) -> list[float]:
        counts = Counter(tokenize(text))
        vec = [0.0] * self.n_feat
        for tok, c in counts.items():
            idx = self.vocab_index.get(tok)
            if idx is not None:
                vec[idx] = float(c)
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]

    def predict(
        self,
        task_text: str,
        *,
        allowed_intents: list[str] | tuple[str, ...],
    ) -> dict[str, Any]:
        t0 = time.perf_counter()
        x = self.vectorize(task_text)
        logits = [
            self.bias[j] + sum(self.weights[j][k] * x[k] for k in range(self.n_feat))
            for j in range(self.n_lab)
        ]
        probs = softmax(logits)
        # Restrict to intersection of model labels and allowed intents (+ ABSTAIN always)
        allowed = set(allowed_intents) | {"ABSTAIN"}
        candidates = [(i, probs[i]) for i, lab in enumerate(self.labels) if lab in allowed]
        if not candidates:
            intent = "ABSTAIN"
            confidence = 1.0
            chosen_i = self.labels.index("ABSTAIN") if "ABSTAIN" in self.labels else 0
        else:
            chosen_i, confidence = max(candidates, key=lambda t: t[1])
            intent = self.labels[chosen_i]
            if confidence < self.abstain_threshold and "ABSTAIN" in allowed:
                intent = "ABSTAIN"
                if "ABSTAIN" in self.labels:
                    confidence = probs[self.labels.index("ABSTAIN")]
                else:
                    confidence = float(1.0 - confidence)

        # Evidence spans: top contributing tokens present in text
        spans = self._evidence_spans(task_text, chosen_i)
        inference_ms = (time.perf_counter() - t0) * 1000.0
        return {
            "intent": intent,
            "confidence": float(confidence),
            "evidence_spans": spans,
            "logits": logits,
            "probs": {self.labels[i]: probs[i] for i in range(self.n_lab)},
            "inference_time_ms": round(inference_ms, 3),
            "input_bytes": len(task_text.encode("utf-8")),
        }

    def _evidence_spans(self, task_text: str, label_i: int) -> list[dict[str, Any]]:
        text_l = task_text.lower()
        contrib: list[tuple[float, str, int, int]] = []
        for m in TOKEN_RE.finditer(text_l):
            tok = m.group(0)
            idx = self.vocab_index.get(tok)
            if idx is None:
                continue
            score = self.weights[label_i][idx]
            if score <= 0:
                continue
            contrib.append((score, tok, m.start(), m.end()))
        contrib.sort(reverse=True)
        spans: list[dict[str, Any]] = []
        for _score, _tok, start, end in contrib[:3]:
            # Map back to original text offsets (same length for ascii-ish tasks)
            quote = task_text[start:end]
            spans.append({"start": start, "end": end, "quote": quote})
        return spans
