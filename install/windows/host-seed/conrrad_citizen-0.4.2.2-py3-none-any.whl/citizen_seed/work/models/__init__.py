"""Local intent model package — stdlib-only inference, no control-plane writers."""

from .loader import LocalIntentModelLoader, ModelLoadError
from .inference import IntentLinearModel

__all__ = [
    "LocalIntentModelLoader",
    "ModelLoadError",
    "IntentLinearModel",
]
