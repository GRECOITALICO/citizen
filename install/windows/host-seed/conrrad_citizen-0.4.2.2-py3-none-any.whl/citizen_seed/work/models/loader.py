"""LocalIntentModelLoader — load + verify model artifact; no control-plane access."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

from .inference import IntentLinearModel

REQUIRED_FIELDS = (
    "model_id",
    "model_version",
    "model_format",
    "algorithm",
    "label_set",
    "feature_specification",
    "parameters",
    "parameters_hash",
    "artifact_hash",
)

DEFAULT_ARTIFACT_NAME = "citizen-intent-linear-v1.0.0.json"


class ModelLoadError(Exception):
    """Raised when artifact is missing, corrupt, or schema-invalid."""

    def __init__(self, code: str, detail: str = ""):
        self.code = code
        super().__init__(f"{code}:{detail}" if detail else code)


def default_artifact_path() -> Path:
    return Path(__file__).resolve().parent / "artifacts" / DEFAULT_ARTIFACT_NAME


def compute_parameters_hash(parameters: dict[str, Any]) -> str:
    raw = json.dumps(parameters, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def canonical_artifact_body(data: dict[str, Any]) -> str:
    """Canonical artifact document bytes excluding the self-referential artifact_hash field."""
    body = {k: v for k, v in data.items() if k != "artifact_hash"}
    return json.dumps(body, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def canonical_artifact_file(data: dict[str, Any]) -> str:
    """Canonical on-disk artifact representation including artifact_hash."""
    return json.dumps(data, sort_keys=True, indent=2, ensure_ascii=False) + "\n"


def compute_artifact_hash(data: dict[str, Any]) -> str:
    """SHA-256 of the complete canonical artifact document (excluding artifact_hash)."""
    return hashlib.sha256(canonical_artifact_body(data).encode("utf-8")).hexdigest()


def verify_artifact_record(raw: bytes, data: dict[str, Any]) -> None:
    """Verify complete artifact bytes and both hash fields."""
    if not isinstance(data, dict):
        raise ModelLoadError("MODEL_LOAD_FAILURE", "not_object")
    for field in REQUIRED_FIELDS:
        if field not in data:
            raise ModelLoadError("MODEL_LOAD_FAILURE", f"missing:{field}")
    expected_file = canonical_artifact_file(data)
    if raw.decode("utf-8") != expected_file:
        raise ModelLoadError("MODEL_LOAD_FAILURE", "artifact_bytes_mismatch")
    expected_params = str(data["parameters_hash"])
    got_params = compute_parameters_hash(dict(data["parameters"]))
    if got_params != expected_params:
        raise ModelLoadError("MODEL_LOAD_FAILURE", f"parameters_hash_mismatch:{got_params}!={expected_params}")
    expected_art = str(data["artifact_hash"])
    got_art = compute_artifact_hash(data)
    if got_art != expected_art:
        raise ModelLoadError("MODEL_LOAD_FAILURE", f"artifact_hash_mismatch:{got_art}!={expected_art}")


def read_verified_artifact_record(path: Path) -> dict[str, str]:
    """Read + verify artifact identity without constructing inference object."""
    if not path.is_file():
        raise ModelLoadError("MODEL_UNAVAILABLE", str(path))
    try:
        raw = path.read_bytes()
        data = json.loads(raw.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ModelLoadError("MODEL_LOAD_FAILURE", f"corrupt:{exc}") from exc
    verify_artifact_record(raw, data)
    return {
        "model_id": str(data["model_id"]),
        "model_version": str(data["model_version"]),
        "artifact_hash": str(data["artifact_hash"]),
        "parameters_hash": str(data["parameters_hash"]),
    }


class LocalIntentModelLoader:
    """Locate, verify, and construct IntentLinearModel. No identity/history/evidence."""

    def __init__(self, artifact_path: Path | None = None):
        self.artifact_path = Path(artifact_path) if artifact_path else default_artifact_path()

    def load(self) -> tuple[IntentLinearModel, dict[str, Any]]:
        t0 = time.perf_counter()
        path = self.artifact_path
        if not path.is_file():
            raise ModelLoadError("MODEL_UNAVAILABLE", str(path))
        try:
            raw = path.read_bytes()
            data = json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ModelLoadError("MODEL_LOAD_FAILURE", f"corrupt:{exc}") from exc
        verify_artifact_record(raw, data)
        if data.get("model_format") != "json-linear-v1":
            raise ModelLoadError("MODEL_LOAD_FAILURE", "bad_format")
        if data.get("algorithm") != "multiclass-linear":
            raise ModelLoadError("MODEL_LOAD_FAILURE", "bad_algorithm")
        try:
            model = IntentLinearModel(data)
        except ValueError as exc:
            raise ModelLoadError("MODEL_LOAD_FAILURE", str(exc)) from exc
        load_ms = (time.perf_counter() - t0) * 1000.0
        meta = {
            "model_id": model.model_id,
            "model_version": model.model_version,
            "model_artifact_hash": model.artifact_hash,
            "model_parameters_hash": model.parameters_hash,
            "model_load_time_ms": round(load_ms, 3),
            "artifact_path": str(path),
            "artifact_bytes": len(raw),
        }
        return model, meta
