"""IPC contracts for trusted runtime ↔ untrusted implementation process.

All payloads are JSON-serializable. No callbacks, no runtime object references.
"""
from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Mapping


def _json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_json(obj: Any) -> str:
    return hashlib.sha256(_json_bytes(obj)).hexdigest()


def _encode_scoped_input(scoped: Mapping[str, Any]) -> dict[str, Any]:
    """Make scoped input JSON-safe (bytes → base64)."""
    out: dict[str, Any] = {}
    for key, value in scoped.items():
        if isinstance(value, (bytes, bytearray)):
            out[key] = {"__bytes_b64__": base64.b64encode(bytes(value)).decode("ascii")}
        elif isinstance(value, list):
            out[key] = value
        elif isinstance(value, dict):
            out[key] = dict(value)
        else:
            out[key] = value
    return out


def _decode_scoped_input(scoped: Mapping[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in scoped.items():
        if isinstance(value, dict) and "__bytes_b64__" in value:
            out[key] = base64.b64decode(str(value["__bytes_b64__"]))
        else:
            out[key] = value
    return out


@dataclass(frozen=True)
class ImplementationRequest:
    work_id: str
    capability_id: str
    implementation_id: str
    scoped_input: dict[str, Any]
    resource_limits: dict[str, Any]
    request_timestamp: str
    deadline_ms: int | None = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["scoped_input"] = _encode_scoped_input(self.scoped_input)
        return d

    @staticmethod
    def from_dict(data: Mapping[str, Any]) -> ImplementationRequest:
        scoped_raw = dict(data.get("scoped_input") or {})
        return ImplementationRequest(
            work_id=str(data["work_id"]),
            capability_id=str(data["capability_id"]),
            implementation_id=str(data["implementation_id"]),
            scoped_input=_decode_scoped_input(scoped_raw),
            resource_limits=dict(data.get("resource_limits") or {}),
            request_timestamp=str(data.get("request_timestamp") or ""),
            deadline_ms=data.get("deadline_ms"),
        )

    def serialized_byte_length(self) -> int:
        return len(_json_bytes(self.to_dict()))


@dataclass
class ImplementationResponse:
    status: str  # COMPLETE | FAILED
    implementation_id: str
    result: dict[str, Any] | None = None
    output_hash: str = ""
    error: str | None = None
    attack_probe: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: Mapping[str, Any]) -> ImplementationResponse:
        return ImplementationResponse(
            status=str(data.get("status") or "FAILED"),
            implementation_id=str(data.get("implementation_id") or ""),
            result=dict(data["result"]) if data.get("result") is not None else None,
            output_hash=str(data.get("output_hash") or ""),
            error=data.get("error"),
            attack_probe=dict(data["attack_probe"]) if data.get("attack_probe") else None,
        )

    def finalize_hashes(self) -> None:
        if self.result is not None and not self.output_hash:
            self.output_hash = sha256_json(self.result)


def write_json(path: str, payload: Mapping[str, Any]) -> None:
    from pathlib import Path

    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(dict(payload), sort_keys=True, separators=(",", ":")), encoding="utf-8")


def read_json(path: str) -> dict[str, Any]:
    from pathlib import Path

    return json.loads(Path(path).read_text(encoding="utf-8"))
