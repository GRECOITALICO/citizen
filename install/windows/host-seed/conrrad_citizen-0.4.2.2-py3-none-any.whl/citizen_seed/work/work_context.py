"""Explicit WorkContext for runtime inference-need policy — not passed to models."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping

from .capability_contract import (
    HISTORY_DIGEST_CAPABILITY_ID,
    INTENT_PROPOSAL_CAPABILITY_ID,
    INTEGRITY_DIGEST_CAPABILITY_ID,
)

TASK_CLASS_DETERMINISTIC = "DETERMINISTIC"
TASK_CLASS_SEMANTIC_INTERPRETATION = "SEMANTIC_INTERPRETATION"

ALLOWED_TASK_CLASSES: frozenset[str] = frozenset(
    {TASK_CLASS_DETERMINISTIC, TASK_CLASS_SEMANTIC_INTERPRETATION}
)

WORK_CONTEXT_FIELDS: frozenset[str] = frozenset(
    {"task_class", "task_metadata", "requested_mode"}
)


@dataclass(frozen=True)
class WorkContext:
    work_id: str
    capability_id: str
    task_class: str
    task_metadata: dict[str, Any]
    requested_mode: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def parse_work_context(
    *,
    work_id: str,
    capability_id: str,
    input_payload: Mapping[str, Any] | None,
) -> WorkContext:
    """Build runtime WorkContext from declared request metadata only."""
    if capability_id in {INTEGRITY_DIGEST_CAPABILITY_ID, HISTORY_DIGEST_CAPABILITY_ID}:
        return WorkContext(
            work_id=work_id,
            capability_id=capability_id,
            task_class=TASK_CLASS_DETERMINISTIC,
            task_metadata={},
            requested_mode="default",
        )

    if capability_id != INTENT_PROPOSAL_CAPABILITY_ID:
        raise ValueError(f"UNKNOWN_CAPABILITY:{capability_id}")

    raw = dict(input_payload or {})
    task_class = str(raw.get("task_class") or TASK_CLASS_DETERMINISTIC)
    if task_class not in ALLOWED_TASK_CLASSES:
        raise ValueError(f"INVALID_TASK_CLASS:{task_class}")

    task_metadata = raw.get("task_metadata") or {}
    if not isinstance(task_metadata, dict):
        raise ValueError("INVALID_TASK_METADATA")

    requested_mode = str(raw.get("requested_mode") or "default")
    return WorkContext(
        work_id=work_id,
        capability_id=capability_id,
        task_class=task_class,
        task_metadata=dict(task_metadata),
        requested_mode=requested_mode,
    )


def strip_work_context_fields(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Remove WorkContext fields before building model/capability scoped input."""
    return {k: v for k, v in raw.items() if k not in WORK_CONTEXT_FIELDS}
