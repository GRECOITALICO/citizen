"""Work engine: WorkContext → inference need → implementation → validator → evidence → history.

P0.3B.2: inference need is decided from WorkContext before implementation selection.
"""
from __future__ import annotations

import hashlib
import json
import time
import uuid
from pathlib import Path
from typing import Any

from citizen_seed.evidence import append as evidence_append
from citizen_seed.identity import load as load_identity
from citizen_seed.paths import layout

from . import validator as work_validator
from . import validator_history
from . import validator_intent
from .capability_contract import (
    ALLOWED_INTENTS,
    HISTORY_DIGEST_CAPABILITY_ID,
    INTENT_PROPOSAL_CAPABILITY_ID,
    INTEGRITY_DIGEST_CAPABILITY_ID,
)
from .context import digest_task_text, parse_intent_proposal_input
from .contracts import WorkRequest, WorkResult
from .failures import INVALID_SCHEMA, MODEL_UNAVAILABLE, RESOURCE_EXHAUSTION, failure_envelope
from .final_action import FinalAction, noop_final_action
from .history import HISTORY_NAME, append_history, history_path
from .inference_policy import resolve_work_execution
from .registry import (
    CAPABILITY_ID,
    VALIDATOR_ID,
    WORKER_ID,
    resolve_capability,
    resolve_implementation,
)
from .resources import (
    INTEGRITY_DIGEST_LIMITS,
    INTENT_PROPOSAL_LIMITS,
    check_evidence_spans,
    check_input_bytes,
    check_output_bytes,
)
from .runtime_decision import ACCEPT_PROPOSAL, decide_from_validation
from .work_context import parse_work_context, strip_work_context_fields
from .worker import BLOCKED, COMPLETE, FAILED, EvidenceWorker, default_worker

MODEL_INVOCATIONS = 0


def reset_model_invocation_counter() -> None:
    global MODEL_INVOCATIONS
    MODEL_INVOCATIONS = 0


def model_invocations() -> int:
    return MODEL_INVOCATIONS


def _note_model_invocation(inference_required: bool) -> None:
    global MODEL_INVOCATIONS
    if inference_required:
        MODEL_INVOCATIONS += 1


def _utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _sha256_json(obj: Any) -> str:
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _citizen_id(home: Path) -> str:
    return load_identity(layout(home)["identity"]).citizen_id


def _validate_digest_input(input_payload: Any) -> tuple[bool, str]:
    if input_payload is None:
        input_payload = {"source": "evidence.jsonl"}
    if not isinstance(input_payload, dict):
        return False, "INVALID_INPUT"
    source = input_payload.get("source", "evidence.jsonl")
    if source not in {"evidence.jsonl", "evidence/evidence.jsonl"}:
        return False, "INVALID_INPUT_SOURCE"
    return True, ""


def _validate_history_input(input_payload: Any) -> tuple[bool, str]:
    if input_payload is None:
        input_payload = {"source": "canonical_work_history.jsonl"}
    if not isinstance(input_payload, dict):
        return False, "INVALID_INPUT"
    source = input_payload.get("source", "canonical_work_history.jsonl")
    if source not in {"canonical_work_history.jsonl", "ops/canonical_work_history.jsonl"}:
        return False, "INVALID_INPUT_SOURCE"
    return True, ""


def _prepare_history_scoped(
    home: Path,
    *,
    work_id: str,
    capability_id: str,
) -> tuple[dict[str, Any] | None, str | None]:
    path = history_path(home)
    if not path.is_file():
        path.write_text("", encoding="utf-8")
    content = path.read_bytes()
    err = check_input_bytes(content, INTEGRITY_DIGEST_LIMITS)
    if err:
        return None, err
    return {
        "work_id": work_id,
        "capability_id": capability_id,
        "content_bytes": content,
        "source": f"ops/{HISTORY_NAME}",
    }, None


def _prepare_digest_scoped(
    home: Path,
    *,
    work_id: str,
    capability_id: str,
) -> tuple[dict[str, Any] | None, str | None]:
    path = layout(home)["evidence"] / "evidence.jsonl"
    if not path.is_file():
        return None, "EVIDENCE_MISSING"
    content = path.read_bytes()
    err = check_input_bytes(content, INTEGRITY_DIGEST_LIMITS)
    if err:
        return None, err
    return {
        "work_id": work_id,
        "capability_id": capability_id,
        "content_bytes": content,
        "source": "evidence/evidence.jsonl",
    }, None


def _prepare_intent_scoped(
    *,
    work_id: str,
    capability_id: str,
    input_payload: dict[str, Any] | None,
) -> tuple[dict[str, Any] | None, str | None]:
    raw = dict(input_payload or {})
    if "task_text" not in raw and "text" in raw:
        raw["task_text"] = raw.pop("text")
    raw = strip_work_context_fields(raw)
    raw.setdefault("work_id", work_id)
    raw.setdefault("capability_id", capability_id)
    raw.setdefault("allowed_intents", list(ALLOWED_INTENTS))
    if "input_digest" not in raw:
        raw["input_digest"] = digest_task_text(str(raw.get("task_text") or ""))
    try:
        parsed = parse_intent_proposal_input(raw)
    except ValueError as exc:
        return None, f"{INVALID_SCHEMA}:{exc}"
    err = check_input_bytes(parsed.task_text, INTENT_PROPOSAL_LIMITS)
    if err:
        return None, err
    return parsed.to_dict(), None


def submit_work(
    home: Path,
    *,
    capability_id: str = CAPABILITY_ID,
    input_payload: dict[str, Any] | None = None,
    worker: EvidenceWorker | None = None,
    force_worker_failure: bool = False,
    force_validator_reject: bool = False,
    implementation_id: str | None = None,
    final_action: FinalAction | None = None,
) -> dict[str, Any]:
    """Public Work entry for POST /api/work and CLI."""
    home = Path(home).resolve()
    created = _utc_now()
    action = final_action or noop_final_action

    if not capability_id or not isinstance(capability_id, str):
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": "INVALID_CAPABILITY_ID",
            "capability_id": capability_id,
        }

    binding = resolve_capability(capability_id)
    if binding is None:
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": "UNKNOWN_CAPABILITY",
            "capability_id": capability_id,
        }

    from .capability_state import capability_unlocked

    if not capability_unlocked(home, capability_id):
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": "CAPABILITY_MISSING",
            "capability_id": capability_id,
        }

    if capability_id == INTEGRITY_DIGEST_CAPABILITY_ID:
        ok_in, reason_in = _validate_digest_input(input_payload)
        if not ok_in:
            return {
                "ok": False,
                "status": BLOCKED,
                "reason": reason_in,
                "capability_id": capability_id,
            }
    elif capability_id == HISTORY_DIGEST_CAPABILITY_ID:
        ok_in, reason_in = _validate_history_input(input_payload)
        if not ok_in:
            return {
                "ok": False,
                "status": BLOCKED,
                "reason": reason_in,
                "capability_id": capability_id,
            }
    elif capability_id == INTENT_PROPOSAL_CAPABILITY_ID:
        if input_payload is not None and not isinstance(input_payload, dict):
            return {
                "ok": False,
                "status": "REJECTED",
                "reason": INVALID_SCHEMA,
                "capability_id": capability_id,
            }
    else:
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": "UNKNOWN_CAPABILITY",
            "capability_id": capability_id,
        }

    try:
        citizen_id = _citizen_id(home)
    except FileNotFoundError:
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": "IDENTITY_MISSING",
            "capability_id": capability_id,
        }

    work_id = f"work_{uuid.uuid4().hex[:12]}"
    run_id = f"run_{uuid.uuid4().hex[:12]}"
    if capability_id == INTEGRITY_DIGEST_CAPABILITY_ID:
        payload_in = dict(input_payload or {"source": "evidence.jsonl"})
    elif capability_id == HISTORY_DIGEST_CAPABILITY_ID:
        payload_in = dict(input_payload or {"source": "canonical_work_history.jsonl"})
    else:
        payload_in = dict(input_payload or {"task_text": "noop"})

    request = WorkRequest(
        work_id=work_id,
        citizen_id=citizen_id,
        capability_id=capability_id,
        input=payload_in,
        created_at=created,
    )

    try:
        work_context = parse_work_context(
            work_id=work_id,
            capability_id=capability_id,
            input_payload=payload_in,
        )
    except ValueError as exc:
        return {
            "ok": False,
            "status": "REJECTED",
            "reason": f"{INVALID_SCHEMA}:{exc}",
            "capability_id": capability_id,
            "work_id": work_id,
            "run_id": run_id,
            "model_invocations": MODEL_INVOCATIONS,
            "final_action_called": False,
        }

    execution = resolve_work_execution(
        work_context,
        implementation_id,
        resolve_implementation=resolve_implementation,
    )
    if execution is None:
        code = (
            MODEL_UNAVAILABLE
            if capability_id == INTENT_PROPOSAL_CAPABILITY_ID
            and work_context.task_class == "SEMANTIC_INTERPRETATION"
            else "UNKNOWN_IMPLEMENTATION"
        )
        env = failure_envelope(
            code, capability_id=capability_id, implementation_id=implementation_id
        )
        env.update({"work_id": work_id, "run_id": run_id, "final_action_called": False})
        return env

    implementation_id = execution.implementation_id
    inference_decision = execution.inference_decision
    inference_required = inference_decision.inference_required
    inference_reason = inference_decision.reason
    policy_version = inference_decision.policy_version
    authorized_model = execution.authorized_model
    validator_id = str(binding["validator_id"])
    worker_id = str(binding.get("worker_id") or WORKER_ID)
    worker = worker or default_worker()
    limits = (
        INTENT_PROPOSAL_LIMITS
        if capability_id == INTENT_PROPOSAL_CAPABILITY_ID
        else INTEGRITY_DIGEST_LIMITS
    )

    if capability_id == INTEGRITY_DIGEST_CAPABILITY_ID:
        scoped, prep_err = _prepare_digest_scoped(
            home, work_id=work_id, capability_id=capability_id
        )
    elif capability_id == HISTORY_DIGEST_CAPABILITY_ID:
        scoped, prep_err = _prepare_history_scoped(
            home, work_id=work_id, capability_id=capability_id
        )
    else:
        scoped, prep_err = _prepare_intent_scoped(
            work_id=work_id, capability_id=capability_id, input_payload=payload_in
        )

    if prep_err or scoped is None:
        status = (
            FAILED
            if prep_err in {"EVIDENCE_MISSING"} or str(prep_err).startswith("RESOURCE_")
            else "REJECTED"
        )
        return {
            "ok": False,
            "status": status,
            "reason": prep_err or INVALID_SCHEMA,
            "capability_id": capability_id,
            "work_id": work_id,
            "run_id": run_id,
            "model_invocations": MODEL_INVOCATIONS,
            "final_action_called": False,
        }

    worker_out = worker.execute(
        request,
        implementation_id=implementation_id,
        scoped_input=scoped,
        force_failure=force_worker_failure,
        max_output_bytes=limits.max_output_bytes,
        max_input_bytes=limits.max_input_bytes,
        timeout_ms=limits.timeout_ms,
        resource_limits=limits.to_dict(),
    )
    _note_model_invocation(inference_required)

    if worker_out["status"] == FAILED:
        err = str(worker_out.get("error") or "WORKER_FAILURE")
        if err == "TIMEOUT" or err.startswith("TIMEOUT"):
            fail_reason = "TIMEOUT"
        elif "RESOURCE_EXHAUSTION" in err:
            fail_reason = "RESOURCE_EXHAUSTION"
        elif "MODEL_UNAVAILABLE" in err:
            fail_reason = "MODEL_UNAVAILABLE"
        elif "MODEL_LOAD_FAILURE" in err:
            fail_reason = "MODEL_LOAD_FAILURE"
        else:
            fail_reason = "WORKER_FAILURE"
        result = WorkResult(
            work_id=work_id,
            citizen_id=citizen_id,
            capability_id=capability_id,
            implementation_id=implementation_id,
            status=FAILED,
            result={},
            validator_result={
                "ok": False,
                "result": "SKIPPED",
                "validator_id": validator_id,
            },
            created_at=created,
            worker_id=worker_id,
            extras={"worker": worker_out, "run_id": run_id},
        )
        href = append_history(
            home,
            {
                "plane": "canonical_work_history",
                "work_id": work_id,
                "run_id": run_id,
                "citizen_id": citizen_id,
                "capability_id": capability_id,
                "implementation_id": implementation_id,
                "status": FAILED,
                "validator_result": result.validator_result,
                "runtime_decision": None,
                "result_ref": None,
                "timestamp": created,
                "error": err,
                "implementation_process_id": worker_out.get("implementation_process_id"),
                "process_exit_status": worker_out.get("process_exit_status"),
                "timeout_status": worker_out.get("timeout_status"),
                "final_action_called": False,
            },
        )
        evidence_append(
            layout(home)["evidence"],
            citizen_id=citizen_id,
            event_type="work_failed",
            payload={
                "work_id": work_id,
                "run_id": run_id,
                "capability_id": capability_id,
                "implementation_id": implementation_id,
                "worker_id": worker_id,
                "error": err,
                "status": FAILED,
                "timestamp": created,
                "implementation_process_id": worker_out.get("implementation_process_id"),
                "process_exit_status": worker_out.get("process_exit_status"),
                "timeout_status": worker_out.get("timeout_status"),
                "final_action_called": False,
            },
        )
        return {
            "ok": False,
            "status": FAILED,
            "reason": fail_reason,
            "request": request.to_dict(),
            "result": result.to_dict(),
            "history_ref": str(href),
            "worker_id": worker_id,
            "capability": binding,
            "run_id": run_id,
            "model_invocations": MODEL_INVOCATIONS,
            "final_action_called": False,
            "implementation_process_id": worker_out.get("implementation_process_id"),
            "process_exit_status": worker_out.get("process_exit_status"),
            "timeout_status": worker_out.get("timeout_status"),
            "process_isolated": worker_out.get("process_isolated"),
        }

    if worker_out["status"] == BLOCKED:
        return {
            "ok": False,
            "status": BLOCKED,
            "reason": worker_out.get("error") or "WORKER_BLOCKED",
            "request": request.to_dict(),
            "worker_id": worker_id,
            "capability_id": capability_id,
            "run_id": run_id,
            "model_invocations": MODEL_INVOCATIONS,
            "final_action_called": False,
        }

    candidate = dict(worker_out.get("result") or {})

    out_err = check_output_bytes(candidate, limits)
    if out_err:
        env = failure_envelope(RESOURCE_EXHAUSTION, capability_id=capability_id, detail=out_err)
        env.update({"work_id": work_id, "run_id": run_id, "final_action_called": False})
        return env
    span_err = check_evidence_spans(candidate.get("evidence_spans") or [], limits)
    if span_err:
        env = failure_envelope(RESOURCE_EXHAUSTION, capability_id=capability_id, detail=span_err)
        env.update({"work_id": work_id, "run_id": run_id, "final_action_called": False})
        return env

    if capability_id == INTEGRITY_DIGEST_CAPABILITY_ID:
        if force_validator_reject:
            candidate = {
                **candidate,
                "digest": "sha256:" + ("0" * 64),
                "input_hash": "0" * 64,
            }
        validation = work_validator.validate(home, candidate)
    elif capability_id == HISTORY_DIGEST_CAPABILITY_ID:
        if force_validator_reject:
            candidate = {
                **candidate,
                "digest": "sha256:" + ("0" * 64),
                "input_hash": "0" * 64,
            }
        validation = validator_history.validate(home, candidate)
    else:
        if force_validator_reject:
            candidate = {**candidate, "intent": "__invalid__"}
        validation = validator_intent.validate_intent_proposal(
            candidate,
            expected_work_id=work_id,
            expected_capability_id=capability_id,
            expected_input_hash=str(scoped.get("input_digest") or ""),
            expected_implementation_id=implementation_id,
            allowed_intents=tuple(scoped.get("allowed_intents") or []),
            task_text=str(scoped.get("task_text") or ""),
            authorized_model=authorized_model,
        )

    decision = decide_from_validation(
        work_id=work_id,
        capability_id=capability_id,
        implementation_id=implementation_id,
        validation=validation,
    )

    final_action_called = False
    final_action_result: dict[str, Any] | None = None
    if decision.final_action_authorized and decision.decision == ACCEPT_PROPOSAL:
        final_action_result = action(
            work_id=work_id,
            decision=decision.decision,
            payload={
                "capability_id": capability_id,
                "implementation_id": implementation_id,
                "candidate": candidate,
            },
        )
        final_action_called = True
        status = COMPLETE
    else:
        status = "REJECTED"

    input_hash = str(candidate.get("input_hash") or scoped.get("input_digest") or "")
    output_hash = _sha256_json(candidate)
    proposal_hash = output_hash if capability_id == INTENT_PROPOSAL_CAPABILITY_ID else None
    cand_extras = candidate.get("extras") if isinstance(candidate.get("extras"), dict) else {}
    model_artifact_hash = cand_extras.get("model_artifact_hash") if isinstance(cand_extras, dict) else None
    model_parameters_hash = cand_extras.get("model_parameters_hash") if isinstance(cand_extras, dict) else None
    model_load_time_ms = cand_extras.get("model_load_time_ms") if isinstance(cand_extras, dict) else None
    inference_time_ms = cand_extras.get("inference_time_ms") if isinstance(cand_extras, dict) else None
    input_bytes_metric = cand_extras.get("input_bytes") if isinstance(cand_extras, dict) else None
    output_bytes_metric = candidate.get("output_bytes")
    if inference_required:
        model_id = candidate.get("model_id")
        model_version = candidate.get("model_version")
    else:
        model_id = None
        model_version = None
        model_artifact_hash = None
        model_parameters_hash = None
        model_load_time_ms = None
        inference_time_ms = None

    evidence_dir = layout(home)["evidence"]
    envelope = evidence_append(
        evidence_dir,
        citizen_id=citizen_id,
        event_type="work_result",
        payload={
            "work_id": work_id,
            "run_id": run_id,
            "capability_id": capability_id,
            "implementation_id": implementation_id,
            "worker_id": worker_id,
            "input_hash": input_hash,
            "output_hash": output_hash,
            "proposal_hash": proposal_hash,
            "validator_id": validation.get("validator_id") or validator_id or VALIDATOR_ID,
            "validator_result": validation,
            "runtime_decision": decision.to_dict(),
            "status": status,
            "timestamp": created,
            "result": candidate if status == COMPLETE else None,
            "final_action_called": final_action_called,
            "implementation_process_id": worker_out.get("implementation_process_id"),
            "process_exit_status": worker_out.get("process_exit_status"),
            "timeout_status": worker_out.get("timeout_status"),
            "output_hash": worker_out.get("output_hash") or output_hash,
            "model_id": model_id,
            "model_version": model_version,
            "model_artifact_hash": model_artifact_hash,
            "model_parameters_hash": model_parameters_hash,
            "model_load_time_ms": model_load_time_ms,
            "inference_time_ms": inference_time_ms,
            "input_bytes": input_bytes_metric,
            "output_bytes": output_bytes_metric,
            "inference_required": inference_required,
            "inference_reason": inference_reason,
            "policy_version": policy_version,
            "task_class": work_context.task_class,
            "work_context": work_context.to_dict(),
            "inference_need_decision": inference_decision.to_dict(),
            "work_execution_plan": execution.to_dict(),
        },
    )
    evidence_ref = str(evidence_dir / "evidence.jsonl")

    result = WorkResult(
        work_id=work_id,
        citizen_id=citizen_id,
        capability_id=capability_id,
        implementation_id=implementation_id,
        status=status,
        result=candidate if status == COMPLETE else {},
        validator_result=validation,
        created_at=created,
        worker_id=worker_id,
        input_hash=input_hash,
        output_hash=output_hash,
        evidence_ref=evidence_ref,
        inference_required=inference_required,
        inference_reason=inference_reason,
        policy_version=policy_version,
        extras={
            "worker": worker_out,
            "evidence_envelope": envelope,
            "runtime_decision": decision.to_dict(),
            "run_id": run_id,
            "final_action_called": final_action_called,
            "final_action_result": final_action_result,
            "model_invocations": MODEL_INVOCATIONS,
            "model_id": model_id,
            "model_version": model_version,
            "model_artifact_hash": model_artifact_hash,
            "model_parameters_hash": model_parameters_hash,
            "model_load_time_ms": model_load_time_ms,
            "inference_time_ms": inference_time_ms,
            "inference_reason": inference_reason,
            "policy_version": policy_version,
            "task_class": work_context.task_class,
            "work_context": work_context.to_dict(),
            "inference_need_decision": inference_decision.to_dict(),
            "work_execution_plan": execution.to_dict(),
            "implementation_process_id": worker_out.get("implementation_process_id"),
            "process_exit_status": worker_out.get("process_exit_status"),
            "timeout_status": worker_out.get("timeout_status"),
            "process_isolated": worker_out.get("process_isolated"),
        },
    )

    href = append_history(
        home,
        {
            "plane": "canonical_work_history",
            "work_id": work_id,
            "run_id": run_id,
            "citizen_id": citizen_id,
            "capability_id": capability_id,
            "implementation_id": implementation_id,
            "status": status,
            "proposal": candidate if capability_id == INTENT_PROPOSAL_CAPABILITY_ID else None,
            "validator_result": validation,
            "runtime_decision": decision.to_dict(),
            "result_ref": evidence_ref,
            "timestamp": created,
            "input_hash": input_hash,
            "output_hash": output_hash,
            "proposal_hash": proposal_hash,
            "result": candidate if status == COMPLETE else None,
            "model_id": model_id,
            "model_version": model_version,
            "model_artifact_hash": model_artifact_hash,
            "model_parameters_hash": model_parameters_hash,
            "final_action_called": final_action_called,
            "implementation_process_id": worker_out.get("implementation_process_id"),
            "process_exit_status": worker_out.get("process_exit_status"),
            "timeout_status": worker_out.get("timeout_status"),
            "inference_required": inference_required,
            "inference_reason": inference_reason,
            "policy_version": policy_version,
            "task_class": work_context.task_class,
            "work_context": work_context.to_dict(),
            "inference_need_decision": inference_decision.to_dict(),
            "work_execution_plan": execution.to_dict(),
        },
    )
    result.history_ref = str(href)

    return {
        "ok": status == COMPLETE,
        "status": status,
        "request": request.to_dict(),
        "result": result.to_dict(),
        "capability": binding,
        "worker_id": worker_id,
        "implementation_id": implementation_id,
        "validator_id": validator_id,
        "history_ref": str(href),
        "evidence_ref": evidence_ref,
        "runtime_decision": decision.to_dict(),
        "run_id": run_id,
        "model_invocations": MODEL_INVOCATIONS,
        "final_action_called": final_action_called,
        "implementation_process_id": worker_out.get("implementation_process_id"),
        "process_exit_status": worker_out.get("process_exit_status"),
        "timeout_status": worker_out.get("timeout_status"),
        "process_isolated": worker_out.get("process_isolated"),
        "model_id": model_id,
        "model_version": model_version,
        "model_artifact_hash": model_artifact_hash,
        "model_parameters_hash": model_parameters_hash,
        "model_load_time_ms": model_load_time_ms,
        "inference_time_ms": inference_time_ms,
        "input_bytes": input_bytes_metric,
        "output_bytes": output_bytes_metric,
        "inference_required": inference_required,
        "inference_reason": inference_reason,
        "policy_version": policy_version,
        "task_class": work_context.task_class,
        "work_context": work_context.to_dict(),
        "inference_need_decision": inference_decision.to_dict(),
        "work_execution_plan": execution.to_dict(),
    }
