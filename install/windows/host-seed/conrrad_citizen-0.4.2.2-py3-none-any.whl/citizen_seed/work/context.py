"""Explicit model/context input — only capability-declared fields."""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Any, Mapping


FORBIDDEN_CONTEXT_FIELDS: frozenset[str] = frozenset(
    {
        "identity",
        "filesystem",
        "history",
        "credentials",
        "environment",
        "env",
        "runtime_config",
        "citizen",
        "home",
        "policy",
        "evidence_ledger",
        "full_history",
        "secrets",
        "private_key",
    }
)


@dataclass(frozen=True)
class IntentProposalInput:
    work_id: str
    capability_id: str
    task_text: str
    allowed_intents: tuple[str, ...]
    input_digest: str
    language: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "work_id": self.work_id,
            "capability_id": self.capability_id,
            "task_text": self.task_text,
            "allowed_intents": list(self.allowed_intents),
            "input_digest": self.input_digest,
        }
        if self.language is not None:
            d["language"] = self.language
        return d


def parse_intent_proposal_input(raw: Mapping[str, Any]) -> IntentProposalInput:
    """Strict schema: reject undeclared / forbidden fields."""
    if not isinstance(raw, Mapping):
        raise ValueError("INVALID_SCHEMA:not_object")
    keys = set(raw.keys())
    forbidden = keys.intersection(FORBIDDEN_CONTEXT_FIELDS)
    if forbidden:
        raise ValueError(f"INVALID_SCHEMA:forbidden:{','.join(sorted(forbidden))}")
    allowed = {
        "work_id",
        "capability_id",
        "task_text",
        "allowed_intents",
        "input_digest",
        "language",
    }
    unknown = keys - allowed
    if unknown:
        raise ValueError(f"INVALID_SCHEMA:unknown_fields:{','.join(sorted(unknown))}")
    required = {"work_id", "capability_id", "task_text", "allowed_intents", "input_digest"}
    missing = required - keys
    if missing:
        raise ValueError(f"INVALID_SCHEMA:missing:{','.join(sorted(missing))}")
    intents = raw["allowed_intents"]
    if not isinstance(intents, (list, tuple)) or not all(isinstance(x, str) for x in intents):
        raise ValueError("INVALID_SCHEMA:allowed_intents")
    language = raw.get("language")
    if language is not None and not isinstance(language, str):
        raise ValueError("INVALID_SCHEMA:language")
    return IntentProposalInput(
        work_id=str(raw["work_id"]),
        capability_id=str(raw["capability_id"]),
        task_text=str(raw["task_text"]),
        allowed_intents=tuple(str(x) for x in intents),
        input_digest=str(raw["input_digest"]),
        language=None if language is None else str(language),
    )


def digest_task_text(task_text: str) -> str:
    return hashlib.sha256(task_text.encode("utf-8")).hexdigest()


def canonical_input_hash(payload: Mapping[str, Any]) -> str:
    raw = json.dumps(dict(payload), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()
