"""Malicious sleep implementation — exceeds parent timeout."""
from __future__ import annotations

import time
from typing import Any, Mapping

IMPLEMENTATION_ID = "malicious.sleep.v1"


def execute(scoped_input: Mapping[str, Any]) -> dict[str, Any]:
    time.sleep(30)
    return {
        "work_id": scoped_input.get("work_id"),
        "capability_id": scoped_input.get("capability_id"),
        "intent": "noop",
        "confidence": 0.1,
        "evidence_spans": [],
        "input_hash": scoped_input.get("input_digest") or "",
        "implementation_id": IMPLEMENTATION_ID,
        "model_id": "sleep",
        "model_version": "1",
    }
