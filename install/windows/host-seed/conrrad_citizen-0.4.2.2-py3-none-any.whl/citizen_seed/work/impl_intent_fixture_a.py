"""Deterministic fixture implementation A for evidence.intent_proposal.

NOT a model. Used only to prove capability↔implementation substitution contracts.
"""
from __future__ import annotations

from typing import Any, Mapping

from .capability_contract import INTENT_FIXTURE_A_IMPLEMENTATION_ID, INTENT_PROPOSAL_CAPABILITY_ID
from .implementation_contract import assert_scoped_input_safe
from .proposal import EvidenceSpan, IntentProposal


IMPLEMENTATION_ID = INTENT_FIXTURE_A_IMPLEMENTATION_ID
CAPABILITY_ID = INTENT_PROPOSAL_CAPABILITY_ID
MODEL_ID = "fixture-a"
MODEL_VERSION = "1"


class IntentFixtureA:
    implementation_id = IMPLEMENTATION_ID
    capability_id = CAPABILITY_ID

    def execute(self, scoped_input: Mapping[str, Any]) -> dict[str, Any]:
        assert_scoped_input_safe(scoped_input)
        task = str(scoped_input["task_text"])
        allowed = list(scoped_input.get("allowed_intents") or [])
        intent = "noop"
        for candidate in ("summarize", "flag_anomaly", "request_review", "noop"):
            if candidate in allowed:
                intent = candidate
                break
        # Deterministic span: first min(8, len) chars when non-empty
        end = min(8, len(task))
        spans = (EvidenceSpan(start=0, end=end, quote=task[:end]),) if end else ()
        proposal = IntentProposal(
            work_id=str(scoped_input["work_id"]),
            capability_id=CAPABILITY_ID,
            intent=intent,
            confidence=0.5,
            evidence_spans=spans,
            input_hash=str(scoped_input["input_digest"]),
            implementation_id=IMPLEMENTATION_ID,
            model_id=MODEL_ID,
            model_version=MODEL_VERSION,
        )
        return proposal.to_dict()


def execute(scoped_input: Mapping[str, Any]) -> dict[str, Any]:
    return IntentFixtureA().execute(scoped_input)
