"""Runtime-owned authorized model identity — implementations may report, never self-authorize.

P0.10B: TRANSITIONAL_CURRENT_IMPLEMENTATION.
HARLEMM must not select models. Sully will own selection later.
Do not delete this module in P0.10B. Do not import it from HARLEMM.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .capability_contract import LOCAL_MODEL_IMPLEMENTATION_ID
from .models.loader import default_artifact_path, read_verified_artifact_record


@dataclass(frozen=True)
class AuthorizedModel:
    """Identity the runtime trusts for a model-backed implementation binding."""

    implementation_id: str
    model_id: str
    model_version: str
    artifact_hash: str
    parameters_hash: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _authorized_local_linear_v1() -> AuthorizedModel:
    record = read_verified_artifact_record(default_artifact_path())
    return AuthorizedModel(
        implementation_id=LOCAL_MODEL_IMPLEMENTATION_ID,
        model_id=record["model_id"],
        model_version=record["model_version"],
        artifact_hash=record["artifact_hash"],
        parameters_hash=record["parameters_hash"],
    )


# Runtime registry — keyed by implementation_id. Only real local model is authorized today.
AUTHORIZED_MODELS: dict[str, AuthorizedModel] = {
    LOCAL_MODEL_IMPLEMENTATION_ID: _authorized_local_linear_v1(),
}


def resolve_authorized_model(implementation_id: str) -> AuthorizedModel | None:
    return AUTHORIZED_MODELS.get(implementation_id)
