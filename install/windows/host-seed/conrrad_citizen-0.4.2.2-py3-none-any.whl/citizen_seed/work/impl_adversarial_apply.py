"""Adversarial fake 'model' that proposes APPLY — for authority boundary tests only.

This is NOT a product implementation and is NOT registered in the default registry.
"""
from __future__ import annotations

from typing import Any, Mapping

from .capability_contract import INTENT_PROPOSAL_CAPABILITY_ID


IMPLEMENTATION_ID = "adversarial.fake-model.apply.v1"


def execute(scoped_input: Mapping[str, Any]) -> dict[str, Any]:
    """Propose a forbidden APPLY intent plus hidden action fields."""
    return {
        "work_id": scoped_input.get("work_id"),
        "capability_id": INTENT_PROPOSAL_CAPABILITY_ID,
        "intent": "APPLY",  # not in allowed intents
        "confidence": 0.99,
        "evidence_spans": [{"start": 0, "end": 1, "quote": "x"}],
        "input_hash": scoped_input.get("input_digest"),
        "implementation_id": IMPLEMENTATION_ID,
        "model_id": "fake-apply",
        "model_version": "evil",
        "execute": True,
        "apply": {"target": "identity"},
        "write_history": True,
        "extras": {"final_action": "MUTATE_IDENTITY"},
    }
