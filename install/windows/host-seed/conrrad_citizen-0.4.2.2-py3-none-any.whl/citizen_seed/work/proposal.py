"""Typed proposal object — DATA only, never an action surface."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Mapping


FORBIDDEN_PROPOSAL_FIELDS: frozenset[str] = frozenset(
    {
        "execute",
        "apply",
        "install",
        "write_history",
        "write_evidence",
        "mutate_identity",
        "mutate_policy",
        "final_action",
        "run_tool",
        "invoke_tool",
    }
)


@dataclass(frozen=True)
class EvidenceSpan:
    start: int
    end: int
    quote: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class IntentProposal:
    """Proposal for evidence.intent_proposal — DATA, not authority."""

    work_id: str
    capability_id: str
    intent: str
    confidence: float
    evidence_spans: tuple[EvidenceSpan, ...]
    input_hash: str
    implementation_id: str
    model_id: str
    model_version: str
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "work_id": self.work_id,
            "capability_id": self.capability_id,
            "intent": self.intent,
            "confidence": self.confidence,
            "evidence_spans": [s.to_dict() for s in self.evidence_spans],
            "input_hash": self.input_hash,
            "implementation_id": self.implementation_id,
            "model_id": self.model_id,
            "model_version": self.model_version,
            "extras": dict(self.extras),
        }

    @staticmethod
    def from_mapping(data: Mapping[str, Any]) -> IntentProposal:
        spans_raw = data.get("evidence_spans") or []
        spans: list[EvidenceSpan] = []
        for item in spans_raw:
            if isinstance(item, EvidenceSpan):
                spans.append(item)
            else:
                spans.append(
                    EvidenceSpan(
                        start=int(item["start"]),
                        end=int(item["end"]),
                        quote=str(item.get("quote") or ""),
                    )
                )
        return IntentProposal(
            work_id=str(data["work_id"]),
            capability_id=str(data["capability_id"]),
            intent=str(data["intent"]),
            confidence=float(data["confidence"]),
            evidence_spans=tuple(spans),
            input_hash=str(data["input_hash"]),
            implementation_id=str(data["implementation_id"]),
            model_id=str(data.get("model_id") or "none"),
            model_version=str(data.get("model_version") or "none"),
            extras=dict(data.get("extras") or {}),
        )
