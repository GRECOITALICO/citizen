"""Resource limits with explicit enforcement status (no false 'bounded' claims)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class ResourceLimits:
    max_input_bytes: int
    max_output_bytes: int
    max_evidence_spans: int
    timeout_ms: int
    # Explicit enforcement flags — never claim ENFORCED without real checks.
    max_input_bytes_enforcement: str = "ENFORCED"
    max_output_bytes_enforcement: str = "ENFORCED"
    max_evidence_spans_enforcement: str = "ENFORCED"
    timeout_ms_enforcement: str = "ENFORCED"
    memory_limit_enforcement: str = "NOT_IMPLEMENTED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "max_input_bytes": self.max_input_bytes,
            "max_output_bytes": self.max_output_bytes,
            "max_evidence_spans": self.max_evidence_spans,
            "timeout_ms": self.timeout_ms,
            "enforcement": {
                "max_input_bytes": self.max_input_bytes_enforcement,
                "max_output_bytes": self.max_output_bytes_enforcement,
                "max_evidence_spans": self.max_evidence_spans_enforcement,
                "timeout_ms": self.timeout_ms_enforcement,
                "memory_limit": self.memory_limit_enforcement,
            },
        }


INTENT_PROPOSAL_LIMITS = ResourceLimits(
    max_input_bytes=8_192,
    max_output_bytes=8_192,
    max_evidence_spans=8,
    timeout_ms=2_000,
)

INTEGRITY_DIGEST_LIMITS = ResourceLimits(
    max_input_bytes=8_388_608,
    max_output_bytes=65_536,
    max_evidence_spans=0,
    timeout_ms=5_000,
)


def check_input_bytes(data: bytes | str, limits: ResourceLimits) -> str | None:
    if limits.max_input_bytes_enforcement != "ENFORCED":
        return None
    n = len(data.encode("utf-8") if isinstance(data, str) else data)
    if n > limits.max_input_bytes:
        return "RESOURCE_EXHAUSTION:max_input_bytes"
    return None


def check_output_bytes(payload: Mapping[str, Any], limits: ResourceLimits) -> str | None:
    if limits.max_output_bytes_enforcement != "ENFORCED":
        return None
    import json

    n = len(json.dumps(dict(payload), sort_keys=True, separators=(",", ":")).encode("utf-8"))
    if n > limits.max_output_bytes:
        return "RESOURCE_EXHAUSTION:max_output_bytes"
    return None


def check_evidence_spans(spans: Any, limits: ResourceLimits) -> str | None:
    if limits.max_evidence_spans_enforcement != "ENFORCED":
        return None
    if not isinstance(spans, (list, tuple)):
        return "RESOURCE_EXHAUSTION:max_evidence_spans_type"
    if len(spans) > limits.max_evidence_spans:
        return "RESOURCE_EXHAUSTION:max_evidence_spans"
    return None


# Timeout is enforced for child-process execution (parent kill).
# Memory is still not OS-enforced — do not claim bounded inference overall.
TIMEOUT_ENFORCEMENT = "ENFORCED"
MEMORY_ENFORCEMENT = "NOT_IMPLEMENTED"
BOUNDED_INFERENCE_CLAIM_ALLOWED = False
