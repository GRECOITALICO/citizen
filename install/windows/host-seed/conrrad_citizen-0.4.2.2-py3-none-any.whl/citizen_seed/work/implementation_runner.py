"""Child-process implementation runner.

Invoked as:
  python -m citizen_seed.work.implementation_runner --request-file PATH --response-file PATH

Loads ONLY the selected implementation module. Does NOT import trusted runtime
control-plane modules (identity, evidence, history, engine, policy).
"""
from __future__ import annotations

import argparse
import sys
import traceback
from typing import Any

from .implementation_registry import load_execute, resolve_module
from .ipc import ImplementationRequest, ImplementationResponse, read_json, write_json


def _run_request(req: ImplementationRequest) -> ImplementationResponse:
    impl_id = req.implementation_id
    if resolve_module(impl_id) is None:
        return ImplementationResponse(
            status="FAILED",
            implementation_id=impl_id,
            error=f"UNKNOWN_IMPLEMENTATION:{impl_id}",
        )
    try:
        execute = load_execute(impl_id)
        scoped = dict(req.scoped_input)
        raw = execute(scoped)
        if not isinstance(raw, dict):
            return ImplementationResponse(
                status="FAILED",
                implementation_id=impl_id,
                error="IMPLEMENTATION_RETURN_NOT_OBJECT",
            )
        result = dict(raw)
        attack_probe = result.pop("attack_probe", None)
        resp = ImplementationResponse(
            status="COMPLETE",
            implementation_id=impl_id,
            result=result,
            attack_probe=attack_probe if isinstance(attack_probe, dict) else None,
        )
        resp.finalize_hashes()
        return resp
    except Exception as exc:  # noqa: BLE001
        return ImplementationResponse(
            status="FAILED",
            implementation_id=impl_id,
            error=f"IMPLEMENTATION_EXCEPTION:{type(exc).__name__}:{exc}",
        )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Citizen implementation child runner")
    parser.add_argument("--request-file", required=True)
    parser.add_argument("--response-file", required=True)
    args = parser.parse_args(argv)

    try:
        req_data = read_json(args.request_file)
        req = ImplementationRequest.from_dict(req_data)
        resp = _run_request(req)
    except Exception as exc:  # noqa: BLE001
        resp = ImplementationResponse(
            status="FAILED",
            implementation_id="unknown",
            error=f"RUNNER_EXCEPTION:{type(exc).__name__}:{exc}",
        )
        traceback.print_exc(file=sys.stderr)

    write_json(args.response_file, resp.to_dict())
    return 0 if resp.status == "COMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
