"""Independent IntentProposalValidator — must not import model/fixture implementations."""
from __future__ import annotations

import math
from typing import Any, Mapping

from .authorized_models import AuthorizedModel
from .capability_contract import ALLOWED_INTENTS, INTENT_PROPOSAL_CAPABILITY_ID, INTENT_PROPOSAL_VALIDATOR_ID
from .proposal import FORBIDDEN_PROPOSAL_FIELDS, IntentProposal

VALIDATOR_ID = INTENT_PROPOSAL_VALIDATOR_ID


def validate_intent_proposal(
    proposal_data: Mapping[str, Any],
    *,
    expected_work_id: str,
    expected_capability_id: str,
    expected_input_hash: str,
    expected_implementation_id: str,
    allowed_intents: tuple[str, ...] | list[str] | None = None,
    task_text: str = "",
    authorized_model: AuthorizedModel | None = None,
) -> dict[str, Any]:
    """Validate proposal independently of any implementation module."""
    errors: list[str] = []
    # ABSTAIN is always structurally valid even if caller omits it from allowed_intents.
    base_allowed = tuple(allowed_intents) if allowed_intents is not None else ALLOWED_INTENTS
    allowed = tuple(dict.fromkeys([*base_allowed, "ABSTAIN"]))

    if "model_id" in proposal_data and not isinstance(proposal_data.get("model_id"), str):
        errors.append("MODEL_ID_TYPE")
    if "model_version" in proposal_data and not isinstance(proposal_data.get("model_version"), str):
        errors.append("MODEL_VERSION_TYPE")

    # Hidden action fields on raw mapping
    for key in FORBIDDEN_PROPOSAL_FIELDS:
        if key in proposal_data:
            errors.append(f"FORBIDDEN_FIELD:{key}")
    extras = proposal_data.get("extras") or {}
    if isinstance(extras, dict):
        for key in FORBIDDEN_PROPOSAL_FIELDS:
            if key in extras:
                errors.append(f"FORBIDDEN_EXTRAS_FIELD:{key}")

    try:
        proposal = IntentProposal.from_mapping(proposal_data)
    except Exception as exc:  # noqa: BLE001
        return {
            "ok": False,
            "result": "REJECT",
            "reason": "INVALID_SCHEMA",
            "validator_id": VALIDATOR_ID,
            "validated_outside_implementation": True,
            "errors": [f"SCHEMA:{type(exc).__name__}:{exc}"],
        }

    if proposal.capability_id != expected_capability_id:
        errors.append("CAPABILITY_MISMATCH")
    if expected_capability_id != INTENT_PROPOSAL_CAPABILITY_ID:
        errors.append("UNEXPECTED_CAPABILITY")
    if proposal.work_id != expected_work_id:
        errors.append("WORK_ID_MISMATCH")
    if proposal.input_hash != expected_input_hash:
        errors.append("INPUT_HASH_MISMATCH")
    if proposal.implementation_id != expected_implementation_id:
        errors.append("IMPLEMENTATION_ID_MISMATCH")

    if authorized_model is not None:
        if proposal.implementation_id != authorized_model.implementation_id:
            errors.append("AUTHORIZED_IMPLEMENTATION_MISMATCH")
        if proposal.model_id != authorized_model.model_id:
            errors.append("UNAUTHORIZED_MODEL_ID")
        if proposal.model_version != authorized_model.model_version:
            errors.append("UNAUTHORIZED_MODEL_VERSION")
        if not isinstance(extras, dict):
            errors.append("MODEL_EXTRAS_MISSING")
        else:
            reported_art = extras.get("model_artifact_hash")
            reported_params = extras.get("model_parameters_hash")
            if reported_art != authorized_model.artifact_hash:
                errors.append("UNAUTHORIZED_ARTIFACT_HASH")
            if reported_params != authorized_model.parameters_hash:
                errors.append("UNAUTHORIZED_PARAMETERS_HASH")

    if proposal.intent not in allowed:
        errors.append("UNKNOWN_INTENT")

    conf = proposal.confidence
    if not isinstance(conf, (int, float)) or isinstance(conf, bool):
        errors.append("CONFIDENCE_TYPE")
    else:
        if math.isnan(conf) or math.isinf(conf):
            errors.append("CONFIDENCE_NON_FINITE")
        if conf < 0.0 or conf > 1.0:
            errors.append("CONFIDENCE_RANGE")

    for span in proposal.evidence_spans:
        if span.start < 0 or span.end < span.start:
            errors.append("SPAN_OFFSETS")
            break
        if task_text and span.end > len(task_text):
            errors.append("SPAN_OUT_OF_BOUNDS")
            break
        if task_text and span.quote and task_text[span.start : span.end] != span.quote:
            errors.append("SPAN_QUOTE_MISMATCH")
            break

    ok = len(errors) == 0
    return {
        "ok": ok,
        "result": "ACCEPT" if ok else "REJECT",
        "reason": "OK" if ok else (errors[0] if errors else "VALIDATOR_REJECT"),
        "validator_id": VALIDATOR_ID,
        "validated_outside_implementation": True,
        "errors": errors,
        "proposal": proposal.to_dict() if ok else None,
    }
