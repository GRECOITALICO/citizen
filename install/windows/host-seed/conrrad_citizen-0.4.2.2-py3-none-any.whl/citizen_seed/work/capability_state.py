"""Observable capability state, derived from the authoritative capability registry.

This is a projection, not a second registry and not a second state machine. Every
value here is computed from facts the runtime already owns: what the registry
declares, which implementations are actually present on disk, and what Work has
already completed. The only stored state is which capabilities a user asked for
but cannot have yet.

Capability, implementation, model and worker are kept as separate planes on
purpose — a capability is what the Citizen can do, an implementation is one way
of doing it, a model is an optional ingredient of an implementation, and the
worker is who runs it.
"""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any

from .capability_contract import (
    HISTORY_DIGEST_CAPABILITY_ID,
    HISTORY_DIGEST_GRANT_ASSET_ID,
    LOCAL_MODEL_IMPLEMENTATION_ID,
)
from .history import read_history
from .registry import default_implementation_table, local_registry

GRANT_REQUIRED = {
    HISTORY_DIGEST_CAPABILITY_ID: HISTORY_DIGEST_GRANT_ASSET_ID,
}

_LOCK = threading.Lock()

MISSING = "MISSING"
AVAILABLE = "AVAILABLE"
ACTIVE = "ACTIVE"
AVAILABLE_AFTER_SYNC = "AVAILABLE_AFTER_SYNC"

CAPABILITY_STATES = (MISSING, AVAILABLE, ACTIVE, AVAILABLE_AFTER_SYNC)

# Implementations whose availability depends on a verified artifact rather than
# on code shipped with the package.
MODEL_BACKED_IMPLEMENTATIONS = {
    LOCAL_MODEL_IMPLEMENTATION_ID: "citizen-intent-linear-v1.0.0",
}

REQUESTS_NAME = "capability_requests.json"


def _requests_path(home: Path) -> Path:
    d = Path(home) / "ops"
    d.mkdir(parents=True, exist_ok=True)
    return d / REQUESTS_NAME


def read_requests(home: Path) -> list[str]:
    path = _requests_path(home)
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    return [str(c) for c in data.get("requested") or []]


def request_capability(home: Path, capability_id: str) -> dict[str, Any]:
    """Record that a capability was asked for.

    Unknown capabilities are refused rather than invented, and a capability that
    is already usable is not turned into a pending request.
    """
    registry = local_registry()
    if capability_id not in registry:
        return {
            "ok": False,
            "capability_id": capability_id,
            "reason": "UNKNOWN_CAPABILITY",
        }
    if capability_unlocked(home, capability_id) and _available_implementations(
        capability_id, registry
    ):
        return {
            "ok": False,
            "capability_id": capability_id,
            "reason": "ALREADY_AVAILABLE",
        }
    with _LOCK:
        requested = read_requests(home)
        if capability_id not in requested:
            requested.append(capability_id)
        _requests_path(home).write_text(
            json.dumps({"requested": requested}, indent=2) + "\n", encoding="utf-8"
        )
    return {
        "ok": True,
        "capability_id": capability_id,
        "state": AVAILABLE_AFTER_SYNC,
    }


def clear_satisfied_requests(home: Path) -> list[str]:
    """Drop requests whose implementation is now present. Called after a Sync."""
    registry = local_registry()
    with _LOCK:
        requested = read_requests(home)
        still_pending = [
            cid
            for cid in requested
            if not (
                capability_unlocked(home, cid)
                and _available_implementations(cid, registry)
            )
        ]
        satisfied = [cid for cid in requested if cid not in still_pending]
        if satisfied:
            _requests_path(home).write_text(
                json.dumps({"requested": still_pending}, indent=2) + "\n",
                encoding="utf-8",
            )
    return satisfied


def grant_asset_ids(home: Path) -> set[str]:
    """Asset ids currently bound in the living manifest."""
    try:
        from citizen_seed.manifest import load_manifest
        from citizen_seed.paths import layout

        manifest = load_manifest(layout(home)["manifest"] / "current.json")
    except Exception:
        return set()
    return {str(a.get("asset_id") or "") for a in manifest.assets}


def capability_unlocked(home: Path, capability_id: str) -> bool:
    """A grant-gated capability is locked until Sync installs its signed grant."""
    grant_id = GRANT_REQUIRED.get(capability_id)
    if not grant_id:
        return capability_id in local_registry()
    return grant_id in grant_asset_ids(home)


def implementation_available(implementation_id: str) -> bool:
    if implementation_id in MODEL_BACKED_IMPLEMENTATIONS:
        from .models.loader import default_artifact_path

        return default_artifact_path().is_file()
    return implementation_id in default_implementation_table()


def _available_implementations(
    capability_id: str, registry: dict[str, dict[str, Any]]
) -> list[str]:
    spec = registry.get(capability_id) or {}
    bindings = spec.get("implementation_bindings") or []
    return [i for i in bindings if implementation_available(str(i))]


def _exercised_capabilities(home: Path) -> set[str]:
    """Capabilities that have actually completed Work in this Citizen's history."""
    out: set[str] = set()
    for row in read_history(home):
        if str(row.get("status") or "").upper() != "COMPLETE":
            continue
        cid = row.get("capability_id")
        if cid:
            out.add(str(cid))
    return out


def project_capabilities(home: Path) -> list[dict[str, Any]]:
    """One row per declared capability, with its four planes kept distinct."""
    home = Path(home)
    registry = local_registry()
    requested = set(read_requests(home))
    exercised = _exercised_capabilities(home)

    rows: list[dict[str, Any]] = []
    for capability_id, spec in sorted(registry.items()):
        bindings = [str(i) for i in spec.get("implementation_bindings") or []]
        implementations = [
            {
                "implementation_id": impl,
                "available": implementation_available(impl),
                "model_id": MODEL_BACKED_IMPLEMENTATIONS.get(impl),
                "kind": "model_backed" if impl in MODEL_BACKED_IMPLEMENTATIONS else "deterministic",
            }
            for impl in bindings
        ]
        usable = [i["implementation_id"] for i in implementations if i["available"]]
        unlocked = capability_unlocked(home, capability_id)

        if not unlocked:
            state = AVAILABLE_AFTER_SYNC if capability_id in requested else MISSING
        elif not usable:
            state = AVAILABLE_AFTER_SYNC if capability_id in requested else MISSING
        elif capability_id in exercised:
            state = ACTIVE
        else:
            state = AVAILABLE

        rows.append(
            {
                "capability_id": capability_id,
                "name": spec.get("name") or capability_id,
                "version": spec.get("version"),
                "state": state,
                "requested": capability_id in requested,
                "worker_id": spec.get("worker_id"),
                "validator_id": spec.get("validator_id"),
                "default_implementation_id": spec.get("implementation_id"),
                "implementations": implementations,
                "available_implementations": usable,
            }
        )
    return rows


def project(home: Path) -> dict[str, Any]:
    capabilities = project_capabilities(home)
    return {
        "schema": "conrrad.citizen.capability_state/v1",
        "capabilities": capabilities,
        "counts": {
            state: sum(1 for c in capabilities if c["state"] == state)
            for state in CAPABILITY_STATES
        },
    }


def diff_capabilities(
    before: list[dict[str, Any]], after: list[dict[str, Any]]
) -> dict[str, list[str]]:
    """NEW / CHANGED / PRESERVED / REMOVED across an evolution."""
    before_by_id = {c["capability_id"]: c for c in before}
    after_by_id = {c["capability_id"]: c for c in after}

    new = sorted(set(after_by_id) - set(before_by_id))
    removed = sorted(set(before_by_id) - set(after_by_id))
    changed = sorted(
        cid
        for cid in set(before_by_id) & set(after_by_id)
        if (
            before_by_id[cid]["state"] != after_by_id[cid]["state"]
            or before_by_id[cid]["version"] != after_by_id[cid]["version"]
            or before_by_id[cid]["available_implementations"]
            != after_by_id[cid]["available_implementations"]
        )
    )
    preserved = sorted(
        cid for cid in set(before_by_id) & set(after_by_id) if cid not in set(changed)
    )
    return {
        "new": new,
        "changed": changed,
        "preserved": preserved,
        "removed": removed,
    }
