"""Bounded worker — launches untrusted implementations in a child process.

Default path: trusted runtime → process_runner → implementation_runner → DATA.
Optional in-process mode exists only for contract-unit tests (process_isolated=False).
"""
from __future__ import annotations

import json
from typing import Any, Callable, Mapping

from .contracts import WorkRequest
from .implementation_contract import FORBIDDEN_SCOPED_INPUT_KEYS, assert_scoped_input_safe
from .process_runner import run_implementation_process, spawn_timestamp
from .registry import WORKER_ID

PENDING = "PENDING"
RUNNING = "RUNNING"
COMPLETE = "COMPLETE"
BLOCKED = "BLOCKED"
FAILED = "FAILED"

ImplementationFn = Callable[[Mapping[str, Any]], Mapping[str, Any]]


class EvidenceWorker:
    """Least-authority worker. Does not own evidence/history/identity writers."""

    worker_id = WORKER_ID

    def __init__(
        self,
        implementations: dict[str, ImplementationFn] | None = None,
        *,
        process_isolated: bool = True,
    ):
        self._implementations = implementations
        self.process_isolated = process_isolated

    def execute(
        self,
        request: WorkRequest,
        *,
        implementation_id: str,
        scoped_input: Mapping[str, Any],
        force_failure: bool = False,
        max_output_bytes: int | None = None,
        max_input_bytes: int | None = None,
        timeout_ms: int | None = None,
        resource_limits: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if force_failure:
            return {
                "worker_id": self.worker_id,
                "status": FAILED,
                "implementation_id": implementation_id,
                "input": request.input,
                "error": "INDUCED_WORKER_FAILURE",
                "result": None,
                "process_isolated": self.process_isolated,
            }

        try:
            assert_scoped_input_safe(scoped_input)
        except ValueError as exc:
            return {
                "worker_id": self.worker_id,
                "status": BLOCKED,
                "implementation_id": implementation_id,
                "input": request.input,
                "error": str(exc),
                "result": None,
                "process_isolated": self.process_isolated,
            }

        scoped_cap = scoped_input.get("capability_id")
        if scoped_cap is not None and scoped_cap != request.capability_id:
            return {
                "worker_id": self.worker_id,
                "status": BLOCKED,
                "implementation_id": implementation_id,
                "input": request.input,
                "error": "WORKER_CAPABILITY_MISMATCH",
                "result": None,
                "process_isolated": self.process_isolated,
            }

        # Production / default: child process
        if self.process_isolated or self._implementations is None:
            limits = dict(resource_limits or {})
            out_max = int(max_output_bytes if max_output_bytes is not None else limits.get("max_output_bytes", 65_536))
            in_max = int(max_input_bytes if max_input_bytes is not None else limits.get("max_input_bytes", 8_388_608))
            t_ms = int(timeout_ms if timeout_ms is not None else limits.get("timeout_ms", 5_000))
            proc_out = run_implementation_process(
                work_id=request.work_id,
                capability_id=request.capability_id,
                implementation_id=implementation_id,
                scoped_input=scoped_input,
                resource_limits=limits,
                request_timestamp=spawn_timestamp(),
                timeout_ms=t_ms,
                max_input_bytes=in_max,
                max_output_bytes=out_max,
            )
            status = str(proc_out.get("status") or FAILED)
            return {
                "worker_id": self.worker_id,
                "status": status,
                "implementation_id": implementation_id,
                "input": request.input,
                "result": proc_out.get("result"),
                "error": proc_out.get("error"),
                "process_isolated": True,
                "implementation_process_id": proc_out.get("implementation_process_id"),
                "process_exit_status": proc_out.get("process_exit_status"),
                "timeout_status": proc_out.get("timeout_status"),
                "output_hash": proc_out.get("output_hash"),
                "attack_probe": proc_out.get("attack_probe"),
            }

        # Contract-unit path only (explicit process_isolated=False + table)
        impl = (self._implementations or {}).get(implementation_id)
        if impl is None:
            return {
                "worker_id": self.worker_id,
                "status": BLOCKED,
                "implementation_id": implementation_id,
                "input": request.input,
                "error": "UNKNOWN_IMPLEMENTATION",
                "result": None,
                "process_isolated": False,
            }

        try:
            result = dict(impl(scoped_input))
            if max_output_bytes is not None:
                size = len(json.dumps(result, sort_keys=True, separators=(",", ":")).encode("utf-8"))
                if size > max_output_bytes:
                    return {
                        "worker_id": self.worker_id,
                        "status": FAILED,
                        "implementation_id": implementation_id,
                        "input": request.input,
                        "error": "RESOURCE_EXHAUSTION:max_output_bytes",
                        "result": None,
                        "process_isolated": False,
                    }
            return {
                "worker_id": self.worker_id,
                "status": COMPLETE,
                "implementation_id": implementation_id,
                "input": request.input,
                "result": result,
                "error": None,
                "process_isolated": False,
            }
        except Exception as exc:  # noqa: BLE001
            return {
                "worker_id": self.worker_id,
                "status": FAILED,
                "implementation_id": implementation_id,
                "input": request.input,
                "result": None,
                "error": f"WORKER_EXCEPTION:{type(exc).__name__}:{exc}",
                "process_isolated": False,
            }


def default_worker() -> EvidenceWorker:
    return EvidenceWorker(process_isolated=True)


WORKER_FORBIDDEN_SCOPED_KEYS = FORBIDDEN_SCOPED_INPUT_KEYS
