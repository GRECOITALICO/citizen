"""local-model.intent-proposal.linear.v1 — real local linear classifier implementation.

Runs only inside the child process. Returns IntentProposal DATA only.
Increments no parent counters; parent measures MODEL_INVOCATIONS.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Mapping

from .capability_contract import INTENT_PROPOSAL_CAPABILITY_ID
from .implementation_contract import assert_scoped_input_safe
from .models.loader import LocalIntentModelLoader, ModelLoadError
from .proposal import EvidenceSpan, IntentProposal

IMPLEMENTATION_ID = "local-model.intent-proposal.linear.v1"
CAPABILITY_ID = INTENT_PROPOSAL_CAPABILITY_ID


def execute(scoped_input: Mapping[str, Any]) -> dict[str, Any]:
    assert_scoped_input_safe(scoped_input)
    artifact_override = scoped_input.get("model_artifact_path") or os.environ.get(
        "CITIZEN_INTENT_MODEL_ARTIFACT"
    )
    loader = LocalIntentModelLoader(
        Path(artifact_override) if artifact_override else None
    )
    try:
        model, meta = loader.load()
    except ModelLoadError as exc:
        # Propagate typed failure to runner → parent
        raise RuntimeError(exc.code if not str(exc).startswith(exc.code) else str(exc)) from exc

    task_text = str(scoped_input.get("task_text") or "")
    allowed = list(scoped_input.get("allowed_intents") or [])
    pred = model.predict(task_text, allowed_intents=allowed)

    spans = tuple(
        EvidenceSpan(start=int(s["start"]), end=int(s["end"]), quote=str(s.get("quote") or ""))
        for s in pred["evidence_spans"]
    )
    proposal = IntentProposal(
        work_id=str(scoped_input["work_id"]),
        capability_id=CAPABILITY_ID,
        intent=str(pred["intent"]),
        confidence=float(pred["confidence"]),
        evidence_spans=spans,
        input_hash=str(scoped_input.get("input_digest") or ""),
        implementation_id=IMPLEMENTATION_ID,
        model_id=model.model_id,
        model_version=model.model_version,
        extras={
            "model_artifact_hash": meta["model_artifact_hash"],
            "model_parameters_hash": meta["model_parameters_hash"],
            "model_load_time_ms": meta["model_load_time_ms"],
            "inference_time_ms": pred["inference_time_ms"],
            "input_bytes": pred["input_bytes"],
        },
    )
    out = proposal.to_dict()
    out["output_bytes"] = len(
        __import__("json").dumps(out, sort_keys=True, separators=(",", ":")).encode("utf-8")
    )
    return out
