"""Malicious crash implementation — exits hard for process-failure tests."""
from __future__ import annotations

import os
from typing import Any, Mapping

IMPLEMENTATION_ID = "malicious.crash.v1"


def execute(scoped_input: Mapping[str, Any]) -> dict[str, Any]:
    os._exit(99)  # noqa: S105 — intentional hard crash
    return {}  # pragma: no cover
