"""Local Citizen evolution semantics — projection, plan, persist, resume.

P0.11H.1. Not a Control Plane service. Not a second updater.
Discovery never applies. Only an explicit Sync (or resume of an already
requested plan) may apply. One user Sync means CURRENT → TARGET.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

PLAN_SCHEMA = "conrrad.citizen.evolution_plan/v1"
PLAN_FILENAME = "EVOLUTION_PLAN.json"

# UI / ops labels. Engine READY (post-verify, pre-apply) is transient.
# Mission READY (plan complete, Citizen at target) is terminal — written as
# Updated / Current / Noop, never as a leaked engine Ready.
TRANSIENT_SYNC_STATES = frozenset(
    {
        "Checking",
        "Update Available",
        "Sync Requested",
        "Planning",
        "Downloading",
        "Verifying",
        "Verified",
        "Ready",
        "Apply Update",
        "Updating",
        "Restart Required",
        "Restarting",
        "Applying",
        "SYNCING",
        "Syncing",
        "SYNCING...",
    }
)

TERMINAL_SYNC_STATES = frozenset(
    {
        "Current",
        "Noop",
        "Updated",
        "Sync Failed",
        "Rolled Back",
        "TARGET_BEHIND_CURRENT",
    }
)

IN_PROGRESS_PLAN_STATUSES = frozenset(
    {
        "sync_requested",
        "planning",
        "applying",
        "downloading",
        "verifying",
        "interrupted",
    }
)

RELATION_CURRENT = "CURRENT"
RELATION_UPDATE_AVAILABLE = "UPDATE_AVAILABLE"
RELATION_TARGET_BEHIND = "TARGET_BEHIND_CURRENT"


def parse_semver_tuple(ver: str) -> tuple[int, int, int]:
    m = re.match(r"v?(\d+)\.(\d+)(?:\.(\d+))?", str(ver or "").strip())
    if not m:
        return (0, 0, 0)
    return (int(m.group(1)), int(m.group(2)), int(m.group(3) or 0))


def compare_versions(left: str, right: str) -> int:
    a = parse_semver_tuple(left)
    b = parse_semver_tuple(right)
    return (a > b) - (a < b)


def is_newer(candidate: str, current: str) -> bool:
    return compare_versions(candidate, current) > 0


def classify_current_target(current_version: str, target_version: str) -> str:
    cmp = compare_versions(target_version, current_version)
    if cmp > 0:
        return RELATION_UPDATE_AVAILABLE
    if cmp == 0:
        return RELATION_CURRENT
    return RELATION_TARGET_BEHIND


def select_target(current_version: str, discovered_versions: list[str]) -> tuple[str, str]:
    """Pick TARGET from compatible discovered versions.

    Returns (target_version, relation).
    TARGET_BEHIND keeps the discovered latest so callers can refuse downgrade
    without pretending the Citizen is behind a newer release.
    """
    current = str(current_version or "").lstrip("v")
    usable = [str(v).lstrip("v") for v in discovered_versions if str(v or "").strip()]
    if not usable:
        return current, RELATION_CURRENT
    latest = max(usable, key=parse_semver_tuple)
    relation = classify_current_target(current, latest)
    if relation == RELATION_CURRENT:
        return current, relation
    if relation == RELATION_UPDATE_AVAILABLE:
        return latest, relation
    return latest, relation


def pack_is_compatible(
    *,
    pack_runtime: str,
    pack_compatibility: str,
    pack_citizen_id: str,
    runtime_version: str,
    current_compatibility: str,
    current_citizen_id: str,
) -> bool:
    """Local/remote pack gate. Host platform is not a fork of these fields."""
    if pack_runtime and str(pack_runtime) != str(runtime_version):
        return False
    if pack_compatibility and current_compatibility and pack_compatibility != current_compatibility:
        return False
    if pack_citizen_id and current_citizen_id and pack_citizen_id != current_citizen_id:
        return False
    return True


def remote_is_compatible(*, minimum_supported_version: str, runtime_version: str) -> bool:
    if not minimum_supported_version:
        return True
    return compare_versions(runtime_version, minimum_supported_version) >= 0


def update_projection(
    *,
    current_version: str,
    target_version: str,
    runtime_version: str,
    sync_state: dict[str, Any] | None = None,
    plan: dict[str, Any] | None = None,
    sync_in_flight: bool = False,
    update_source: str | None = None,
    update_release: str | None = None,
    living_version: str | None = None,
) -> dict[str, Any]:
    """Single local update truth. UI and APIs must consume this, not stale flags."""
    current = str(current_version or "").lstrip("v")
    target = str(target_version or current).lstrip("v")
    runtime = str(runtime_version or "")
    living = str(living_version or current).lstrip("v")
    relation = classify_current_target(current, target)
    update_available = relation == RELATION_UPDATE_AVAILABLE
    sync_required = update_available
    if relation == RELATION_UPDATE_AVAILABLE:
        update_status = "UPDATE AVAILABLE"
    elif relation == RELATION_TARGET_BEHIND:
        update_status = "TARGET_BEHIND_CURRENT"
    else:
        update_status = "Current"

    raw_sync = ""
    if isinstance(sync_state, dict):
        raw_sync = str(sync_state.get("state") or "")
    plan_active = bool(plan and str(plan.get("status") or "") in IN_PROGRESS_PLAN_STATUSES)
    in_flight = bool(sync_in_flight or plan_active)

    if in_flight:
        sync_status = raw_sync if raw_sync else "SYNCING"
        if sync_status in TERMINAL_SYNC_STATES:
            sync_status = "SYNCING"
        evolution_status = str((plan or {}).get("status") or "sync_requested")
    else:
        if not raw_sync or raw_sync in TRANSIENT_SYNC_STATES:
            if relation == RELATION_CURRENT:
                sync_status = "Current"
            elif relation == RELATION_UPDATE_AVAILABLE:
                sync_status = "Update Available"
            else:
                sync_status = "TARGET_BEHIND_CURRENT"
        else:
            sync_status = raw_sync
        if plan and str(plan.get("status") or "") == "failed":
            evolution_status = "FAILED"
            if raw_sync == "Rolled Back":
                evolution_status = "ROLLED_BACK"
                sync_status = "Rolled Back"
        elif plan and str(plan.get("status") or "") == "complete":
            evolution_status = "READY"
        elif relation == RELATION_CURRENT:
            evolution_status = "READY"
        elif relation == RELATION_TARGET_BEHIND:
            evolution_status = "TARGET_BEHIND_CURRENT"
        else:
            evolution_status = "UPDATE_AVAILABLE"

    current_step = int((plan or {}).get("current_step") or 0)
    total_steps = int((plan or {}).get("total_steps") or 0)
    return {
        "current_version": current,
        "target_version": target,
        "runtime_version": runtime,
        "living_version": living,
        "update_available": update_available,
        "sync_required": sync_required,
        "update_status": update_status,
        "sync_status": sync_status,
        "evolution_status": evolution_status,
        "target_behind_current": relation == RELATION_TARGET_BEHIND,
        "relation": relation,
        "update_source": update_source,
        "update_release": update_release,
        "plan_active": plan_active,
        "current_step": current_step,
        "total_steps": total_steps,
        "step_label": (
            f"Step {min(current_step + 1, total_steps)} of {total_steps}" if total_steps else ""
        ),
    }


def build_evolution_plan(
    *,
    source_version: str,
    target_version: str,
    artifacts: list[dict[str, Any]],
) -> dict[str, Any]:
    """Ordered internal steps from CURRENT to TARGET.

    If intermediate compatible artifacts exist, they are applied in version
    order (migrations). If only a TARGET artifact exists, the plan is one jump.
    """
    source = str(source_version or "").lstrip("v")
    target = str(target_version or "").lstrip("v")
    relation = classify_current_target(source, target)
    if relation == RELATION_CURRENT:
        return empty_plan(source, target, status="noop")
    if relation == RELATION_TARGET_BEHIND:
        return empty_plan(source, target, status="target_behind")

    chosen: list[dict[str, Any]] = []
    for art in artifacts:
        ver = str(art.get("version") or "").lstrip("v")
        if not ver:
            continue
        if not is_newer(ver, source):
            continue
        if compare_versions(ver, target) > 0:
            continue
        chosen.append({**art, "version": ver})
    chosen.sort(key=lambda a: (parse_semver_tuple(a["version"]), str(a.get("release") or "")))

    # Prefer a single artifact per version (local over remote).
    by_ver: dict[str, dict[str, Any]] = {}
    for art in chosen:
        prev = by_ver.get(art["version"])
        if prev is None or (prev.get("kind") == "remote" and art.get("kind") != "remote"):
            by_ver[art["version"]] = art
    ordered = [by_ver[v] for v in sorted(by_ver, key=parse_semver_tuple)]

    steps: list[dict[str, Any]] = []
    prev = source
    for art in ordered:
        steps.append(
            {
                "from_version": prev,
                "to_version": art["version"],
                "kind": art.get("kind") or "local",
                "artifact_ref": art.get("path") or art.get("artifact_ref") or "",
                "release": art.get("release"),
                "source": art.get("source"),
                "envelope": art.get("envelope"),
            }
        )
        prev = art["version"]

    status = "planning" if steps else "unplannable"
    return {
        "schema": PLAN_SCHEMA,
        "source_version": source,
        "target_version": target,
        "steps": steps,
        "current_step": 0,
        "total_steps": len(steps),
        "status": status,
        "artifact_refs": [s.get("artifact_ref") or "" for s in steps],
        "migration_refs": [],
        "rollback_state": {
            "supported": False,
            "last_valid_version": source,
        },
        "last_verified_step": -1,
        "failed_step": None,
        "error_code": None,
        "phase": None,
    }


def empty_plan(source: str, target: str, *, status: str) -> dict[str, Any]:
    return {
        "schema": PLAN_SCHEMA,
        "source_version": source,
        "target_version": target,
        "steps": [],
        "current_step": 0,
        "total_steps": 0,
        "status": status,
        "artifact_refs": [],
        "migration_refs": [],
        "rollback_state": {
            "supported": False,
            "last_valid_version": source,
        },
        "last_verified_step": -1,
        "failed_step": None,
        "error_code": None,
        "phase": None,
    }


def plan_path(home: Path) -> Path:
    return Path(home) / "ops" / PLAN_FILENAME


def load_plan(home: Path) -> dict[str, Any] | None:
    path = plan_path(home)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    return data


def save_plan(home: Path, plan: dict[str, Any]) -> Path:
    path = plan_path(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(plan, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def clear_plan(home: Path) -> None:
    path = plan_path(home)
    if path.is_file():
        path.unlink()


def mark_plan_failed(
    plan: dict[str, Any],
    *,
    failed_step: int,
    error_code: str,
    phase: str,
    last_valid_version: str,
) -> dict[str, Any]:
    plan = dict(plan)
    plan["status"] = "failed"
    plan["failed_step"] = failed_step
    plan["error_code"] = error_code
    plan["phase"] = phase
    rollback = dict(plan.get("rollback_state") or {})
    rollback["supported"] = False
    rollback["last_valid_version"] = last_valid_version
    plan["rollback_state"] = rollback
    return plan


def mark_step_verified(plan: dict[str, Any], step_index: int, living_version: str) -> dict[str, Any]:
    plan = dict(plan)
    plan["current_step"] = step_index + 1
    plan["last_verified_step"] = step_index
    plan["status"] = "applying"
    rollback = dict(plan.get("rollback_state") or {})
    rollback["last_valid_version"] = living_version
    plan["rollback_state"] = rollback
    if plan["current_step"] >= int(plan.get("total_steps") or 0):
        plan["status"] = "complete"
    return plan
